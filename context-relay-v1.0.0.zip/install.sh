#!/bin/bash
# Context Relay installer
# 사용법:
#   ./install.sh              Claude Code(~/.claude/skills)에 설치
#   ./install.sh --codex      + Codex(~/.codex/skills)에도 설치
#   ./install.sh --agents     + Agent Skills 표준(~/.config/agents/skills)에도 설치 (Kimi Code 등)
#   ./install.sh --all        위 3곳 전부
#   ./install.sh --force      기존 설치를 덮어쓰기
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/context-relay"
FORCE=0
DO_CODEX=0
DO_AGENTS=0

for arg in "$@"; do
  case "$arg" in
    --codex)  DO_CODEX=1 ;;
    --agents) DO_AGENTS=1 ;;
    --all)    DO_CODEX=1; DO_AGENTS=1 ;;
    --force)  FORCE=1 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "unknown option: $arg (see --help)"; exit 1 ;;
  esac
done

if [ ! -f "$SRC/SKILL.md" ]; then
  echo "error: $SRC/SKILL.md not found — zip을 풀었던 폴더에서 실행하세요."
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "error: python3 가 필요합니다 (표준 라이브러리만 사용, pip 설치 불필요)."
  exit 1
fi

install_to() {
  local dir="$1"
  local dest="$dir/context-relay"
  mkdir -p "$dir"
  if [ -e "$dest" ] || [ -L "$dest" ]; then
    if [ "$FORCE" -eq 1 ]; then
      rm -rf "$dest"
    else
      echo "SKIP: $dest 가 이미 존재합니다 (덮어쓰려면 --force)"
      return 0
    fi
  fi
  cp -R "$SRC" "$dest"
  echo "OK: $dest"
}

install_to "$HOME/.claude/skills"
[ "$DO_CODEX" -eq 1 ]  && install_to "$HOME/.codex/skills"
[ "$DO_AGENTS" -eq 1 ] && install_to "$HOME/.config/agents/skills"

echo ""
echo "설치 검증:"
python3 "$HOME/.claude/skills/context-relay/scripts/cr.py" --help >/dev/null \
  && echo "  cr.py 실행 OK" || echo "  경고: cr.py 실행 실패 — python3 버전(3.9+) 확인"

echo ""
echo "시작하기: 프로젝트 루트에서 /context-relay setup 을 호출하세요."
