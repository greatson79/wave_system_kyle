# PRD: Context Relay

## 여러 AI 코딩 도구를 넘나드는 프로젝트 맥락 인계 시스템

---

# 1. 제품 개요

## 1.1 제품명

**Context Relay**

## 1.2 한국어 설명명

**AI 개발 인계서 생성 및 세션 맥락 관리 스킬**

## 1.3 방송/마케팅용 이름

**프로젝트 블랙박스**

## 1.4 한 줄 정의

Claude Code, Cursor, Antigravity, Codex 등 여러 AI 코딩 도구에서 흩어진 작업 맥락을 날짜별·작업별·프롬프트별로 기록하고, 다음 세션에서 바로 이어갈 수 있도록 인계 문서, SQLite 기반 작업 기억 저장소, 검색 시스템, 대시보드를 제공하는 Claude Code 스킬.

## 1.5 핵심 가치

AI 코딩 도구를 여러 개 사용할수록 프로젝트의 코드는 남지만, **왜 그렇게 만들었는지**, **어디까지 했는지**, **다음에 무엇을 해야 하는지**가 사라진다.

Context Relay는 이 맥락 손실을 막기 위해 프로젝트의 작업 이력, 프롬프트, 에이전트 사용 내역, 결정 사항, 변경 파일, 토큰 사용량, 작업 시간, GitHub 상태를 저장하고 검색·시각화·인계할 수 있게 한다.

---

# 2. 문제 정의

## 2.1 현재 문제

AI 코딩 환경은 점점 분산되고 있다.

사용자는 하나의 프로젝트를 다음과 같은 방식으로 진행한다.

```text
Claude Code에서 PRD 작성
→ Cursor에서 UI 수정
→ Codex에서 특정 기능 구현
→ Antigravity에서 실험
→ 다시 Claude Code에서 리팩토링
```

이 과정에서 다음 문제가 발생한다.

```text
1. 각 도구의 작업 맥락이 끊긴다.
2. 세션이 바뀌면 AI가 이전 판단을 잊는다.
3. 사용자가 어떤 프롬프트를 썼는지 추적하기 어렵다.
4. 프롬프트에 따라 어떤 구현 결과가 나왔는지 연결되지 않는다.
5. 날짜별 작업 이력은 남아도 작업별 스토리가 사라진다.
6. 프로젝트가 PRD에서 벗어나도 늦게 알아차린다.
7. 현재 진행 중인 task가 무엇인지 한눈에 보기 어렵다.
8. 에이전트별 작업 시간, 토큰 사용량, 산출물을 비교하기 어렵다.
9. 모든 내용을 Markdown에만 저장하면 데이터가 늘어날수록 검색과 분석이 느려진다.
10. 다음 세션에서 매번 프로젝트를 다시 설명해야 한다.
11. 프로젝트 최초 셋업이 없으면 도구마다 서로 다른 기준으로 작업을 시작한다.
```

## 2.2 핵심 통증

AI 코딩에서 가장 위험한 것은 코드가 틀리는 것이 아니다.
**프로젝트의 기억이 사라지는 것**이다.

파일은 남아 있지만, 이런 정보가 사라진다.

```text
- 왜 이 라이브러리를 선택했는가?
- 왜 이 기능은 보류했는가?
- 어떤 파일은 건드리면 안 되는가?
- 어떤 버그를 우회했는가?
- 어떤 프롬프트가 효과적이었는가?
- 어떤 AI 도구가 어떤 작업을 했는가?
- 다음 세션에서 무엇부터 해야 하는가?
```

Context Relay는 이 문제를 해결하는 프로젝트 맥락 운영 시스템이다.

---

# 3. 제품 목표

Context Relay의 목표는 단순 기록이 아니다.

이 제품의 목표는 다음 네 가지다.

```text
1. 프로젝트 시작 전에 공통 작업 헌법을 세팅한다.
2. 작업 중 발생한 맥락을 기억한다.
3. 흩어진 세션을 작업 스토리로 재구성한다.
4. 다음 세션에 안전하게 인계한다.
```

## 3.1 공통 작업 헌법을 세팅한다

프로젝트 최초 셋업 단계에서 `project-charter.md`, `PRD.md`, `TASKS.md`, `CLAUDE.md`, `AGENTS.md`, Cursor Rules를 생성하여 모든 AI 코딩 도구가 같은 기준을 읽게 한다.

## 3.2 기억한다

프로젝트에서 발생한 프롬프트, 응답 요약, 변경 파일, git diff, 작업 시간, 사용 에이전트, 토큰 사용량, 결정 사항을 SQLite DB에 저장한다.

## 3.3 맥락을 재구성한다

흩어진 세션 기록을 날짜별·작업별·목표별로 연결하여 하나의 작업 스토리로 재구성한다.

## 3.4 다음 세션에 안전하게 인계한다

다음 AI 도구가 바로 이어서 작업할 수 있도록 `handoff.md`, `next-session-prompt.md`, `decision-log.md`, `risk-notes.md`를 생성한다.

---

# 4. 대상 사용자

## 4.1 1차 사용자

```text
- Claude Code, Cursor, Codex, Antigravity 등을 함께 사용하는 AI 개발자
- 여러 AI 도구를 오가며 프로젝트를 만드는 바이브코더
- 비개발자이지만 AI 코딩 도구로 제품을 만들고 싶은 사용자
- Claude Code 스킬을 제작·배포하는 크리에이터
- 1인 개발자, 강사, 자동화 도구 제작자
```

## 4.2 2차 사용자

```text
- AI 개발 과정을 강의하는 강사
- 팀 단위로 AI 코딩 워크플로우를 운영하는 조직
- 외주 개발이나 프로토타입 개발 결과를 검수해야 하는 사람
- 프로젝트 인수인계가 잦은 개발팀
```

---

# 5. 핵심 컨셉

## 5.1 MD는 인계 문서, DB는 기억 저장소

초기 버전에서 모든 세션 내용을 Markdown으로 저장하면 사람이 읽기는 쉽지만, 데이터가 많아질수록 병목이 발생한다.

따라서 Context Relay는 다음 원칙을 따른다.

```text
SQLite DB:
- 원본 세션 데이터 저장
- 프롬프트 기록
- 응답 요약
- 파일 변경 이력
- 작업 시간
- 토큰 사용량
- 에이전트 사용 내역
- 검색 인덱스
- 대시보드 데이터

Markdown:
- 사람이 읽는 인계 문서
- 다음 세션 프롬프트
- 날짜별 요약
- 결정 사항 요약
- 위험 요소 요약
```

즉, DB가 **원천 데이터 저장소**이고, Markdown은 **사람과 AI가 읽는 요약 산출물**이다.

## 5.2 기록보다 인계가 중요하다

기록은 과거를 남긴다.
인계는 다음 행동을 가능하게 한다.

Context Relay는 단순히 "무엇을 했는가"를 저장하는 데서 끝나지 않는다.
반드시 다음 정보를 생성해야 한다.

```text
- 현재 프로젝트 상태
- 완료된 작업
- 미완료 작업
- 중요한 결정 사항
- 위험 요소
- 다음 세션에서 바로 할 일
- 다음 AI 도구에 넣을 프롬프트
```

## 5.3 프로젝트 최초 셋업이 없으면 인계도 흔들린다

Context Relay는 세션 종료 후 기록만 하는 도구가 아니다.

프로젝트 시작 시점에 공통 기준을 세팅해야 한다.

```text
- 프로젝트 목표
- MVP 범위
- 하지 않을 것
- 기술 스택
- 배포 목표
- 완료 기준
- AI 도구별 작업 규칙
- 세션 시작/종료 규칙
```

이 기준이 있어야 Claude Code, Cursor, Codex, Antigravity가 같은 방향으로 작업할 수 있다.

---

# 6. 주요 기능

---

## 6.0 Project Setup / Context Bootstrapping

### 6.0.1 목적

Context Relay는 프로젝트가 시작되는 순간 공통 작업 맥락을 세팅해야 한다.

여러 AI 코딩 도구가 서로 다른 기준으로 프로젝트를 해석하지 않도록, 프로젝트 루트에 공통 기준 문서와 도구별 지침 파일을 생성한다.

이 단계의 목적은 다음과 같다.

```text
1. 프로젝트의 목표와 범위를 명확히 한다.
2. 모든 AI 코딩 도구가 같은 PRD와 task 기준을 읽게 한다.
3. Claude Code, Cursor, Codex, Antigravity가 각자 다른 방향으로 작업하지 않도록 공통 규칙을 주입한다.
4. 세션 기록, 프롬프트 기록, 작업 이력, 결정 사항을 저장할 SQLite DB를 초기화한다.
5. 다음 세션 인계 문서가 생성될 기본 구조를 만든다.
```

### 6.0.2 최초 셋업 명령

```text
/context-relay setup
```

또는

```text
/context-relay init --full
```

이 명령은 프로젝트 루트에서 실행한다.

### 6.0.3 셋업 시 사용자에게 질문할 항목

초기 셋업은 무작정 파일을 만드는 것이 아니라, 프로젝트의 기준을 수집해야 한다.

필수 질문은 다음과 같다.

```text
1. 이 프로젝트의 이름은 무엇인가?
2. 이 프로젝트의 최종 목표는 무엇인가?
3. 이번 MVP의 범위는 어디까지인가?
4. 이번 버전에서 절대 하지 않을 것은 무엇인가?
5. 주로 사용할 AI 코딩 도구는 무엇인가?
   - Claude Code
   - Cursor
   - Codex
   - Antigravity
   - 기타
6. 사용할 주요 기술 스택은 무엇인가?
7. 배포 목표는 무엇인가?
8. 가장 중요한 완료 기준은 무엇인가?
9. 건드리면 위험한 파일이나 영역이 있는가?
10. 세션 종료 시 자동/수동으로 기록할 정보는 무엇인가?
11. GitHub 저장소를 사용할 것인가?
12. 프롬프트 원문을 저장할 것인가, 요약만 저장할 것인가?
13. 토큰 사용량과 작업 시간을 수동으로 기록할 것인가, 가능한 범위에서 자동 추정할 것인가?
```

### 6.0.4 셋업 결과로 생성되는 디렉터리 구조

```text
/
├── PRD.md
├── TASKS.md
├── CLAUDE.md
├── AGENTS.md
├── README.md
├── .cursor/
│   └── rules/
│       └── context-relay.mdc
├── context/
│   ├── handoff.md
│   ├── next-session-prompt.md
│   ├── daily-worklog.md
│   ├── decision-log.md
│   ├── risk-notes.md
│   ├── prompt-library.md
│   └── project-charter.md
└── context-relay/
    ├── context-relay.sqlite
    ├── config.json
    ├── dashboard/
    │   └── index.html
    ├── exports/
    └── snapshots/
```

### 6.0.5 `project-charter.md`

초기 셋업에서 가장 중요한 문서는 `project-charter.md`다.

이 문서는 프로젝트의 헌법 역할을 한다.

```markdown
# Project Charter

## Project Name
...

## Product Goal
이 프로젝트가 최종적으로 해결하려는 문제를 적는다.

## MVP Scope
이번 버전에서 반드시 구현할 범위를 적는다.

## Non-Goals
이번 버전에서 하지 않을 것을 명확히 적는다.

## Target Users
누가 이 프로젝트를 사용하는지 적는다.

## Tech Stack
주요 기술 스택을 적는다.

## Deployment Target
배포 목표를 적는다.

## Definition of Done
완료 기준을 적는다.

## AI Tool Rules
모든 AI 코딩 도구가 따라야 할 공통 규칙을 적는다.

## Risk Areas
건드리면 위험한 파일, 모듈, 정책을 적는다.

## Session Handoff Rule
모든 세션은 종료 전에 Context Relay capture를 실행한다.
```

### 6.0.6 도구별 지침 파일 생성 전략

Context Relay는 각 도구가 읽을 수 있는 지침 파일을 자동 생성하거나 업데이트한다.

---

### Claude Code: `CLAUDE.md`

```markdown
# CLAUDE.md

## Project Context

이 프로젝트는 Context Relay로 작업 맥락을 관리한다.

먼저 아래 문서를 읽고 작업을 시작하라.

1. `/context/project-charter.md`
2. `/PRD.md`
3. `/TASKS.md`
4. `/context/handoff.md`
5. `/context/decision-log.md`
6. `/context/risk-notes.md`

## Working Rules

- PRD와 TASKS에 없는 작업을 임의로 시작하지 말 것.
- MVP 범위를 벗어나는 기능은 제안만 하고 구현하지 말 것.
- 구조 변경, 라이브러리 추가, DB 스키마 변경은 decision-log 후보로 기록할 것.
- 핵심 파일을 수정할 때는 변경 이유를 명시할 것.
- 작업 종료 전 Context Relay capture를 실행할 것.

## Session Start Protocol

1. handoff.md를 읽는다.
2. 현재 진행 task를 확인한다.
3. risk-notes.md를 확인한다.
4. next-session-prompt.md의 목표를 따른다.

## Session End Protocol

1. 변경 파일을 요약한다.
2. 완료/미완료 작업을 분리한다.
3. 사용한 프롬프트와 결과를 기록한다.
4. 다음 세션용 handoff를 갱신한다.
```

---

### Codex / Agent 계열: `AGENTS.md`

```markdown
# AGENTS.md

## Global Agent Rule

This repository uses Context Relay to preserve project memory across AI coding tools.

## Required Reading Before Work

- `/context/project-charter.md`
- `/PRD.md`
- `/TASKS.md`
- `/context/handoff.md`
- `/context/decision-log.md`
- `/context/risk-notes.md`

## Agent Behavior

- Stay aligned with the current active task.
- Do not introduce unrelated refactoring.
- Do not change architecture without recording the decision.
- Report any divergence from PRD before implementation.
- Record prompts, implementation result, changed files, and unresolved issues.

## After Work

Generate or update:

- `/context/handoff.md`
- `/context/next-session-prompt.md`
- `/context/daily-worklog.md`
- `/context/decision-log.md`
- `/context/risk-notes.md`
```

---

### Cursor: `.cursor/rules/context-relay.mdc`

```markdown
---
description: Context Relay project memory rule
globs:
  - "**/*"
alwaysApply: true
---

# Context Relay Rule

Before making changes:

- Read `/context/project-charter.md`
- Read `/context/handoff.md`
- Check `/context/risk-notes.md`
- Stay within the current active task

During work:

- Do not modify unrelated files.
- Do not add new libraries unless the task requires it.
- If the implementation diverges from the PRD, stop and report it.
- Keep changes small and traceable.

After making changes:

- Summarize what changed.
- List modified files.
- Explain why the changes were made.
- Update Context Relay by running the capture workflow.
```

---

### Antigravity 전략

Antigravity의 세션 로그 접근 방식이 도구 버전에 따라 달라질 수 있으므로, MVP 단계에서는 다음 전략을 사용한다.

```text
1. 프로젝트 폴더 기준으로 변경 파일과 git diff를 분석한다.
2. Antigravity에서 사용한 프롬프트는 수동 또는 반자동으로 prompt log에 추가한다.
3. 세션 종료 시 Context Relay capture를 실행한다.
4. Antigravity 작업 결과는 tool_name = "antigravity"로 DB에 저장한다.
```

### 6.0.7 최초 셋업 완료 기준

초기 셋업은 다음 조건을 만족해야 완료된다.

```text
1. project-charter.md가 생성되어 있다.
2. PRD.md와 TASKS.md가 존재하거나 생성되었다.
3. CLAUDE.md가 Context Relay 규칙을 포함한다.
4. AGENTS.md가 Context Relay 규칙을 포함한다.
5. Cursor Rules가 생성되었다.
6. SQLite DB가 초기화되었다.
7. context 폴더의 기본 문서가 생성되었다.
8. dashboard 기본 파일이 생성되었다.
9. 첫 번째 handoff.md가 생성되었다.
10. next-session-prompt.md가 생성되었다.
```

---

## 6.1 프로젝트 초기화

### 기능 설명

프로젝트 루트에서 Context Relay를 초기화한다.

초기화는 두 수준으로 나뉜다.

```text
1. basic init
   - context 폴더와 기본 DB만 생성

2. full setup
   - project-charter, PRD, TASKS, CLAUDE.md, AGENTS.md, Cursor Rules, dashboard까지 생성
```

### 생성 항목

```text
/context
  ├── handoff.md
  ├── next-session-prompt.md
  ├── daily-worklog.md
  ├── decision-log.md
  ├── risk-notes.md
  ├── prompt-library.md
  └── project-charter.md

/context-relay
  ├── context-relay.sqlite
  ├── config.json
  ├── exports/
  ├── snapshots/
  └── dashboard/
```

### 초기화 시 탐색 대상

```text
- README.md
- PRD.md
- TASKS.md
- TODO.md
- CLAUDE.md
- AGENTS.md
- package.json
- pyproject.toml
- tsconfig.json
- .git/
- docs/
```

---

## 6.2 공통 도구별 맥락 기록 전략

### 6.2.1 공통 원칙

모든 도구에 대해 Context Relay는 다음 원칙을 적용한다.

```text
1. 도구 내부 로그에 전적으로 의존하지 않는다.
2. 프로젝트 폴더, git diff, 사용자가 저장한 프롬프트, 세션 요약을 기준으로 맥락을 재구성한다.
3. 각 도구별 지침 파일은 작업 규칙을 주입하는 용도로 사용한다.
4. 원천 데이터는 SQLite에 저장한다.
5. 사람이 읽을 인계 문서는 Markdown으로 생성한다.
6. 세션 시작 전에는 handoff를 읽고, 세션 종료 후에는 capture를 실행한다.
```

---

## 6.3 세션 기록

### 기능 설명

각 작업 세션을 하나의 단위로 기록한다.

### 기록 항목

```text
- session_id
- project_id
- tool_name
- agent_name
- started_at
- ended_at
- duration_sec
- session_goal
- user_request
- summary
- status
- token_input
- token_output
- token_total
- estimated_cost
- linked_task_id
```

### 세션 상태

```text
- planned
- active
- paused
- completed
- failed
- abandoned
```

---

## 6.4 프롬프트 라이브러리

### 기능 설명

사용자가 사용한 모든 프롬프트를 시간 순서대로 기록한다.

단순히 프롬프트만 저장하지 않고, 해당 프롬프트에 따라 AI가 어떤 구현 결과를 냈는지 연결한다.

### 기록 항목

```text
- prompt_id
- session_id
- tool_name
- agent_name
- prompt_text
- prompt_type
- created_at
- related_files
- result_summary
- implementation_result_id
- success_score
- reuse_candidate
```

### 프롬프트 유형

```text
- planning
- implementation
- debugging
- refactoring
- testing
- deployment
- documentation
- review
- recovery
```

### 프롬프트 라이브러리 출력 예시

```markdown
# Prompt Library

## 2026-07-05

### Prompt 001

도구: Claude Code
유형: implementation
목표: 결제 완료 후 다운로드 링크 생성

#### 프롬프트
...

#### AI 구현 결과
- webhook route 수정
- download token 생성 함수 추가
- 이메일 발송은 미완료

#### 재사용 가능성
높음

#### 개선 메모
다음에는 완료 기준을 더 명확히 넣을 것.
```

---

## 6.5 작업별 스토리 재구성

### 기능 설명

날짜별 기록만으로는 프로젝트 맥락을 파악하기 어렵다. Context Relay는 여러 세션에 걸친 작업을 하나의 task story로 묶는다.

### 예시

```markdown
# Task Story: 결제 후 다운로드 링크 발송

## 시작 배경
사용자가 상품 구매 후 즉시 다운로드 링크를 받아야 한다.

## 관련 세션
- 2026-07-05 Claude Code
- 2026-07-05 Cursor
- 2026-07-06 Codex

## 진행 내용
1. webhook route 추가
2. order 상태 업데이트 로직 연결
3. download token 생성 초안 작성
4. 이메일 템플릿 연결 시도

## 현재 상태
부분 완료

## 남은 작업
- token 만료 테스트
- 실결제 webhook 검증
- 이메일 발송 실패 처리

## 위험 요소
- webhook 응답 형식 변경 시 기존 결제 흐름 깨질 수 있음
```

---

## 6.6 현재 진행 Task 카드

### 기능 설명

현재 진행 중인 작업을 대시보드에서 카드 형태로 보여준다.

### 카드 정보

```text
- task title
- task status
- linked sessions
- assigned agent
- used tools
- token usage
- elapsed time
- changed files
- blockers
- next action
- PRD alignment score
- risk level
```

### 카드 상태

```text
- Not Started
- In Progress
- Blocked
- Needs Review
- Ready to Test
- Completed
```

---

## 6.7 SQLite 데이터베이스

### 기능 설명

Context Relay는 세션 데이터가 많아질수록 Markdown 기반 저장 방식이 병목이 될 수 있으므로 SQLite를 기본 저장소로 사용한다.

### DB 파일 위치

```text
/context-relay/context-relay.sqlite
```

### 주요 테이블

#### projects

```sql
CREATE TABLE projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
```

#### sessions

```sql
CREATE TABLE sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  tool_name TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT,
  ended_at TEXT,
  duration_sec INTEGER,
  session_goal TEXT,
  user_request TEXT,
  summary TEXT,
  status TEXT,
  token_input INTEGER DEFAULT 0,
  token_output INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  estimated_cost REAL DEFAULT 0,
  linked_task_id INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
```

#### prompts

```sql
CREATE TABLE prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  tool_name TEXT,
  agent_name TEXT,
  prompt_text TEXT NOT NULL,
  prompt_type TEXT,
  result_summary TEXT,
  success_score INTEGER,
  reuse_candidate INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
```

#### tasks

```sql
CREATE TABLE tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT,
  priority TEXT,
  prd_reference TEXT,
  risk_level TEXT,
  current_next_action TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
```

#### files_changed

```sql
CREATE TABLE files_changed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  change_type TEXT,
  change_summary TEXT,
  risk_level TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
```

#### decisions

```sql
CREATE TABLE decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  decision_text TEXT NOT NULL,
  reason TEXT,
  impact TEXT,
  revisit_condition TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
```

#### risks

```sql
CREATE TABLE risks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  risk_text TEXT NOT NULL,
  risk_level TEXT,
  related_file TEXT,
  mitigation TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
```

#### git_events

```sql
CREATE TABLE git_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  commit_hash TEXT,
  branch_name TEXT,
  diff_summary TEXT,
  changed_files_count INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
```

#### agents

```sql
CREATE TABLE agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  role TEXT,
  tool_name TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
```

#### session_agents

```sql
CREATE TABLE session_agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  agent_id INTEGER NOT NULL,
  duration_sec INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  result_summary TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(id),
  FOREIGN KEY(agent_id) REFERENCES agents(id)
);
```

---

## 6.8 FTS5 / BM25 검색

### 기능 설명

세션, 프롬프트, 결정 사항, 작업 기록이 많아지면 단순 파일 검색으로는 한계가 있다. Context Relay는 SQLite FTS5를 사용해 빠른 전문 검색을 제공한다.

### 검색 대상

```text
- 프롬프트 본문
- 세션 요약
- 작업 설명
- 결정 사항
- 위험 기록
- 파일 변경 요약
```

### FTS 테이블 예시

```sql
CREATE VIRTUAL TABLE search_index USING fts5(
  entity_type,
  entity_id,
  title,
  body,
  created_at,
  tokenize = 'unicode61'
);
```

### BM25 검색 예시

```sql
SELECT
  entity_type,
  entity_id,
  title,
  snippet(search_index, 3, '[', ']', '...', 20) AS snippet,
  bm25(search_index) AS rank
FROM search_index
WHERE search_index MATCH ?
ORDER BY rank
LIMIT 20;
```

### 검색 기능 예시

```text
- "결제 webhook 관련 작업 찾아줘"
- "download token을 왜 만들었는지 찾아줘"
- "Cursor에서 마지막으로 수정한 파일 보여줘"
- "실패한 프롬프트만 찾아줘"
- "재사용 가능한 프롬프트 보여줘"
- "토큰을 많이 쓴 세션 찾아줘"
```

---

## 6.9 대시보드

### 기능 설명

사용자는 진행 중인 세션과 작업 상태를 대시보드 형식으로 볼 수 있어야 한다.

### 대시보드 형태

초기 버전은 로컬 HTML 대시보드로 제공한다.

```text
/context-relay/dashboard/index.html
```

또는 Claude Code가 생성하는 정적 HTML로 시작할 수 있다.

### 대시보드 주요 영역

#### 1. 프로젝트 요약

```text
- 프로젝트명
- 현재 브랜치
- 마지막 세션 시간
- 진행 중 task 수
- 완료 task 수
- 위험 task 수
- 총 세션 수
- 총 프롬프트 수
- 총 작업 시간
- 총 토큰 사용량
```

#### 2. 현재 진행 Task 카드

각 작업을 카드로 표시한다.

```text
[In Progress] 결제 후 다운로드 링크 발송
- 사용 도구: Claude Code, Cursor
- 사용 에이전트: PM, Developer, QA
- 작업 시간: 2h 14m
- 토큰 사용량: 128K
- 변경 파일: 7개
- 위험도: 높음
- 다음 액션: webhook 실패 재시도 테스트 작성
```

#### 3. 세션 타임라인

```text
2026-07-05 10:20 Claude Code - PRD 정리
2026-07-05 11:40 Cursor - UI 수정
2026-07-05 13:10 Codex - webhook 구현
```

#### 4. 프롬프트 라이브러리

프롬프트를 시간순으로 보여주고, 결과와 연결한다.

```text
Prompt → AI Response Summary → Changed Files → Result Score
```

#### 5. 히트맵

다음 데이터를 히트맵으로 시각화한다.

```text
- 날짜별 작업량
- 날짜별 토큰 사용량
- 파일별 변경 빈도
- task별 작업 밀도
- 에이전트별 활동량
```

#### 6. 위험 파일 지도

자주 수정되거나 핵심 로직에 가까운 파일을 표시한다.

```text
- 위험도 높음: payment/webhook.ts
- 위험도 중간: email/template.ts
- 위험도 낮음: ui/Button.tsx
```

#### 7. GitHub 상태

```text
- 현재 브랜치
- 마지막 커밋
- uncommitted changes
- open PR
- 최근 커밋 목록
- 변경 파일 수
```

---

## 6.10 히트맵

### 기능 설명

사용자가 프로젝트의 작업 밀도를 한눈에 볼 수 있도록 히트맵을 제공한다.

### 히트맵 유형

#### 1. 날짜별 작업 히트맵

```text
날짜별 세션 수, 작업 시간, 토큰 사용량 표시
```

#### 2. 파일 변경 히트맵

```text
어떤 파일이 자주 변경되는지 표시
```

#### 3. Task 집중도 히트맵

```text
특정 task에 얼마나 많은 세션과 토큰이 투입되었는지 표시
```

#### 4. 에이전트 활동 히트맵

```text
PM, Developer, QA, Refactor Agent 등 에이전트별 활동량 표시
```

### 목적

히트맵은 단순 시각화가 아니라 병목 감지를 위한 장치다.

```text
- 특정 파일만 지나치게 자주 바뀌는가?
- 특정 task가 너무 오래 걸리는가?
- 특정 에이전트가 과도하게 많은 토큰을 쓰는가?
- 최근 작업이 PRD 핵심 영역에 집중되고 있는가?
```

---

## 6.11 GitHub 관리

### 기능 설명

Context Relay는 GitHub 작업 흐름과 연결되어야 한다.

### MVP 기능

```text
- 현재 브랜치 확인
- git status 요약
- git diff 요약
- git log 요약
- 커밋 후보 메시지 생성
- PR 설명 초안 생성
- 변경 파일별 요약
```

### 확장 기능

```text
- GitHub Issue와 task 연결
- PR과 session 연결
- commit hash와 세션 연결
- 특정 PR에 사용된 프롬프트 조회
- 배포 전 체크리스트 생성
```

### 커밋 메시지 예시

```text
feat(payment): add download token generation after successful checkout

- add webhook handling for payment completion
- create download token draft
- prepare email link flow
- add follow-up task for token expiration test
```

### PR 설명 초안 예시

```markdown
## Summary
This PR adds the first implementation of the post-payment download token flow.

## Changes
- Added payment webhook handling
- Added download token creation logic
- Prepared email delivery flow

## Not Completed
- Token expiration test
- Real payment webhook verification
- Email retry handling

## Related Context
See `/context/handoff.md` and session #12 in Context Relay.
```

---

## 6.12 인계 문서 생성

### 기능 설명

DB에 저장된 세션 데이터를 바탕으로 사람이 읽을 수 있는 Markdown 인계 문서를 생성한다.

### 생성 파일

```text
/context/handoff.md
/context/next-session-prompt.md
/context/daily-worklog.md
/context/decision-log.md
/context/risk-notes.md
/context/prompt-library.md
```

### handoff.md 구조

```markdown
# Handoff

## 현재 프로젝트 상태
...

## 마지막 작업 목표
...

## 완료된 작업
...

## 미완료 작업
...

## 변경된 주요 파일
...

## 중요한 결정 사항
...

## 위험 요소
...

## 다음 세션에서 바로 할 일
...

## 다음 세션 추천 프롬프트
...
```

---

## 6.13 다음 세션 프롬프트 생성

### 기능 설명

다음 AI 도구에 그대로 붙여 넣을 수 있는 프롬프트를 생성한다.

### 예시

```markdown
당신은 이 프로젝트의 다음 개발 세션을 이어받는다.

먼저 아래 문서를 읽어라.

1. /context/project-charter.md
2. /context/handoff.md
3. /context/decision-log.md
4. /context/risk-notes.md
5. PRD.md
6. TASKS.md

이번 세션의 목표:
결제 완료 후 다운로드 토큰 생성 로직을 완성하고 테스트한다.

주의:
- payment webhook 응답 형식은 바꾸지 말 것.
- auth/session.ts는 이번 작업 범위가 아니다.
- token 만료 정책은 기존 PRD 기준을 따른다.

작업 순서:
1. 현재 webhook route 확인
2. token 생성 함수 검토
3. token 만료 테스트 작성
4. 이메일 템플릿 연결 확인
5. 변경 파일과 테스트 결과 보고

완료 기준:
- 테스트 통과
- 변경 파일 목록 보고
- PRD와 달라진 점이 있으면 별도 보고
```

---

## 6.14 토큰 사용량 및 작업 시간 추적

### 기능 설명

각 세션별 사용 에이전트, 토큰 소모량, 작업 시간을 기록한다.

### 추적 항목

```text
- tool_name
- agent_name
- started_at
- ended_at
- duration_sec
- token_input
- token_output
- token_total
- estimated_cost
- files_changed_count
- prompts_count
- result_score
```

### 목적

```text
- 어떤 작업이 토큰을 많이 쓰는지 파악
- 어떤 에이전트가 비효율적인지 확인
- 반복되는 실패 프롬프트 확인
- 비용 대비 산출물 품질 분석
```

---

## 6.15 에이전트 사용 기록

### 기능 설명

각 작업이나 세션에서 어떤 에이전트가 사용되었는지 기록한다.

### 에이전트 예시

```text
- Project PM
- Product Planner
- Frontend Developer
- Backend Developer
- QA Agent
- Refactor Agent
- Docs Agent
- Deployment Agent
```

### 기록 예시

```text
Task: 결제 후 다운로드 링크 발송

사용 에이전트:
1. Project PM
   - 역할: 범위 설정, 작업 순서 결정
   - 사용 시간: 12분
   - 토큰: 18K

2. Backend Developer
   - 역할: webhook route 구현
   - 사용 시간: 41분
   - 토큰: 64K

3. QA Agent
   - 역할: 테스트 케이스 작성
   - 사용 시간: 19분
   - 토큰: 26K
```

---

# 7. 사용자 시나리오

## 7.1 최초 프로젝트 셋업

사용자는 프로젝트 루트에서 다음 명령을 실행한다.

```text
/context-relay setup
```

Context Relay는 사용자에게 프로젝트 목표, MVP 범위, 사용할 도구, 기술 스택, 배포 목표, 완료 기준을 질문한다.

그 후 다음을 생성한다.

```text
- project-charter.md
- PRD.md
- TASKS.md
- CLAUDE.md
- AGENTS.md
- Cursor Rules
- SQLite DB
- context 기본 문서
- dashboard 기본 파일
```

이후 모든 AI 코딩 도구는 같은 기준 문서를 읽고 작업한다.

---

## 7.2 세션 시작

사용자가 Claude Code를 실행한다.

Claude Code는 `CLAUDE.md`의 Context Relay Protocol에 따라 다음 문서를 읽는다.

```text
/context/project-charter.md
/context/handoff.md
/context/decision-log.md
/context/risk-notes.md
/context/next-session-prompt.md
```

그 후 현재 해야 할 작업을 요약한다.

---

## 7.3 작업 진행

사용자는 Claude Code, Cursor, Codex 중 원하는 도구로 작업한다.

작업 중 다음 데이터가 기록된다.

```text
- 사용 프롬프트
- 사용 도구
- 사용 에이전트
- 작업 시간
- 변경 파일
- 구현 결과 요약
- 토큰 사용량
```

---

## 7.4 세션 종료

사용자는 Context Relay capture를 실행한다.

시스템은 다음을 수행한다.

```text
1. git status 확인
2. git diff 요약
3. 변경 파일 분석
4. 프롬프트와 구현 결과 연결
5. 완료/미완료 작업 분리
6. decision-log 후보 추출
7. risk-notes 후보 추출
8. SQLite DB 저장
9. FTS5 검색 인덱스 갱신
10. Markdown 인계 문서 갱신
11. 대시보드 데이터 갱신
```

---

## 7.5 다음 도구에서 이어가기

사용자는 Cursor나 Codex를 연다.

`AGENTS.md` 또는 Cursor Rules에 따라 다음 문서를 읽는다.

```text
/context/project-charter.md
/context/handoff.md
/context/next-session-prompt.md
```

AI는 이전 세션의 맥락을 이어받아 작업을 계속한다.

---

# 8. 명령어 설계

## 8.1 setup

```text
/context-relay setup
```

프로젝트의 공통 작업 헌법과 도구별 지침 파일, DB, 대시보드를 모두 생성한다.

## 8.2 init

```text
/context-relay init
```

프로젝트에 Context Relay 기본 구조를 생성한다.

## 8.3 capture

```text
/context-relay capture
```

현재 세션의 변경 내역과 작업 맥락을 저장한다.

## 8.4 handoff

```text
/context-relay handoff
```

다음 세션 인계 문서를 생성한다.

## 8.5 resume

```text
/context-relay resume
```

다음 세션에서 사용할 프롬프트를 생성한다.

## 8.6 search

```text
/context-relay search "download token"
```

SQLite FTS5/BM25 기반으로 세션, 프롬프트, 결정 사항, 파일 변경 내역을 검색한다.

## 8.7 dashboard

```text
/context-relay dashboard
```

로컬 대시보드 데이터를 생성하거나 정적 HTML을 업데이트한다.

## 8.8 prompt-library

```text
/context-relay prompts
```

프롬프트 라이브러리를 생성하거나 조회한다.

## 8.9 github-summary

```text
/context-relay github-summary
```

git status, diff, log를 기반으로 커밋 메시지와 PR 설명 초안을 생성한다.

---

# 9. 데이터 흐름

```text
Project Setup
    ↓
Project Charter / PRD / TASKS / Tool Rules 생성
    ↓
AI Tool Session
    ↓
Prompt / Response Summary / File Change / Git Diff
    ↓
Context Relay Capture
    ↓
SQLite DB 저장
    ↓
FTS5 검색 인덱스 갱신
    ↓
Markdown 인계 문서 생성
    ↓
Dashboard 데이터 생성
    ↓
다음 AI 세션에서 handoff 읽기
```

---

# 10. 대시보드 상세 설계

## 10.1 첫 화면

```text
프로젝트명
현재 브랜치
마지막 세션
현재 진행 task
위험도 높은 task
총 세션 수
총 프롬프트 수
총 작업 시간
총 토큰 사용량
```

## 10.2 Task Board

칸반 형식으로 표시한다.

```text
Not Started | In Progress | Blocked | Needs Review | Completed
```

각 카드에는 다음을 표시한다.

```text
- 제목
- 상태
- 사용 도구
- 사용 에이전트
- 작업 시간
- 토큰 사용량
- 위험도
- 다음 액션
```

## 10.3 Prompt Timeline

프롬프트를 시간순으로 표시한다.

```text
시간 → 도구 → 프롬프트 → 결과 요약 → 변경 파일 → 성공 점수
```

## 10.4 Session Timeline

도구별 세션 흐름을 표시한다.

```text
Claude Code → Cursor → Codex → Claude Code
```

## 10.5 Heatmap

다음 기준으로 히트맵을 생성한다.

```text
- 날짜별 작업량
- 파일별 변경 빈도
- task별 토큰 사용량
- 에이전트별 활동량
```

## 10.6 Search Panel

검색창에서 다음 질의를 지원한다.

```text
- "결제 관련 프롬프트"
- "실패한 디버깅 세션"
- "Cursor에서 수정한 파일"
- "토큰 많이 쓴 작업"
- "리팩토링 관련 결정"
```

---

# 11. 품질 기준

## 11.1 좋은 project-charter의 기준

```text
1. 프로젝트 목표가 한 문장으로 명확하다.
2. MVP 범위가 구체적이다.
3. 하지 않을 것이 명확하다.
4. 완료 기준이 검증 가능하다.
5. 모든 AI 도구가 따라야 할 공통 규칙이 있다.
6. 위험 영역이 명시되어 있다.
```

## 11.2 좋은 handoff의 기준

```text
1. 다음 AI가 바로 작업을 이어갈 수 있다.
2. 완료/미완료가 명확하다.
3. 변경 파일과 변경 이유가 연결되어 있다.
4. PRD와의 관련성이 표시된다.
5. 위험 파일과 수정 금지 영역이 표시된다.
6. 다음 액션이 3~5개로 구체적이다.
```

## 11.3 좋은 프롬프트 기록의 기준

```text
1. 프롬프트 원문이 보존된다.
2. 어떤 도구에서 사용했는지 표시된다.
3. 어떤 결과가 나왔는지 연결된다.
4. 어떤 파일이 바뀌었는지 연결된다.
5. 재사용 가능 여부가 표시된다.
```

## 11.4 좋은 대시보드의 기준

```text
1. 현재 프로젝트 상태를 10초 안에 파악할 수 있다.
2. 지금 진행 중인 task가 명확하다.
3. 병목 task와 위험 파일이 보인다.
4. 이전 프롬프트와 결과를 쉽게 찾을 수 있다.
5. 다음 세션에서 무엇을 해야 하는지 명확하다.
```

---

# 12. 보안 및 민감정보 처리

## 12.1 민감정보 마스킹

다음 패턴은 저장 또는 출력 시 마스킹한다.

```text
API_KEY
SECRET
TOKEN
PASSWORD
PRIVATE_KEY
ACCESS_KEY
.env
```

## 12.2 git diff 분석 주의

git diff에 민감정보가 포함될 수 있으므로, Context Relay는 저장 전 필터링을 수행한다.

## 12.3 로컬 우선 원칙

MVP에서는 모든 데이터가 로컬 SQLite DB에 저장된다.

```text
- 외부 서버 전송 없음
- 로컬 프로젝트 단위 저장
- 사용자가 원할 때만 export
```

---

# 13. MVP 범위

## 13.1 포함

```text
- Project Setup / Context Bootstrapping
- project-charter.md 생성
- PRD.md / TASKS.md 생성 또는 보완
- CLAUDE.md / AGENTS.md / Cursor Rules 지침 생성
- SQLite DB 생성
- 세션 기록
- 프롬프트 기록
- git status / diff / log 요약
- handoff.md 생성
- next-session-prompt.md 생성
- decision-log.md 생성
- risk-notes.md 생성
- FTS5 검색
- 기본 HTML 대시보드
- 현재 task 카드
- 토큰/작업시간 수동 또는 반자동 기록
```

## 13.2 제외

```text
- 모든 도구의 내부 세션 로그 완전 자동 수집
- 클라우드 동기화
- 팀 협업 권한 관리
- GitHub API 완전 연동
- 실시간 토큰 자동 계측
- IDE 플러그인 개발
- 벡터 DB 기반 의미 검색
```

---

# 14. 향후 확장

## 14.1 GitHub 연동 강화

```text
- Issue ↔ Task 연결
- PR ↔ Session 연결
- Commit ↔ Prompt 연결
- Release note 자동 생성
```

## 14.2 벡터 검색 추가

FTS5/BM25 이후, 필요하면 벡터 검색을 추가한다.

```text
- 유사 프롬프트 검색
- 유사 버그 검색
- 과거 결정 사항 추천
```

## 14.3 팀 대시보드

```text
- 여러 개발자 세션 통합
- 에이전트별 생산성 비교
- 프로젝트별 토큰 비용 분석
```

## 14.4 자동 캡처

```text
- shell hook
- git hook
- post-commit hook
- IDE extension
- Claude Code 종료 시 자동 capture
```

---

# 15. 성공 지표

## 15.1 정량 지표

```text
- 세션 재시작 준비 시간 50% 이상 감소
- 이전 프롬프트 검색 시간 70% 이상 감소
- 미완료 task 누락률 감소
- PRD 이탈 작업 조기 발견률 증가
- 동일 설명 반복 입력 감소
- 프로젝트 셋업 후 도구 간 작업 기준 불일치 감소
```

## 15.2 정성 지표

```text
- 사용자가 "어디까지 했더라?"를 덜 묻는다.
- 다음 AI 세션이 프로젝트를 다시 해석하지 않는다.
- 변경 이유와 결정 사항이 남는다.
- 프롬프트와 구현 결과가 연결된다.
- 작업 흐름이 하나의 스토리로 보인다.
- Claude Code, Cursor, Codex가 같은 프로젝트 헌법을 읽고 움직인다.
```

---

# 16. 최종 제품 포지셔닝

Context Relay는 단순한 로그 도구가 아니다.

이 제품은 AI 개발 세션의 기억 상실을 막는 **프로젝트 맥락 운영 시스템**이다.

```text
AI 코딩 도구는 점점 많아진다.
하지만 프로젝트의 기억은 흩어진다.

Context Relay는 프로젝트 시작 시 공통 헌법을 세우고,
작업 중 흩어진 기억을 모아,
다음 세션이 바로 이어 달릴 수 있게 만든다.
```

---

# 17. 최종 한 줄

**Context Relay는 Claude Code, Cursor, Antigravity, Codex를 오가며 작업해도 프로젝트의 목표, 판단, 프롬프트, 변경 이력, 현재 task, 다음 행동을 잃지 않게 해주는 AI 개발 블랙박스다.**
