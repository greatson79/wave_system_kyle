# GitHub Guide — `/context-relay github-summary` 실행 절차

> SKILL.md의 `github-summary` 서브커맨드가 이 문서를 로드한다.
> 인터페이스 계약은 `references/architecture.md`(SSOT)를 따른다.
> 표기: `<skill>` = 스킬 루트 경로. 커맨드는 대상 프로젝트 루트에서 실행한다.

절차: 상태 수집 → 요약 보고 → 커밋 메시지 생성 → PR 설명 초안 → 커밋 후 이벤트 기록.

---

## 1. 상태 수집

```bash
python3 <skill>/scripts/cr.py git info --json
```

- 저장 없이 현재 git 상태를 JSON으로 출력: `branch`, `last_commit`, `dirty_count`, `recent_commits`(5개), `changed_files[]`.
- git 미설치·비저장소면 경고 후 exit 0 — 사용자에게 "git 저장소가 아니라 github-summary를 수행할 수 없다"고 보고하고 종료한다.
- 커밋 메시지·PR 본문의 판단 재료로 raw diff가 필요하면 직접 확인한다:

```bash
git diff --stat
git diff            # 변경 내용 정밀 확인 (필요한 파일만)
git log --oneline -10
```

## 2. 상태 요약 보고 형식

수집 결과를 먼저 사용자에게 요약한다:

```text
GitHub 상태 — <branch>

- 마지막 커밋: <hash 앞 7자> <제목> (<시각>)
- uncommitted 변경: n개 파일
  - src/payment/webhook.ts (modified)
  - src/lib/token.ts (added)
- 최근 커밋 5건: <목록>
```

uncommitted 변경이 0건이면 커밋 메시지 생성은 건너뛰고, 최근 커밋 기준 PR 초안(4)만 진행할지 사용자에게 확인한다.

## 3. 커밋 메시지 생성 규칙

Conventional Commits 형식(PRD §6.11 예시 준수):

```text
<type>(<scope>): <subject>

- <실제 diff에서 확인된 변경 1>
- <실제 diff에서 확인된 변경 2>
- <후속 작업이 있으면: add follow-up task for ...>
```

규칙:

- `type` ∈ {feat, fix, refactor, docs, test, chore, perf, build}. 변경의 주된 성격 1개만.
- `scope`: 변경이 집중된 도메인·최상위 디렉터리(예: payment, auth, dashboard). 전역 변경이면 생략 가능.
- `subject`: 영어 명령형 현재시제, 소문자 시작, 마침표 없음, 72자 이내.
- **본문 불릿은 실제 diff 기반만**: `git diff`/`changed_files`에서 직접 확인한 변경만 쓴다. diff에 없는 내용, 확인하지 않은 효과, 가짜 수치 금지.
- 민감정보(키·토큰·내부 URL)가 메시지에 들어가지 않는지 확인한다.
- 서로 무관한 변경이 섞여 있으면(예: 결제 로직 + 문서 오타) 하나의 메시지로 뭉개지 말고 **커밋 분리를 제안**한다.

PRD §6.11 예시:

```text
feat(payment): add download token generation after successful checkout

- add webhook handling for payment completion
- create download token draft
- prepare email link flow
- add follow-up task for token expiration test
```

메시지는 **초안으로 제시**한다. 커밋 실행은 사용자가 요청한 경우에만 수행한다.

## 4. PR 설명 초안

PRD §6.11 예시 구조를 따른다:

```markdown
## Summary
<이 PR이 무엇을 구현·변경하는지 1~3문장>

## Changes
- <diff 기반 변경 사항>
- <diff 기반 변경 사항>

## Not Completed
- <이번 PR에 포함되지 않은 미완료 항목>

## Related Context
See `/context/handoff.md` and session #N in Context Relay.
```

작성 재료:

- **Summary / Changes**: 1의 diff·커밋 목록에서. 추측 금지.
- **Not Completed**: 미완료 항목은 DB에서 근거를 가져온다.

```bash
python3 <skill>/scripts/cr.py task list --status in_progress --json
python3 <skill>/scripts/cr.py task list --status blocked --json
```

`context/handoff.md`의 "미완료 작업" 섹션과 대조해 이 PR 범위와 겹치는 항목만 넣는다.

- **Related Context의 세션 번호**: 이 PR 작업이 이루어진 세션 id를 넣는다.

```bash
python3 <skill>/scripts/cr.py session list --limit 5 --json
```

## 5. 커밋 후 이벤트 기록

사용자가 커밋을 실행했다면, 커밋 hash·브랜치를 세션과 연결해 남긴다:

```bash
python3 <skill>/scripts/cr.py git capture --session N
```

- `git_events`에 commit_hash, branch_name, diff 요약이 저장된다(자유 텍스트는 저장 시 자동 마스킹).
- `N`은 이 작업이 속한 세션 id. capture 프로토콜(①)에서 커밋 **전** 상태를 이미 기록했더라도, 커밋 **후** 다시 실행하면 hash가 담긴 새 이벤트 행이 추가되어 "커밋 전 dirty 상태 → 커밋 완료" 흐름이 남는다.
- 커밋 전 `files_changed`를 이미 기록했다면 `--files`는 반복하지 않는다(커밋 직후 working tree가 clean이면 생성할 행도 없다).

## 6. 최종 보고 형식

```text
github-summary 완료

- 브랜치: <branch> / uncommitted: n개
- 커밋 메시지 초안: 1건 (또는 분리 제안 n건)
- PR 설명 초안: 작성 (Not Completed n항목, 세션 #N 연결)
- git_events 기록: <실행 여부>
```

---

## 향후 (비 MVP — 참고 수준 opt-in)

MVP는 GitHub API 완전 연동을 하지 않는다(architecture §9). 아래는 **`gh` CLI가 설치되어 있고 사용자가 원할 때만** 읽기 전용으로 참고한다. 실패해도 무시하고 진행한다(파이프라인 필수 요소 아님):

```bash
gh pr list --limit 10        # open PR 목록 참고
gh pr view <번호>            # PR 본문 참고
```

다음 항목은 향후 확장(PRD §14.1)이며 이 절차서의 범위 밖이다: Issue↔Task 연결, PR↔Session 연결 자동화, Commit↔Prompt 연결, Release note 자동 생성, 배포 전 체크리스트 생성.
