# Handoff Guide — handoff / resume / prompts 절차

> `/context-relay handoff`, `/context-relay resume`, `/context-relay prompts` 실행 시 이 문서를 따른다.
> 커맨드·플래그는 `references/architecture.md` §3.1 계약과 글자 단위로 일치해야 한다.
> `<skill>` 은 스킬 설치 경로(예: `~/.claude/skills/context-relay`)를 뜻한다.

## 0. 공통 원칙

- 저장·검색·집계는 `cr.py`, 판단·요약·문장 생성은 Claude (architecture §2).
- Claude 는 SQL 을 직접 쓰지 않고 항상 `cr.py` CLI 를 경유한다.
- 생성 문서는 전부 대상 프로젝트의 `context/` 아래에 쓴다.
- DB 미초기화(exit 2)면 먼저 `/context-relay init` 을 안내하고 중단한다.

## 1. 데이터 수집

기본 번들 1회 호출:

```bash
python3 <skill>/scripts/cr.py recent --json
```

`recent` 번들 구성 (architecture §3.1) 과 handoff 반영처:

| 구성 요소 | 내용 | 반영처 |
|---|---|---|
| project | 프로젝트명·루트 경로 | 문서 헤더 |
| 최근 세션 N개 | 각 세션의 프롬프트 수 포함 | 마지막 작업 목표, 완료/미완료 |
| 최근 프롬프트 | prompt_text, result_summary 등 | 추천 프롬프트, prompt-library |
| 최근 변경 파일 | file_path, change_type, change_summary, risk_level | 변경된 주요 파일 |
| open task 전부 | status, current_next_action, prd_reference | 미완료 작업, 다음 할 일 |
| 최근 결정 10 | decision_text, reason, impact | 중요한 결정 사항 |
| risk 전부 | risk_text, risk_level, related_file | 위험 요소 |
| stats 요약 | 세션/토큰/시간 총계 | 현재 프로젝트 상태 |

보조 조회 (필요할 때만):

```bash
python3 <skill>/scripts/cr.py stats --json        # task 상태별 수, 날짜별 집계, 파일 변경 top 20
python3 <skill>/scripts/cr.py git info --json     # branch, last_commit, dirty_count, recent_commits, changed_files (저장 없음)
python3 <skill>/scripts/cr.py session list --limit 30 --json
python3 <skill>/scripts/cr.py task list --status completed --json   # §2.3 완료 근거 (c) — recent 번들은 open task만 담는다
python3 <skill>/scripts/cr.py decision list --limit 30 --json
python3 <skill>/scripts/cr.py risk list --json
```

## 2. handoff.md 생성 — 9개 섹션

`templates/handoff.md` 구조(PRD §6.12)를 그대로 따른다. 섹션별 작성법:

1. **현재 프로젝트 상태** — stats(총 세션·task 상태별 수) + `git info` (브랜치, uncommitted 수)로 2~4문장. "무엇이 동작하고 무엇이 미완인지"가 한눈에 보여야 한다.
2. **마지막 작업 목표** — 가장 최근 세션의 session_goal / user_request 를 옮긴다. 여러 세션이 같은 task 에 연결돼 있으면 task 단위 목표로 승격해 적는다.
3. **완료된 작업** — 분리 기준: (a) 세션 summary 에 완료로 명시, (b) status=completed 세션의 산출, (c) 대응 task 의 status 가 completed 또는 ready_to_test. 세 근거 중 하나 이상을 갖춘 항목만 완료로 적는다.
4. **미완료 작업** — (a) task status 가 in_progress / blocked / needs_review, (b) 세션 summary 에 미완료·실패·보류 언급, (c) status=failed / paused / abandoned 세션의 목표. **애매하면 미완료로 분류한다** (다음 세션이 놓치는 것보다 재확인이 싸다). blocked task 는 blocker 를 함께 표기.
5. **변경된 주요 파일** — 파일과 변경 이유를 반드시 연결한다. 번들의 file_path + change_type + change_summary 사용. change_summary 가 비어 있으면 같은 session_id 의 세션 summary 나 프롬프트 result_summary 에서 이유를 찾아 연결한다. 형식: `- <경로> (<change_type>) — <이유>` + risk_level 이 있으면 배지. 전체 나열 대신 위험도 높은 파일 우선으로 핵심만.
6. **중요한 결정 사항** — 결정 10건에서 decision_text + reason 을 각 1줄로. 상세는 decision-log.md 링크.
7. **위험 요소** — risk 전부를 risk_level 내림차순으로. related_file 이 있으면 "수정 금지/주의 파일" 로 명시 (PRD §11.2 기준 5).
8. **다음 세션에서 바로 할 일** — open task 의 current_next_action 을 **3~5개 구체 항목**으로 (PRD §11.2 기준 6). 각 항목 뒤에 PRD 관련성 표기.
9. **다음 세션 추천 프롬프트** — §5 resume 절차로 생성할 next-session-prompt.md 의 요약판 또는 파일 링크.

**PRD 관련성 표시법 (공통)**: 완료/미완료/다음 할 일 항목 뒤에 `(PRD §x.y)` 를 붙인다. 근거는 `tasks.prd_reference` 컬럼만 사용하고, 값이 없으면 표기하지 않는다 — 추측 매핑 금지.

### 완료 전 자가 점검 체크리스트 (PRD §11.2 — 전부 예여야 완료 선언)

- [ ] 1. 다음 AI 가 이 문서만 읽고 바로 작업을 이어갈 수 있는가?
- [ ] 2. 완료/미완료가 명확히 분리되어 있는가?
- [ ] 3. 변경 파일과 변경 이유가 연결되어 있는가?
- [ ] 4. PRD 와의 관련성이 표시되어 있는가?
- [ ] 5. 위험 파일과 수정 금지 영역이 표시되어 있는가?
- [ ] 6. 다음 액션이 3~5개로 구체적인가?

하나라도 아니오면 해당 섹션을 보강한 뒤 재점검한다.

## 3. 부속 문서 갱신 (handoff 와 함께 수행)

### 3.1 daily-worklog.md — 삽입 (기존 내용 보존, 템플릿 골격 준수)

- 파일 전체를 다시 쓰지 않는다. 기존 날짜 섹션을 절대 삭제·수정하지 않는다.
- 오늘 날짜 섹션(`## YYYY-MM-DD`)이 없으면 제목·안내 인용문 바로 아래(기존 날짜 섹션들보다 위)에 새로 삽입한다 — **최신 날짜가 위**. 이미 있으면 그 섹션 끝에 세션 항목만 추가한다.
- 세션 항목은 `templates/daily-worklog.md` 골격을 그대로 쓴다: `### HH:MM · <도구> · 세션 N` 헤딩 + 목표/결과/상태/작업 시간/토큰 5개 불릿.

### 3.2 decision-log.md — 전체 재생성

- `python3 <skill>/scripts/cr.py decision list --json` 결과로 사람이 읽는 형식으로 재생성 (DB 가 원천이므로 재생성해도 소실 없음).
- 항목: 날짜 · 결정(decision_text) · 이유(reason) · 영향(impact) · 재검토 조건(revisit_condition) · 기록 세션 id. 최신이 위.

### 3.3 risk-notes.md — 전체 재생성

- `python3 <skill>/scripts/cr.py risk list --json` 결과로 재생성. high → medium → low 그룹.
- 항목: 위험 내용(risk_text) · 관련 파일(related_file) · 완화책(mitigation) · 기록 세션 id.
- high 그룹 상단에 "수정 금지/주의 파일" 목록을 뽑아 강조한다.

## 4. Task Story 재구성 (PRD §6.5)

여러 세션에 걸친 task 를 하나의 스토리로 묶는다.

1. `python3 <skill>/scripts/cr.py session list --json` 으로 세션 전체(필요시 `--limit` 상향) 조회.
2. `linked_task_id` 로 세션을 그룹핑. task 메타는 `python3 <skill>/scripts/cr.py task list --json`.
3. task 별로 관련 세션을 시간순 정렬하고 summary 를 진행 단계로 재구성.
4. PRD §6.5 예시 구조로 작성:

```markdown
# Task Story: <task title>

## 시작 배경
## 관련 세션        ← "YYYY-MM-DD <도구>" 목록
## 진행 내용        ← 번호 목록, 시간순
## 현재 상태        ← 완료 / 부분 완료 / 진행 중 / 차단
## 남은 작업
## 위험 요소
```

- 배치: 기본은 handoff.md 하단 부록(`## 부록: Task Story`)에 진행 중 핵심 task 1~2개만. 사용자가 요청하면 `context/task-story-<task_id>.md` 로 별도 생성.
- `linked_task_id` 가 비어 있는 세션은 스토리에서 제외하되 handoff 세션 요약에는 포함하고, capture 시 task 연결을 권장한다.

## 5. resume — next-session-prompt.md 생성

전제: 최신 handoff.md 가 있어야 한다. 없거나 마지막 세션 이후 갱신되지 않았으면 먼저 §2 handoff 절차를 수행한다.

PRD §6.13 구조를 그대로 따른다:

1. **읽을 문서 목록** (6개 고정): `/context/project-charter.md`, `/context/handoff.md`, `/context/decision-log.md`, `/context/risk-notes.md`, `PRD.md`, `TASKS.md`
2. **이번 세션의 목표** — handoff "다음 세션에서 바로 할 일" 의 최상위 항목을 1~2문장으로.
3. **주의** — risk-notes 기반: 수정 금지 파일, 바꾸면 안 되는 계약/응답 형식, 범위 밖 영역.
4. **작업 순서 5단계** — 현재 상태 확인 → 구현/수정 → 테스트 → 연결 확인 → 변경 파일과 결과 보고 흐름으로 구체화.
5. **완료 기준 3개** — 검증 가능한 것만 (예: 테스트 통과 / 변경 파일 목록 보고 / PRD 와 달라진 점 별도 보고).

**자기완결성 기준**: 이 파일 하나를 Cursor / Codex / Antigravity 에 그대로 붙여넣었을 때, 그 도구가 프로젝트를 처음 봐도 무엇을 읽고, 무엇을 하고, 무엇을 보고할지 알 수 있어야 한다. 대명사("그 파일", "아까 그 버그") 금지. 경로는 프로젝트 루트 기준으로 명시.

## 6. prompts — prompt-library.md 재생성

1. 조회:

```bash
python3 <skill>/scripts/cr.py prompt list --json                 # 기본 전체
python3 <skill>/scripts/cr.py prompt list --reuse-only --json    # 재사용 후보만
python3 <skill>/scripts/cr.py prompt list --type debugging --json
python3 <skill>/scripts/cr.py prompt list --session 12 --json
```

2. `context/prompt-library.md` 를 전체 재생성한다. PRD §6.4 출력 예시 형식:

```markdown
# Prompt Library

## YYYY-MM-DD

### Prompt NNN

도구: <tool_name>
유형: <prompt_type>
목표: <프롬프트 의도 1줄 — Claude 가 prompt_text 에서 추출>

#### 프롬프트
<prompt_text>

#### AI 구현 결과
- <result_summary 를 bullet 로 분해>
- <related_files 가 있으면 변경 파일 표기>

#### 재사용 가능성
높음 | 중간 | 낮음 | 미평가

#### 개선 메모
<success_score 가 낮거나 결과가 부분 실패일 때만>
```

- 재사용 가능성 판정: `reuse_candidate=1` → 높음. 아니면 success_score 4~5 → 중간, 1~2 → 낮음, 점수 없음 → 미평가. 가짜 평가를 만들지 않는다.
- 기본 정렬: 날짜 내림차순, 같은 날짜 안에서는 시간순.
- 사용자가 "재사용 후보 우선" 을 요청하면: `reuse_candidate=1` 그룹을 문서 상단 `## 재사용 후보` 섹션으로 먼저 배치하고, 나머지를 날짜별로 이어 붙인다.
- config.json 의 `store_prompt_full_text` 가 false 인 프로젝트에서는 prompt_text 가 이미 요약본이므로 문서 헤더에 그 사실을 명시한다.
