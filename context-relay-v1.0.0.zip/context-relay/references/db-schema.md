# DB Schema Reference — context-relay.sqlite

> 원본 계약: `references/architecture.md` §4. 이 문서의 DDL 은 계약 전문의 사본이며, 어긋나면 **계약이 우선**한다. 스키마 변경 시 이 문서에 근거를 기록한다.
> 경고: **쓰기는 반드시 `cr.py` CLI 경유** — 직접 INSERT/UPDATE/DELETE 는 마스킹(§3.3)과 FTS 동기화(§3.2)를 건너뛰어 인덱스를 오염시킨다. §5 직접 질의는 읽기 전용 SELECT 만 허용.

## 1. DDL 전문 (architecture §4 — 이대로 구현)

```sql
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
);
-- meta: schema_version='1', fts_enabled='1'|'0'

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  tool_name TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT,
  ended_at TEXT,
  duration_sec INTEGER,
  session_goal TEXT,
  user_request TEXT,
  summary TEXT,
  status TEXT,
  token_input INTEGER DEFAULT 0,
  token_output INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  estimated_cost REAL DEFAULT 0,
  linked_task_id INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  tool_name TEXT,
  agent_name TEXT,
  prompt_text TEXT NOT NULL,
  prompt_type TEXT,
  related_files TEXT,            -- 확장: PRD 6.4 기록 항목 (쉼표 구분 경로)
  result_summary TEXT,
  success_score INTEGER,
  reuse_candidate INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT,
  priority TEXT,
  prd_reference TEXT,
  risk_level TEXT,
  current_next_action TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS files_changed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  change_type TEXT,
  change_summary TEXT,
  risk_level TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  decision_text TEXT NOT NULL,
  reason TEXT,
  impact TEXT,
  revisit_condition TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS risks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  risk_text TEXT NOT NULL,
  risk_level TEXT,
  related_file TEXT,
  mitigation TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS git_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  commit_hash TEXT,
  branch_name TEXT,
  diff_summary TEXT,
  changed_files_count INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  role TEXT,
  tool_name TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS session_agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  agent_id INTEGER NOT NULL,
  duration_sec INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  result_summary TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(id),
  FOREIGN KEY(agent_id) REFERENCES agents(id)
);

CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_prompts_session ON prompts(session_id);
CREATE INDEX IF NOT EXISTS idx_files_session ON files_changed(session_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

-- FTS5 (생성 실패 시 meta.fts_enabled='0' 로 기록하고 LIKE 폴백)
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
  entity_type UNINDEXED,
  entity_id UNINDEXED,
  title,
  body,
  created_at UNINDEXED,
  tokenize = 'unicode61'
);
```

런타임 PRAGMA (architecture §3.4): `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`. 모든 SQL 은 파라미터 바인딩.

## 2. 테이블별 컬럼 설명

공통: 모든 테이블의 `id` 는 AUTOINCREMENT PK. `created_at`(및 `updated_at`)은 로컬 타임존 ISO 8601 초 단위. 자유 텍스트 컬럼은 저장 직전 마스킹(architecture §3.3)이 적용된다.

| 테이블 | 컬럼 | 설명 |
|---|---|---|
| meta | key / value | `schema_version`(마이그레이션 기준), `fts_enabled`('1' FTS5 사용 / '0' LIKE 폴백) |
| projects | name / root_path | 프로젝트명(init `--name`, 기본값 루트 디렉터리명) / 루트 절대 경로 |
| sessions | tool_name / agent_name | 사용 도구(claude-code, cursor, codex, antigravity 등) / 대표 에이전트명 |
| sessions | started_at / ended_at / duration_sec | 시작·종료 시각·소요 초 — `session end` 가 자동 계산 (`--duration-sec` 지정 시 존중) |
| sessions | session_goal / user_request / summary / status | 세션 목표 / 사용자 원요청 / 결과 요약 (자유 텍스트) / status 6종 (§4 어휘 사전) |
| sessions | token_input / token_output / token_total / estimated_cost | 토큰·추정 비용. token_total 은 `session end` 자동 합산 |
| sessions | linked_task_id | tasks 논리 참조 — **FK 선언 없음**. task story 그룹핑 키 |
| prompts | tool_name / agent_name | 미지정 시 세션에서 상속 |
| prompts | prompt_text / prompt_type / related_files | 본문 (`store_prompt_full_text: false` 면 요약본) / 9종 (§4 어휘 사전) / 관련 파일 경로 (쉼표 구분 문자열) |
| prompts | result_summary / success_score / reuse_candidate | 구현 결과 요약 / 1~5 점수 / 재사용 후보 플래그 0·1 |
| tasks | title / description / status / priority | 제목 / 상세 / 6종 (§4 어휘 사전) / low·medium·high |
| tasks | prd_reference | PRD 섹션 참조 — handoff 의 PRD 관련성 표시 근거 |
| tasks | risk_level / current_next_action | low·medium·high / 다음 액션 1줄 (handoff "다음 할 일" 원천) |
| files_changed | file_path / change_type / change_summary / risk_level | 경로 / 4종 (§4 어휘 사전) / 변경 이유 요약 / 위험도 |
| decisions | decision_text / reason / impact / revisit_condition | 결정 내용·이유·영향·재검토 조건 (session_id 는 NULL 허용) |
| risks | risk_text / risk_level / related_file / mitigation | 위험 내용·수준·관련 파일·완화책 (session_id 는 NULL 허용) |
| git_events | commit_hash / branch_name / diff_summary / changed_files_count | HEAD 커밋 / 브랜치 / diff 요약(마스킹 적용) / 변경 파일 수 |
| agents | name / role / tool_name | 에이전트명(예: Backend Developer) / 역할 / 주 사용 도구 |
| session_agents | duration_sec / token_total / result_summary | 세션-에이전트 N:M 연결의 투입 시간·토큰·결과 |
| search_index | entity_type / entity_id / created_at | **UNINDEXED** — 단수형 entity_type(session, prompt, task, decision, risk, file), 원본 행 id, 생성 시각 |
| search_index | title / body | 인덱싱 컬럼 — architecture §3.2 매핑으로 원본에서 조립, add/update 시 즉시 upsert |

## 3. PRD 원안 대비 변경점과 근거

| 변경 | 근거 |
|---|---|
| `meta` 테이블 신설 | schema_version 으로 마이그레이션 대비 + fts_enabled 로 FTS5 불가 환경의 LIKE 폴백 상태를 영속 기록 |
| search_index 의 `entity_type` / `entity_id` / `created_at` 3컬럼 UNINDEXED | 메타컬럼 값(예: "prompt", 숫자 id, 날짜)이 BM25 어휘 통계를 오염시키지 않게 함. 필터는 `WHERE entity_type = ?` 등호 비교로 동일하게 가능 |
| `prompts.related_files` 컬럼 추가 | PRD §6.4 기록 항목(related_files) 대응 — 프롬프트와 변경 파일 연결 |
| 모든 CREATE 에 `IF NOT EXISTS` + 인덱스 4건 추가 | init idempotent 보장 + session/prompt/file 조회와 task 상태 필터 성능 |
| PRD §6.4 의 `implementation_result_id` 미채택 | MVP 에 별도 구현결과 테이블이 없어 `result_summary` + `related_files` 로 대체 (architecture §4 채택안) |
| PRD §6.6 의 `blockers` / `PRD alignment score` 컬럼 미채택 | blocked task 는 status=blocked + current_next_action 으로 표현, PRD 정렬은 prd_reference 배지로 대체 (자동 점수화는 MVP 밖) |
| PRD §6.9-7 의 open PR 미저장 | GitHub API 연동은 PRD §13.2 제외 항목 — gh CLI opt-in 참고 수준만 (github-guide 참조) |

## 4. ERD (텍스트) 와 상태·유형 어휘 사전

```text
projects (1) ──< sessions (N) ──< prompts (N)
    │               │       └──< files_changed (N)
    │               │       └──< session_agents (N) >── (1) agents >── projects
    │               │ linked_task_id ···> tasks   (FK 선언 없는 논리 참조)
    ├──< tasks (N)
    ├──< decisions (N)   ─ session_id ···> sessions (NULL 허용)
    ├──< risks (N)       ─ session_id ···> sessions (NULL 허용)
    ├──< git_events (N)  ─ session_id ···> sessions (NULL 허용)
    └──< agents (N)

meta          독립 (스키마 버전, FTS 가용성)
search_index  파생 인덱스 — (entity_type, entity_id) 로 원본 행 참조
```

| 어휘 | 값 |
|---|---|
| 세션 status (6종) | planned, active, paused, completed, failed, abandoned |
| task status (6종) | not_started, in_progress, blocked, needs_review, ready_to_test, completed (대시보드 표기: Not Started 등) |
| prompt_type (9종) | planning, implementation, debugging, refactoring, testing, deployment, documentation, review, recovery |
| risk_level (3종) | low, medium, high (tasks / files_changed / risks 공통) |
| change_type (4종) | added, modified, deleted, renamed (git porcelain 매핑: M→modified, A/??→added, D→deleted, R→renamed) |
| priority (3종) | low, medium, high |

## 5. 직접 질의 예시 (읽기 전용 SELECT 만 — 쓰기는 반드시 cr.py 경유)

```sql
-- 1. 토큰 상위 세션
SELECT id, tool_name, session_goal, token_total, started_at
FROM sessions ORDER BY token_total DESC LIMIT 10;
-- 2. 가장 자주 바뀐 파일
SELECT file_path, COUNT(*) AS change_count
FROM files_changed GROUP BY file_path
ORDER BY change_count DESC LIMIT 20;
-- 3. task별 투입 시간과 세션 수
SELECT t.id, t.title, t.status,
       SUM(COALESCE(s.duration_sec, 0)) AS total_sec,
       COUNT(s.id) AS session_count
FROM tasks t LEFT JOIN sessions s ON s.linked_task_id = t.id
GROUP BY t.id, t.title, t.status ORDER BY total_sec DESC;
-- 4. 도구별 세션 분포
SELECT tool_name, COUNT(*) AS session_count, SUM(token_total) AS tokens
FROM sessions GROUP BY tool_name ORDER BY session_count DESC;
-- 5. 실패 세션의 프롬프트
SELECT p.id, p.prompt_type, substr(p.prompt_text, 1, 120) AS prompt_head,
       p.result_summary, s.id AS session_id
FROM prompts p JOIN sessions s ON s.id = p.session_id
WHERE s.status = 'failed' ORDER BY p.created_at DESC;
```

## 6. FTS search_index 사용 예 (bm25 / snippet)

PRD §6.8 의 BM25 예시를 UNINDEXED 컬럼 반영해 수정한 형태:

```sql
SELECT
  entity_type,
  entity_id,
  title,
  snippet(search_index, 3, '[', ']', '...', 20) AS snippet,  -- 컬럼 3 = body (인덱싱 컬럼)
  bm25(search_index) AS rank
FROM search_index
WHERE search_index MATCH ?
  AND entity_type = 'prompt'      -- 엔티티 필터: MATCH 안이 아니라 WHERE 등호로
ORDER BY rank
LIMIT 20;
```

- `bm25()` 는 값이 작을수록 관련도가 높다 — `ORDER BY rank` 오름차순 그대로가 맞다.
- **UNINDEXED 컬럼은 MATCH 대상이 아니다**: `entity_type:prompt` 컬럼 필터 문법은 실패한다. 값 저장은 되므로 `WHERE entity_type = ?` 등호 비교와 SELECT 는 정상 동작. `snippet()` 컬럼 인덱스는 정의 순서(0=entity_type … 3=body) 기준이며 하이라이트는 인덱싱 컬럼(2, 3)에만 의미가 있다.
- 인덱스 재구축(복구용): `python3 <skill>/scripts/cr.py reindex`. 평시에는 add/update 시 자동 동기화되므로 불필요.
