# Capture Protocol — `/context-relay capture` 실행 절차

> SKILL.md의 `capture` 서브커맨드가 이 문서를 로드한다.
> 인터페이스 계약은 `references/architecture.md`(SSOT)를 따른다.
> 표기: `<skill>` = 스킬 루트 경로. 커맨드는 대상 프로젝트 루트에서 실행한다.
> 사전 조건: 프로젝트가 초기화되어 있어야 한다(미초기화면 exit 2 → `/context-relay init` 또는 `setup` 먼저 안내).

capture는 PRD §7.4의 11단계를 수행한다. DB 저장(§7.4-8)과 FTS 인덱스 갱신(§7.4-9)은 각 `cr.py` add/update 커맨드에 내장되어 있으므로 별도 단계가 아니다 — 아래 ①~⑦이 곧 저장이고, ⑨~⑪이 문서·대시보드 갱신이다.

시작 전에 `context-relay/config.json`을 Read 하여 `store_prompt_full_text`, `token_tracking` 값을 확인한다.

---

## 모드 판별

| 모드 | 조건 | 세션 기록 방법 |
|---|---|---|
| **A — Claude Code 라이브** | 캡처 대상이 지금 이 Claude Code 대화 자체 | 세션 시작 시 `session start`를 이미 실행했으면 `session end`로 마감. 아니면 `session log`로 일괄 기록 |
| **B — 타 도구 사후 캡처** | 사용자가 Cursor/Codex/Antigravity 등에서 한 작업을 기록 요청 | git diff 분석 + 사용자 문답 → `session log --tool cursor` 등 |

### 모드 A — 재구성 항목

현재 대화를 되짚어 Claude가 직접 재구성한다:

- 세션 목표(`--goal`)와 사용자 최초 요청 원문(`--request`)
- 사용자가 보낸 주요 프롬프트들(③에서 개별 저장)
- 구현 결과 요약, 완료/미완료 분리
- 변경 파일 목록(대화 중 Edit/Write 이력 + git 상태 대조)

### 모드 B — git 분석 + 사용자 질문 (3~5개, AskUserQuestion 1회)

먼저 `python3 <skill>/scripts/cr.py git info --json` 과 필요 시 `git diff --stat`으로 변경 규모를 파악한 뒤 질문한다:

1. 어떤 도구로 작업했는가? (cursor / codex / antigravity / 기타)
2. 이 세션의 목표는 무엇이었는가?
3. 사용한 주요 프롬프트를 붙여넣어 줄 수 있는가? (없으면 요약이라도)
4. 결과는 어떤 상태인가? (completed / failed / paused / abandoned + 미완료 항목)
5. (config `token_tracking`이 `manual`일 때만) 대략의 작업 시간과 토큰 사용량은?

---

## 11단계 프로토콜

**순서 규칙**: 세션 id가 아직 없으면(모드 B, 또는 모드 A인데 `session start` 미실행) ②를 먼저 실행해 id를 확보한 뒤 ①에 `--session N`을 부여한다. 이하 커맨드의 `N`은 그 세션 id다.

### ① git 상태 수집·저장

```bash
python3 <skill>/scripts/cr.py git capture --session N --files
```

- branch/HEAD/status/diff --stat/log -5 를 수집해 `git_events` 1행 저장.
- `--files`: porcelain을 파싱해 `files_changed` 행을 일괄 생성(M→modified, A/??→added, D→deleted, R→renamed). `context-relay/` 하위 경로는 자기 오염 방지를 위해 자동 제외된다.
- git 저장소가 아니면 경고 후 exit 0 — 파이프라인을 중단하지 말고 ②로 진행한다.
- `context-relay/`가 untracked로 계속 잡히면 setup-guide §3.5의 `.gitignore` 블록이 빠진 것이다 — 한 번 추가해 두면 git 통계 노이즈가 사라진다.

### ② 세션 기록

모드 A에서 `session start`를 이미 실행한 경우:

```bash
python3 <skill>/scripts/cr.py session end --id N \
  --summary "webhook route 추가, 토큰 생성 함수 초안. 이메일 발송 미완" \
  --status completed --task 3
```

- `--task`: 세션 시작 시점에 task를 연결하지 못했다면 **여기서 반드시 연결**한다 — 연결이 없으면 대시보드 task 카드의 세션·시간·토큰 집계가 비게 된다.

그 외(모드 A 일괄 / 모드 B):

```bash
python3 <skill>/scripts/cr.py session log --tool cursor \
  --goal "결제 UI 수정" --request "결제 버튼 상태 표시 개선" \
  --summary "버튼 로딩 상태 추가. 에러 토스트 미완" \
  --status completed --task 3 \
  --started-at 2026-07-05T10:20:00+09:00 --ended-at 2026-07-05T11:05:00+09:00
```

- `--status` ∈ {completed, failed, paused, abandoned}. 세션이 이어질 예정이면 paused.
- `--task`로 관련 task id를 연결한다(task id는 `task list --json`으로 확인).
- 출력의 `id=N`을 이후 단계에서 사용한다.

### ③ 프롬프트 저장 (사용자 프롬프트마다 반복)

원문은 `--text-file` 경유(멀티라인 안전). stdin(`--text-file -`) + heredoc 권장:

```bash
python3 <skill>/scripts/cr.py prompt add --session N --type implementation \
  --result "webhook route 수정, download token 생성 함수 추가, 이메일 발송 미완" \
  --score 4 --reuse --files "src/payment/webhook.ts,src/lib/token.ts" \
  --text-file - <<'PROMPT'
(사용자 프롬프트 원문)
PROMPT
```

- `--type` ∈ {planning, implementation, debugging, refactoring, testing, deployment, documentation, review, recovery}.
- `--score` 1~5: 프롬프트가 의도한 결과를 얼마나 냈는가. `--reuse`: 다른 작업에도 재사용할 만한 프롬프트일 때만.
- config `store_prompt_full_text: false`면 원문 대신 Claude가 작성한 요약을 저장한다.
- **민감정보 육안 확인**: cr.py가 저장 직전 자동 마스킹(architecture §3.3)하지만, Claude도 저장 전 원문을 훑어 API 키·비밀번호·고객 개인정보·`.env` 내용이 있으면 해당 부분을 제거하거나 요약으로 대체한 뒤 저장한다. 마스킹은 이중 안전장치이지 면죄부가 아니다.

### ④ 핵심 파일 의미 기록

①의 `--files`는 기계적 목록만 남긴다. 이번 세션의 **핵심 파일 3~10개**에 요약·위험도를 부여한 행을 추가한다(같은 경로의 기계 기록 행과 별개 행이 되어도 무방 — summary 유무로 구분된다):

```bash
python3 <skill>/scripts/cr.py file add --session N --path "src/payment/webhook.ts" \
  --type modified --summary "결제 완료 시 download token 발급 분기 추가" --risk high
```

### ⑤ task 상태 반영

완료/미완료 분리 결과를 task DB에 반영한다:

```bash
python3 <skill>/scripts/cr.py task update --id 3 --status in_progress \
  --next "token 만료 테스트 작성"
```

- 완료된 task → `--status completed`. 진행 중 task → `--next`를 반드시 다음 구체 액션으로 갱신.
- 이번 세션에서 새로 드러난 작업 → `task add`로 신규 등록.

### ⑥ decision 후보 추출·저장

이번 세션에 다음이 **있었는가**를 점검한다(후보 추출 휴리스틱):

- 라이브러리·의존성을 추가/교체했는가?
- DB 스키마·API 응답 형식을 변경했는가?
- 아키텍처·구조를 선택했는가(대안이 있었는가)?
- 기능을 보류·범위 제외했는가?

해당 항목마다:

```bash
python3 <skill>/scripts/cr.py decision add --session N \
  --text "다운로드 링크 전송을 이메일 대신 결제 완료 페이지 노출로 변경" \
  --reason "이메일 인프라 미구축, MVP 범위 축소" \
  --impact "email 템플릿 작업 보류" --revisit "이메일 발송 요구 재확인 시"
```

### ⑦ risk 후보 추출·저장

휴리스틱: 우회한(근본 수정 안 한) 버그가 있는가? / 건드리면 위험한 파일·정책이 새로 생겼는가? / 검증하지 못한 변경(테스트 미작성·실환경 미확인)이 있는가?

```bash
python3 <skill>/scripts/cr.py risk add --session N \
  --text "webhook 실패 재시도 미검증 — 실결제 환경에서 미확인" \
  --level high --file "src/payment/webhook.ts" --mitigation "스테이징 실결제 테스트"
```

### ⑧ 토큰·시간 기록 (config `token_tracking` 값별)

| 값 | 처리 |
|---|---|
| `manual` | 사용자에게 토큰 입력/출력(또는 총량)과 작업 시간을 질문한 뒤 기록 |
| `estimate` | Claude가 대화 규모(턴 수·메시지 길이) 기반으로 추정하고, **추정치이며 근거가 무엇인지 ⑪ 보고에 명시**한 뒤 기록 |
| `off` | 생략 |

②에서 `session end`/`session log`를 아직 실행하기 전이라면 그 커맨드에 `--tokens-in`/`--tokens-out`(필요 시 `--cost`)을 함께 넣는 것이 원칙이다. 즉 ⑧의 값 결정은 ② 실행 전에 해 둔다. 에이전트별 소모를 구분해 남길 필요가 있으면:

```bash
python3 <skill>/scripts/cr.py agent log --session N --agent "Backend Developer" \
  --duration-sec 2460 --tokens 64000 --result "webhook route 구현"
```

### ⑨ 인계 문서 갱신

`references/handoff-guide.md`의 절차를 따른다. 요지: `python3 <skill>/scripts/cr.py recent --json`으로 번들을 받아 `context/handoff.md`, `context/daily-worklog.md`, `context/decision-log.md`, `context/risk-notes.md`, `context/next-session-prompt.md`를 갱신하고 PRD §11.2의 6기준을 자가 점검한다.

### ⑩ 대시보드 갱신

```bash
python3 <skill>/scripts/cr_dashboard.py
```

기본 출력: `context-relay/dashboard/index.html`.

### ⑪ 사용자 보고

```text
Capture 완료 — 세션 #N (<tool>, <status>)

- 저장: 프롬프트 n건, 파일 기록 n건(핵심 n건), 결정 n건, 리스크 n건, git 이벤트 1건
- task: #3 in_progress (다음 액션: token 만료 테스트 작성), #5 completed
- 토큰: 입력 n / 출력 n (<manual 입력|estimate — 근거: 대화 n턴 기준 추정|off로 미기록>)
- 갱신: handoff.md, next-session-prompt.md, daily-worklog.md,
  decision-log.md, risk-notes.md, dashboard/index.html
- 다음 세션: context/next-session-prompt.md 그대로 사용 가능
```

---

## 판단 기준 요약

- 프롬프트는 **사용자가 보낸 것**만 저장한다. Claude 내부 도구 호출은 프롬프트가 아니다.
- 사소한 확인성 메시지("응", "계속해")는 저장하지 않는다. 작업을 규정한 프롬프트만.
- decision/risk가 0건인 세션도 정상이다 — 억지로 만들지 않는다(가짜 기록 금지).
- 여러 task에 걸친 세션이면 `--task`는 주된 task 하나로 연결하고, 나머지는 ⑤에서 개별 갱신한다.
- capture 도중 어떤 커맨드가 exit 1이어도 나머지 단계를 계속 진행하고, 실패 항목을 ⑪ 보고에 명시한다.
