# Context Relay — Architecture & Interface Contract (SSOT)

> 이 문서는 Context Relay 스킬의 **단일 인터페이스 계약**이다.
> SKILL.md, scripts/cr.py, scripts/cr_dashboard.py, templates/*, references/* 는
> 전부 이 계약을 따른다. 계약과 구현이 어긋나면 **구현이 틀린 것**이다.
> 기능 배경과 요구사항 원문은 `references/PRD.md` 참조.

---

## 1. 두 개의 디렉터리 세계

### 1.1 스킬 패키지 (이 저장소)

```text
context-relay/                  ← 스킬 루트 (~/.claude/skills/context-relay 로 설치)
├── SKILL.md                    ← 스킬 본체: 서브커맨드 라우팅 + 워크플로우
├── README.md                   ← 설치·사용 안내
├── scripts/
│   ├── cr.py                   ← 결정론 엔진: DB init/CRUD/검색/마스킹/git/통계
│   └── cr_dashboard.py         ← 정적 HTML 대시보드 생성기
├── templates/                  ← setup/init 시 대상 프로젝트로 복사·치환되는 원본
│   ├── project-charter.md
│   ├── PRD.md
│   ├── TASKS.md
│   ├── CLAUDE-section.md       ← 기존 CLAUDE.md에 append 하는 섹션 (전체 덮어쓰기 금지)
│   ├── AGENTS.md
│   ├── cursor-context-relay.mdc
│   ├── handoff.md
│   ├── next-session-prompt.md
│   ├── daily-worklog.md
│   ├── decision-log.md
│   ├── risk-notes.md
│   ├── prompt-library.md
│   └── config.json
└── references/
    ├── PRD.md                  ← 제품 요구사항 원문
    ├── architecture.md         ← 이 문서
    ├── setup-guide.md          ← setup 인터뷰 + 파일 생성 절차 상세
    ├── capture-protocol.md     ← capture 11단계 상세 프로토콜
    ├── handoff-guide.md        ← handoff/resume 문서 품질 기준 + 생성 절차
    ├── search-guide.md         ← FTS5 질의 문법 + 자연어→질의 변환
    ├── dashboard-guide.md      ← 대시보드 생성·해석 가이드
    ├── github-guide.md         ← github-summary: 커밋 메시지/PR 초안 생성
    └── db-schema.md            ← 전체 스키마 레퍼런스 + 설계 근거
```

### 1.2 대상 프로젝트 (사용자의 프로젝트, setup 후)

```text
<project-root>/
├── PRD.md                      ← 없으면 생성, 있으면 보존
├── TASKS.md                    ← 없으면 생성, 있으면 보존
├── CLAUDE.md                   ← Context Relay 섹션 append (마커 기반 idempotent)
├── AGENTS.md                   ← Context Relay 섹션 append (마커 기반 idempotent)
├── .cursor/rules/context-relay.mdc
├── context/
│   ├── project-charter.md
│   ├── handoff.md
│   ├── next-session-prompt.md
│   ├── daily-worklog.md
│   ├── decision-log.md
│   ├── risk-notes.md
│   └── prompt-library.md
└── context-relay/
    ├── context-relay.sqlite
    ├── config.json
    ├── dashboard/index.html
    ├── exports/
    └── snapshots/
```

- **basic init** = `context/` + `context-relay/` 만 생성 (cr.py init 이 수행).
- **full setup** = basic init + 헌법 문서 + 도구별 지침 파일 (SKILL.md 의 setup 워크플로우가 인터뷰 후 수행).
- 기존 파일 보호 원칙: `CLAUDE.md`/`AGENTS.md` 는 **덮어쓰지 않고** 마커 블록을 append 한다.
  마커: `<!-- context-relay:begin -->` … `<!-- context-relay:end -->`.
  이미 마커가 있으면 블록 내부만 교체한다. `PRD.md`/`TASKS.md`/`README.md` 는 존재하면 건드리지 않는다.

---

## 2. 역할 분리: AI 판단 vs 결정론 엔진

```text
Claude (SKILL.md 워크플로우)          cr.py / cr_dashboard.py (결정론)
─────────────────────────────         ─────────────────────────────
셋업 인터뷰, 문서 내용 작성            디렉터리/DB 생성, 스키마 관리
세션 요약, 완료/미완료 분리            세션/프롬프트/task CRUD
decision·risk 후보 추출               마스킹 후 저장, FTS 인덱스 동기화
handoff/next-prompt 문안 생성         git status/diff/log 수집·요약 저장
커밋 메시지/PR 초안 작성              BM25 검색, 통계 집계, JSON 번들 출력
대시보드 해석·보고                    index.html 렌더링
```

원칙: **판단·요약·문장 생성은 Claude가, 저장·검색·집계·렌더링은 스크립트가** 한다.
Claude는 SQL을 직접 쓰지 않고 항상 cr.py CLI를 경유한다 (스키마 보호).

---

## 3. `scripts/cr.py` CLI 계약

- Python 3.9+ / **표준 라이브러리만** (sqlite3, argparse, json, re, subprocess, pathlib, datetime, shutil).
- 호출 형태: `python3 <skill>/scripts/cr.py <command> [subcommand] [flags]`
- 공통 플래그: `--root PATH` (기본: cwd에서 위로 올라가며 `context-relay/context-relay.sqlite` 탐색; `init` 은 cwd 사용), `--json` (기계 판독 출력).
- 종료 코드: `0` 성공 / `1` 일반 오류 / `2` 미초기화 (DB 없음).
- 생성 커맨드는 기본 출력에 `id=N` 을 반드시 포함하고, `--json` 시 생성된 행 전체를 JSON으로 출력한다.
- 모든 타임스탬프는 로컬 타임존 ISO 8601 초 단위: `datetime.now().astimezone().isoformat(timespec="seconds")`.
- 멀티라인 텍스트 입력: `--text` 대신 `--text-file PATH` 지원, `--text-file -` 는 stdin.

### 3.1 커맨드 목록

```text
init [--name NAME]
    context/ + context-relay/ 디렉터리, DB(스키마+FTS), config.json 생성. idempotent.
    projects 행이 없으면 생성 (name 기본값: 루트 디렉터리명).

session start --tool T [--agent A] [--goal G] [--request R] [--task N]
    status=active, started_at=now 로 세션 생성. → id 출력
session end --id N [--summary S] [--status completed|failed|paused|abandoned]
            [--tokens-in N] [--tokens-out N] [--cost C] [--task N] [--duration-sec N]
    ended_at=now, duration_sec 자동 계산(--duration-sec 지정 시 존중), token_total 자동 합산.
    --task N: 세션을 task에 연결(linked_task_id 갱신) — 세션 시작 시점에 task를 몰랐던
    라이브 세션을 capture 시점에 연결하는 용도.
session log --tool T [--goal G] [--summary S] [--status ST] [--request R] [--agent A]
            [--task N] [--started-at ISO] [--ended-at ISO] [--duration-sec N]
            [--tokens-in N] [--tokens-out N] [--cost C]
    사후(retroactive) 일괄 기록. Cursor/Codex/Antigravity 세션 캡처용. → id 출력
session list [--limit N] [--status ST] [--json]

prompt add --session N (--text TXT | --text-file PATH) [--type TYPE] [--result R]
           [--score 1-5] [--reuse] [--files "a.ts,b.ts"] [--agent A] [--tool T]
    tool/agent 미지정 시 세션에서 상속. prompt_type ∈
    {planning, implementation, debugging, refactoring, testing, deployment,
     documentation, review, recovery}
prompt list [--session N] [--reuse-only] [--type TYPE] [--limit N] [--json]

task add --title T [--description D] [--status S] [--priority P] [--prd-ref R]
         [--risk L] [--next A]
    status ∈ {not_started, in_progress, blocked, needs_review, ready_to_test, completed}
    priority ∈ {low, medium, high}   risk ∈ {low, medium, high}
task update --id N [--title|--description|--status|--priority|--prd-ref|--risk|--next]
task list [--status S] [--json]

file add --session N --path P [--type added|modified|deleted|renamed]
         [--summary S] [--risk L]
file list [--session N] [--json]

decision add --text TXT [--session N] [--reason R] [--impact I] [--revisit C]
decision list [--limit N] [--json]

risk add --text TXT [--level L] [--file F] [--mitigation M] [--session N]
risk list [--json]

git capture [--session N] [--files]
    git branch/HEAD/status --porcelain/diff --stat/log -5 수집 → git_events 1행 저장.
    --files: porcelain 파싱해 files_changed 행도 생성 (M→modified, A/??→added,
    D→deleted, R→renamed). --files 는 --session 필수 (files_changed.session_id NOT NULL).
    context-relay/ 하위 경로는 자기 오염 방지를 위해 files_changed 생성에서 제외.
    git 저장소가 아니면 경고 후 exit 0 (오류 아님).
git info [--json]
    저장 없이 현재 git 상태 JSON 출력 (branch, last_commit, dirty_count,
    recent_commits[5], changed_files[]). 대시보드/handoff 생성 참고용.

agent add --name N [--role R] [--tool T]                          → id
agent log --session N --agent NAME_OR_ID [--duration-sec S] [--tokens N] [--result R]
    agents 행이 없으면 이름으로 자동 생성 후 session_agents 에 기록.
agent list [--json]

search "QUERY" [--limit N] [--entity sessions|prompts|tasks|decisions|risks|files]
               [--json]
    FTS5 BM25. snippet 포함. FTS5 불가 환경이면 LIKE 폴백 (출력에 fallback 표기).
reindex
    search_index 전체 재구축 (복구용; 평시엔 쓰기 시 자동 동기화).

stats [--json]
    요약 통계: 세션/프롬프트/결정/리스크 수, task 상태별 수, 총 duration_sec,
    총 토큰, 총 비용, 마지막 세션 시각, 날짜별 세션·토큰 집계(전 기간),
    파일 변경 빈도 top 20, 도구별 세션 수.
recent [--limit N] [--json]
    handoff 생성용 번들 JSON: project, 최근 세션 N개(프롬프트 수 포함),
    최근 프롬프트, 최근 변경 파일, open task 전부, 최근 결정 10, risk 전부, stats 요약.

export [--out PATH]      전체 DB → JSON 덤프. 기본: context-relay/exports/export-<stamp>.json
snapshot                 context/*.md → context-relay/snapshots/<stamp>/ 복사
```

### 3.2 FTS 동기화 규칙

- 각 add/update 커맨드는 해당 행의 search_index 항목을 즉시 upsert 한다
  (기존 `(entity_type, entity_id)` 행 delete 후 insert).
- entity_type 값: `session`, `prompt`, `task`, `decision`, `risk`, `file`.
- title/body 매핑:

| entity_type | title | body |
|---|---|---|
| session | session_goal (없으면 tool_name) | summary + user_request |
| prompt | prompt_type + result_summary 앞 60자 | prompt_text + result_summary |
| task | title | description + current_next_action |
| decision | decision_text 앞 80자 | decision_text + reason + impact |
| risk | risk_text 앞 80자 | risk_text + mitigation + related_file |
| file | file_path | change_summary + change_type |

### 3.3 마스킹 규칙 (저장 직전 모든 자유 텍스트에 적용)

적용 대상: prompt_text, result_summary, summary, user_request, diff_summary,
change_summary, decision/risk 텍스트 등 **모든 자유 텍스트 컬럼**.

패턴 (대체 문자열은 `[MASKED:<종류>]`):

```text
1. 키=값 할당:  (?i)[A-Za-z0-9_.\-]*(api[_-]?key|apikey|secret|token|passwd|password|
   private[_-]?key|access[_-]?key|client[_-]?secret|auth[_-]?token|credential)
   [A-Za-z0-9_.\-]*\s*[:=]\s*["']?\S{6,}
   → 값 부분만 [MASKED:assignment]. 트리거 키워드는 LHS 식별자 안 어디에 있어도
   발화한다 (SECRET_KEY=, MY_API_TOKEN= 포함).
   예외: 값이 함수 호출 형태("(" 포함, 예: token = generateToken())면 코드 예시로
   보고 마스킹하지 않는다 — 프롬프트 라이브러리 가치 보존 (알려진 한계로 문서화).
2. OpenAI/Anthropic 류: sk-[A-Za-z0-9_-]{16,}                → [MASKED:api-key]
3. GitHub: (ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,} 및 github_pat_[A-Za-z0-9_]{20,}
4. AWS: AKIA[0-9A-Z]{16}
5. Slack: xox[baprs]-[A-Za-z0-9-]{10,}
6. Bearer 헤더: (?i)bearer\s+[A-Za-z0-9\-_\.=]{16,}
7. JWT: eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}
8. PEM 블록: -----BEGIN [A-Z ]*PRIVATE KEY----- ... -----END ...----- 전체
9. .env 행: diff/텍스트 안에서 파일 경로가 .env 계열이면 값 전체 마스킹
10. 연결 문자열 자격증명: (?i)\b[a-z][a-z0-9+.\-]*://[^\s:@/]+:([^\s:@/]{3,})@
    → 비밀번호 부분만 [MASKED:credential] (postgres://user:pass@host 류)
```

알려진 한계: 다단어 패스프레이즈("password = correct horse battery staple")는
첫 토큰만 마스킹된다. 함수 호출 예외로 인해 "("를 포함한 실제 시크릿은 통과할 수
있다 (실사용에서 극히 드묾). Claude 는 저장 전 육안 확인을 병행한다 (SKILL 불변 규칙 e).

- config.json `masking: false` 면 건너뛴다 (기본 true).
- 마스킹은 저장 시 1회 적용 (원문 비보존). 검색·대시보드는 마스킹된 텍스트만 다룬다.

### 3.4 오류·엣지 처리

- DB 없는 상태에서 init 외 커맨드 → stderr 안내 + exit 2.
- 존재하지 않는 id 참조 → stderr `not found` + exit 1.
- git 미설치/비저장소 → `git capture`/`git info` 는 경고 출력 + exit 0 (파이프라인 중단 방지).
- 모든 SQL 은 파라미터 바인딩 (문자열 포맷 금지).
- `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`.

---

## 4. DB 스키마 (DDL 전문 — 이대로 구현)

PRD §6.7 스키마 + 아래 확장. 변경 금지, 추가 시 db-schema.md에 근거 기록.

```sql
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
);
-- meta: schema_version='1', fts_enabled='1'|'0'

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  tool_name TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT,
  ended_at TEXT,
  duration_sec INTEGER,
  session_goal TEXT,
  user_request TEXT,
  summary TEXT,
  status TEXT,
  token_input INTEGER DEFAULT 0,
  token_output INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  estimated_cost REAL DEFAULT 0,
  linked_task_id INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  tool_name TEXT,
  agent_name TEXT,
  prompt_text TEXT NOT NULL,
  prompt_type TEXT,
  related_files TEXT,            -- 확장: PRD 6.4 기록 항목 (쉼표 구분 경로)
  result_summary TEXT,
  success_score INTEGER,
  reuse_candidate INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT,
  priority TEXT,
  prd_reference TEXT,
  risk_level TEXT,
  current_next_action TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS files_changed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  change_type TEXT,
  change_summary TEXT,
  risk_level TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  decision_text TEXT NOT NULL,
  reason TEXT,
  impact TEXT,
  revisit_condition TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS risks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  risk_text TEXT NOT NULL,
  risk_level TEXT,
  related_file TEXT,
  mitigation TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS git_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  commit_hash TEXT,
  branch_name TEXT,
  diff_summary TEXT,
  changed_files_count INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  role TEXT,
  tool_name TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS session_agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  agent_id INTEGER NOT NULL,
  duration_sec INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  result_summary TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(id),
  FOREIGN KEY(agent_id) REFERENCES agents(id)
);

CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_prompts_session ON prompts(session_id);
CREATE INDEX IF NOT EXISTS idx_files_session ON files_changed(session_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

-- FTS5 (생성 실패 시 meta.fts_enabled='0' 로 기록하고 LIKE 폴백)
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
  entity_type UNINDEXED,
  entity_id UNINDEXED,
  title,
  body,
  created_at UNINDEXED,
  tokenize = 'unicode61'
);
```

> PRD 예시 대비 의도적 변경: `entity_type/entity_id/created_at` 를 UNINDEXED 로 —
> 메타컬럼이 BM25 어휘를 오염시키지 않게 한다. 필터는 `WHERE entity_type = ?` 로 동일하게 가능.
> `prompts.related_files` 컬럼 추가 — PRD 6.4 기록 항목 대응.

---

## 5. `context-relay/config.json` 스키마

```json
{
  "version": 1,
  "project_name": "<이름>",
  "tools": ["claude-code", "cursor", "codex", "antigravity"],
  "store_prompt_full_text": true,
  "token_tracking": "estimate",
  "masking": true,
  "github": true,
  "language": "ko",
  "capture_mode": "manual"
}
```

- `store_prompt_full_text: false` 면 SKILL.md capture 단계에서 프롬프트를 요약해 저장.
- `token_tracking`: `"manual"` | `"estimate"` (Claude가 대화 길이 기반 추정) | `"off"`.
- `capture_mode`: `"manual"` (사용자가 capture 를 명시 요청) | `"semi"` (세션 종료 신호가
  보이면 Claude 가 capture 실행을 선제안). setup 인터뷰 Q10 답이 여기에 기록된다.
- cr.py 는 `masking` 만 직접 읽는다. 나머지는 SKILL.md 워크플로우가 해석.

---

## 6. `scripts/cr_dashboard.py` 계약

- 호출: `python3 cr_dashboard.py [--root PATH] [--out PATH]`
  (기본 out: `<root>/context-relay/dashboard/index.html`)
- DB(§4 스키마)를 직접 SELECT + `git` 커맨드로 현재 상태 수집 → **자체완결 정적 HTML 1파일** 생성.
- 제약: 외부 CDN/폰트/네트워크 요청 0건. CSS/JS 인라인. 시스템 폰트 스택.
  라이트/다크 모두 지원 (`prefers-color-scheme`). 데이터는 `<script id="cr-data" type="application/json">` 에 임베드하고 vanilla JS 로 렌더.
- 빈 DB(세션 0건)에서도 절대 크래시하지 않고 "아직 기록이 없습니다" 빈 상태를 렌더.
- HTML 이스케이프 필수 (프롬프트 본문에 `<script>` 가 있어도 안전해야 함).
- UI 언어: 한국어.

### 섹션 (PRD §6.9, §10 매핑)

의도적 미구현 3건 (MVP 경계 §9 근거): PRD §6.6 카드 항목 중 `blockers`(스키마에 컬럼
없음 — blocked 상태 task 의 next_action 으로 대체 표기)와 `PRD alignment score`(자동
산출 불가 — prd_reference 배지로 대체), PRD §6.9-7 의 `open PR`(GitHub API 연동은
§13.2 제외 항목). 이 3건 외에는 전부 포함한다.

1. **프로젝트 요약 카드 줄**: 프로젝트명, 현재 브랜치, 마지막 세션 시각, 진행중/완료/위험 task 수, 총 세션·프롬프트 수, 총 작업 시간(h m), 총 토큰.
2. **Task Board (칸반)**: Not Started | In Progress | Blocked | Needs Review | Ready to Test | Completed 컬럼. 카드: 제목, 상태, 연결 세션 수, 사용 도구, 에이전트, 작업 시간, 토큰, 변경 파일 수, 위험도 배지, 다음 액션.
3. **세션 타임라인**: 최근 30개, `날짜 시각 · 도구 · 목표 · 상태 · 토큰`.
4. **프롬프트 타임라인**: 최근 50개, `시간 → 도구 → 프롬프트(앞 160자) → 결과 요약 → 관련 파일 → 점수/재사용 배지`.
5. **히트맵 4종**: ① 날짜별 활동 캘린더(최근 17주, 세션 수 & 토큰 토글) ② 파일 변경 빈도 top 20 바 ③ task별 토큰 바 ④ 에이전트 활동(세션 수·토큰) 바.
6. **위험 파일 지도**: risks.related_file + files_changed.risk_level 결합, 위험도별 그룹.
7. **GitHub 상태**: 브랜치, 마지막 커밋, uncommitted 수, 최근 커밋 5, 최근 git_events.
8. **검색 패널**: 임베드된 데이터에 대한 클라이언트 사이드 필터(부분 문자열). 심층 검색은 CLI `search` 안내 문구 표기.

---

## 7. 템플릿 계약

- 플레이스홀더 표기: `{{PLACEHOLDER_NAME}}` (예: `{{PROJECT_NAME}}`, `{{PRODUCT_GOAL}}`,
  `{{MVP_SCOPE}}`, `{{NON_GOALS}}`, `{{TECH_STACK}}`, `{{DEPLOY_TARGET}}`, `{{DOD}}`,
  `{{RISK_AREAS}}`, `{{TOOLS}}`, `{{DATE}}`). Claude가 setup 인터뷰 답변으로 치환.
- `CLAUDE-section.md` / `AGENTS.md` 는 `<!-- context-relay:begin -->` / `<!-- context-relay:end -->`
  마커를 포함해야 한다 (idempotent append 용).
- 각 템플릿의 필수 섹션 구조는 PRD §6.0.5, §6.0.6, §6.12, §6.13 을 그대로 따른다.
- `config.json` 템플릿은 §5 스키마의 기본값.
- 도구별 지침 파일에는 capture 실행 지시가 반드시 포함된다
  (예: "작업 종료 전 Context Relay capture 워크플로우 실행 또는 사용자에게 요청").

---

## 8. SKILL.md 라우팅 계약

`/context-relay <subcommand>` 인자 라우팅 (인자 없으면 status 요약 + 메뉴 제시):

| 서브커맨드 | 동작 | 참조 문서 |
|---|---|---|
| `setup` | 인터뷰(AskUserQuestion) → full setup → 초기 handoff 생성 | setup-guide.md |
| `init` | basic init (cr.py init) | setup-guide.md |
| `capture` | 세션 종료 11단계: git 수집→세션/프롬프트/파일/결정/리스크 저장→문서 갱신→대시보드 | capture-protocol.md |
| `handoff` | recent 번들 → handoff.md + daily-worklog + decision-log + risk-notes 갱신 | handoff-guide.md |
| `resume` | handoff 기반 next-session-prompt.md 생성 | handoff-guide.md |
| `search "..."` | cr.py search 실행 + 결과 해석 보고 | search-guide.md |
| `dashboard` | cr_dashboard.py 실행 + 열람 안내 + 핵심 해석 | dashboard-guide.md |
| `prompts` | prompt-library.md 재생성 / 조회 | handoff-guide.md |
| `github-summary` | git info 기반 커밋 메시지·PR 초안 생성 | github-guide.md |
| `status` | stats + task list 요약 보고 | — |

- SKILL.md 는 **본문을 얇게** 유지하고 세부 절차는 references/ 로 progressive disclosure.
- capture 는 어떤 도구의 세션이든 기록 가능해야 한다: Claude Code 세션은 대화에서 직접 재구성,
  타 도구(Cursor/Codex/Antigravity)는 git diff + 사용자 문답으로 `session log` 사후 기록.
- 품질 게이트: handoff 는 PRD §11.2 의 6기준, charter 는 §11.1 의 6기준을 자가 점검 후 완료 선언.

---

## 9. MVP 경계 (재확인)

포함: PRD §13.1 전체. 제외: 도구 내부 로그 자동 수집, 클라우드 동기화, 팀 권한,
GitHub API 완전 연동(gh CLI 있으면 opt-in 참고 수준만), 실시간 토큰 계측, IDE 플러그인, 벡터 검색.
