# Search Guide — search 서브커맨드

> `/context-relay search "..."` 실행 시 이 문서를 따른다.
> 커맨드·플래그는 `references/architecture.md` §3.1 계약과 글자 단위로 일치해야 한다.
> `<skill>` 은 스킬 설치 경로(예: `~/.claude/skills/context-relay`)를 뜻한다.

## 1. 사용법

```bash
python3 <skill>/scripts/cr.py search "QUERY" [--limit N] [--entity sessions|prompts|tasks|decisions|risks|files] [--json]
```

- 질의는 **위치 인자** — 반드시 따옴표로 감싼다 (OR, NOT, `*` 가 셸에 먹히지 않도록).
- `--entity` — 결과를 한 종류로 제한. 플래그 값은 **복수형**이고, 결과 행의 entity_type 필드는 **단수형**(session, prompt, task, decision, risk, file — architecture §3.2)임에 주의.
- `--limit N` — 결과 수 상한.
- `--json` — 기계 판독 출력. Claude 가 후속 처리할 때는 항상 `--json` 을 쓴다.
- 검색 결과가 명백히 어긋나면(방금 저장한 것이 안 나옴) 인덱스 재구축: `python3 <skill>/scripts/cr.py reindex`

검색 엔진: SQLite FTS5 + BM25 순위. snippet 포함. FTS5 불가 환경이면 LIKE 폴백 (§5).

## 2. FTS5 질의 문법 요약

| 문법 | 예 | 의미 |
|---|---|---|
| 암시적 AND | `download token` | 두 토큰 모두 포함 (공백 = AND) |
| OR | `결제 OR webhook` | 둘 중 하나 이상 |
| NOT | `webhook NOT test` | webhook 포함, test 제외 |
| "구문 검색" | `"download token"` | 인접·순서 일치 |
| 접두사* | `tok*` | tok 로 시작하는 토큰 전부 |
| NEAR | `NEAR(webhook 실패, 10)` | 10토큰 이내 근접 |

연산자(OR, NOT, NEAR)는 대문자만 인식된다.

### 한국어 주의 (unicode61 토크나이저)

- 토큰은 공백·문장부호 단위로 잘린다. 형태소 분석이 없으므로 **조사가 붙은 형태는 별개 토큰**이다: "token을", "토큰이" 는 "token", "토큰" 과 다른 토큰.
- 따라서 한국어·혼용 질의는 핵심 명사에 **접두사`*`** 를 붙이는 것이 기본기다: `토큰*`, `webhook*`, `다운로드*`.
- 정확한 구문이 확실할 때만 `"구문 검색"` 을 쓰고, 아니면 `단어* AND 단어*` 조합이 재현율이 높다.

## 3. 자연어 요청 → 질의 변환표 (PRD §6.8 예시)

| 자연어 요청 | 실행 커맨드 | 비고 |
|---|---|---|
| "결제 webhook 관련 작업 찾아줘" | `python3 <skill>/scripts/cr.py search "결제* OR webhook*" --json` | 전 엔티티 검색 후 task/session 중심으로 보고. task 만 원하면 `--entity tasks` 추가 |
| "download token을 왜 만들었는지 찾아줘" | `python3 <skill>/scripts/cr.py search "download token*" --entity decisions --json` | "왜" = 결정 이유 → decisions 우선. 0건이면 `--entity prompts` 로 재검색 |
| "Cursor에서 마지막으로 수정한 파일 보여줘" | `python3 <skill>/scripts/cr.py session list --json` 에서 tool_name 이 cursor 인 최신 세션 확인 → `python3 <skill>/scripts/cr.py file list --session N --json` | FTS 아님 — 도구·최신성 필터는 구조 질의 |
| "실패한 프롬프트만 찾아줘" | `python3 <skill>/scripts/cr.py prompt list --json` 후 success_score 1~2 를 필터. 또는 `python3 <skill>/scripts/cr.py session list --status failed --json` → 해당 세션마다 `prompt list --session N --json` | FTS 아님 — "실패" 단어 검색이 아니라 구조 속성 |
| "재사용 가능한 프롬프트 보여줘" | `python3 <skill>/scripts/cr.py prompt list --reuse-only --json` | reuse_candidate=1 구조 필터 |
| "토큰을 많이 쓴 세션 찾아줘" | `python3 <skill>/scripts/cr.py stats --json` (총계·날짜별 집계) + `python3 <skill>/scripts/cr.py session list --json` 후 token_total 내림차순 정렬해 보고 | 수치 정렬은 FTS 영역이 아님 |

## 4. 라우팅 기준 — FTS 인가, 구조 질의인가

| 요청 신호 | 경로 |
|---|---|
| 내용·주제·이유 ("~관련", "~에 대한", "왜 ~했는지") | `search` (FTS) |
| 상태·점수·플래그 (실패한, 재사용 가능한, blocked 인) | `session list --status` / `prompt list --reuse-only` / `task list --status` |
| 수치·정렬 (토큰 많이 쓴, 오래 걸린, 자주 바뀐) | `stats --json` / `session list --json` 후 클라이언트 정렬 |
| 도구·시간 범위 (Cursor 에서, 어제, 마지막) | `session list --json` 후 tool_name / started_at 필터 |
| 혼합 (예: "실패한 webhook 프롬프트") | 구조 필터 먼저(`session list --status failed`) → 그 결과 범위 안에서 텍스트 대조 또는 `search` 결과와 교집합 |

## 5. LIKE 폴백 동작과 한계

- FTS5 를 만들 수 없는 환경에서는 DB 에 `meta.fts_enabled='0'` 이 기록되고, `search` 는 LIKE 부분 문자열 검색으로 폴백한다. **출력에 fallback 표기**가 나타난다.
- 한계:
  - BM25 순위 없음 — 관련도 정렬을 기대하지 말 것.
  - OR / NOT / "구문" / 접두사`*` / NEAR 미지원 — 질의 전체가 하나의 부분 문자열로 취급된다.
  - snippet 하이라이트 정밀도가 낮고, 데이터가 커질수록 느리다.
- 폴백 표기를 보면: 복합 질의를 **단순 키워드 여러 번**으로 나눠 각각 실행하고 결과를 합쳐 보고한다.

## 6. 결과 보고 형식

1. 실행한 커맨드와 실제 질의문을 먼저 명시한다 (사용자가 재현 가능하도록).
2. 각 결과 행: `[entity_type #entity_id] title — snippet` 형태로 나열. snippet 의 `[ ]` 는 매칭 토큰 하이라이트다.
3. 상위 3~5건은 후속 조회로 상세를 붙인다:

| entity_type | 후속 조회 |
|---|---|
| session | `session list --json` 출력에서 해당 id 행 (프롬프트는 `prompt list --session N --json`) |
| prompt | `prompt list --json` 출력에서 해당 id 행 |
| task | `task list --json` 출력에서 해당 id 행 |
| decision | `decision list --json` 출력에서 해당 id 행 |
| risk | `risk list --json` 출력에서 해당 id 행 |
| file | `file list --json` 출력에서 해당 id 행 (세션 범위는 `--session N`) |

4. **0건 처리**: (a) 핵심 토큰에 접두사`*` 완화 → (b) AND 를 OR 로 확장 → (c) `--entity` 제한 해제 순으로 1회씩 재시도한 뒤, 그래도 없으면 "기록 없음" 과 시도한 질의들을 보고한다.
5. 마스킹된 텍스트(`[MASKED:...]`)가 snippet 에 보이면 원문은 저장되지 않았음을 함께 알린다 (architecture §3.3 — 마스킹은 저장 시 1회, 원문 비보존).
