# Setup Guide — `/context-relay setup` 실행 절차

> SKILL.md의 `setup` 서브커맨드가 이 문서를 로드한다.
> 인터페이스 계약은 `references/architecture.md`(SSOT)를 따른다.
> 표기: `<skill>` = 스킬 루트 경로 (예: `~/.claude/skills/context-relay`).
> 모든 커맨드는 **대상 프로젝트 루트**에서 실행한다.

절차 개요: Step 0 사전 스캔 → Step 1 인터뷰 → Step 2 basic init → Step 3 문서 생성 → Step 4 초기 데이터 등록 → Step 5 완료 검증·보고.

---

## Step 0 — 사전 스캔

프로젝트 루트에서 아래 대상(PRD §6.1)을 확인한다. 목적은 두 가지: (a) 기존 자산 보호 대상 파악, (b) 인터뷰 질문의 기본값 채우기.

| 탐색 대상 | 확인 방법 | 발견 시 반영 |
|---|---|---|
| `README.md` | Read | 프로젝트 이름·목표 후보 추출 → Q1·Q2 기본값. 보존 대상(생성·수정 금지) |
| `PRD.md` | Read | **보존 대상.** 목표·MVP 범위 추출 → Q2·Q3 기본값 |
| `TASKS.md` / `TODO.md` | Read | **TASKS.md는 보존 대상.** 기존 task 항목 → Step 4 초기 task 후보 |
| `CLAUDE.md` | Read | 마커(`<!-- context-relay:begin -->`) 존재 여부 → 재실행 감지. 기존 규칙 파악(엣지 케이스 3 참조) |
| `AGENTS.md` | Read | 마커 존재 여부 → 재실행 감지 |
| `package.json` | Read | `name` → Q1 기본값, dependencies → Q6 기본값, `workspaces` → 모노레포 감지 |
| `pyproject.toml` | Read | `[project].name` → Q1, 의존성 → Q6 |
| `tsconfig.json` | 존재 확인 | TypeScript → Q6 기본값 보강 |
| `.git/` | `git status`, `git remote -v` | 존재+remote 있으면 Q11 기본값 "예". 현재 브랜치 파악 |
| `docs/` | 목록 확인 | 기존 설계 문서 존재 사실을 charter 작성 시 참고 |

주의: 이 시점에는 DB가 없으므로 `cr.py git info`를 쓰지 말 것(미초기화 상태에서 `init` 외 커맨드는 exit 2). git 상태는 `git` 커맨드로 직접 확인한다.

모노레포 감지(`workspaces` 존재 또는 하위 디렉터리에 복수 `package.json`/`pyproject.toml`) 시 Step 1 앞에 Batch 0 질문을 추가한다.

---

## Step 1 — 인터뷰 (AskUserQuestion, 총 3~4회 호출)

PRD §6.0.3의 13개 질문을 AskUserQuestion 규격(1회 최대 4문항)에 맞춰 배치한다. 모든 질문에 스캔 기반 기본값을 첫 번째 선택지로 제시하고, 자유 입력(Other)을 열어 둔다.

**위임 규칙**: 사용자가 어느 시점이든 "알아서 해줘"라고 답하면 남은 질문을 전부 생략하고 아래 표의 기본값으로 진행한다. 이 경우 Step 5 보고에 "자동 채택한 기본값" 목록을 반드시 명시한다.

### Batch 0 (조건부) — 모노레포 루트 선택

모노레포 감지 시에만 1문항: "Context Relay를 어디에 설치할까요?" 선택지 = 저장소 루트 / 감지된 각 패키지 디렉터리. 이후 모든 Step은 선택된 루트 기준으로 실행한다.

### Batch 1 — 프로젝트 정체성 (Q1~Q4)

| # | 질문 (PRD §6.0.3) | 선택지 구성 | 기본값 (스캔 반영) |
|---|---|---|---|
| Q1 | 프로젝트 이름 | 발견된 이름 1~2개 + 직접 입력 | `package.json name` > `pyproject name` > 루트 디렉터리명 |
| Q2 | 최종 목표 | README/PRD 첫 문단에서 요약한 후보 1~2개 + 직접 입력 | 스캔 요약 후보. 없으면 자유 입력 유도 |
| Q3 | MVP 범위 | PRD/TASKS 기반 범위 후보 + 직접 입력 | 스캔 후보. 없으면 "핵심 기능 1개 동작" 류의 보수적 후보 제시 |
| Q4 | 이번 버전에서 하지 않을 것 | 일반 후보(예: 인증 제외, 모바일 제외, 다국어 제외) + 직접 입력 | "미정 — 작업 중 발견 시 charter에 추가" |

### Batch 2 — 도구·기술 (Q5~Q8)

| # | 질문 | 선택지 구성 | 기본값 |
|---|---|---|---|
| Q5 | 주로 사용할 AI 코딩 도구 (**복수 선택**) | claude-code / cursor / codex / antigravity + 기타 | claude-code |
| Q6 | 주요 기술 스택 | 스캔 결과 후보(예: "TypeScript + Next.js — package.json 기준") + 직접 입력 | 스캔 결과. 없으면 자유 입력 |
| Q7 | 배포 목표 | 예: Vercel / 로컬 실행만 / 미정 + 직접 입력 | 미정 |
| Q8 | 가장 중요한 완료 기준 | 예: "테스트 통과 + 배포", "MVP 시나리오 수동 검증 통과" + 직접 입력 | MVP 시나리오 수동 검증 통과 |

### Batch 3 — 운영 규칙 (Q9~Q11)

| # | 질문 | 선택지 구성 | 기본값 |
|---|---|---|---|
| Q9 | 건드리면 위험한 파일·영역 | 스캔 기반 후보(예: 결제·인증·마이그레이션 디렉터리) + "없음" + 직접 입력 | 없음 |
| Q10 | 세션 종료 시 기록 방식 | "세션 종료마다 사용자가 capture 요청(수동)" / "Claude가 작업 종료 시점에 capture를 먼저 제안(반자동)" | 반자동 (MVP에 자동 훅 없음) → config `capture_mode` (`manual`\|`semi`) |
| Q11 | GitHub 저장소 사용 여부 | 예 / 아니오 | `.git/` + remote 존재 시 "예", 아니면 "아니오" |

### Batch 4 — 기록 정책 (Q12~Q13)

| # | 질문 | 선택지 구성 | 기본값 | config.json 반영 |
|---|---|---|---|---|
| Q12 | 프롬프트 원문 저장 vs 요약만 | 원문 저장 / 요약만 | 원문 저장 | `store_prompt_full_text` |
| Q13 | 토큰·작업 시간 기록 방식 | 자동 추정(estimate) / 수동(manual) / 기록 안 함(off) | estimate | `token_tracking` |

---

## Step 2 — basic init

```bash
python3 <skill>/scripts/cr.py init --name "<Q1 답변>"
```

- 생성물: `context/`·`context-relay/` 디렉터리, `context-relay/context-relay.sqlite`(스키마+FTS), `context-relay/config.json`(기본값), projects 행.
- idempotent — 재실행해도 안전하다.
- 확인: exit 0, 이후 `python3 <skill>/scripts/cr.py stats --json` 이 정상 출력되면 DB 초기화 성공.

---

## Step 3 — 문서 생성 (templates/ 13개 전부)

### 3.1 매핑 표

| # | 템플릿 (`<skill>/templates/`) | 대상 경로 | 생성 규칙 |
|---|---|---|---|
| 1 | `project-charter.md` | `context/project-charter.md` | 치환 후 생성 |
| 2 | `PRD.md` | `PRD.md` | **존재 시 보존(건드리지 않음)**, 없으면 치환 후 생성 |
| 3 | `TASKS.md` | `TASKS.md` | **존재 시 보존**, 없으면 치환 후 생성 |
| 4 | `CLAUDE-section.md` | `CLAUDE.md` | **마커 블록 idempotent append** (3.3) |
| 5 | `AGENTS.md` | `AGENTS.md` | **마커 블록 idempotent append** (3.3). 본문 영어 유지 |
| 6 | `cursor-context-relay.mdc` | `.cursor/rules/context-relay.mdc` | 생성(디렉터리 포함). 본문 영어 유지 |
| 7 | `handoff.md` | `context/handoff.md` | **Step 3에서 만들지 않음** — Step 4.3에서 템플릿 섹션 구조대로 실제 내용을 작성해 생성 |
| 8 | `next-session-prompt.md` | `context/next-session-prompt.md` | **Step 3에서 만들지 않음** — Step 4.4에서 실제 내용으로 생성 |
| 9 | `daily-worklog.md` | `context/daily-worklog.md` | 제목+안내 인용문만 남기고 저장 (항목 골격은 기록 추가 시마다 복제 — 템플릿 상단 주석 참조) |
| 10 | `decision-log.md` | `context/decision-log.md` | 제목+안내 인용문만 남기고 저장 (위와 동일) |
| 11 | `risk-notes.md` | `context/risk-notes.md` | 제목+안내 인용문만 남기고 저장 (위와 동일) |
| 12 | `prompt-library.md` | `context/prompt-library.md` | 제목+안내 인용문만 남기고 저장 (위와 동일) |
| 13 | `config.json` | `context-relay/config.json` | cr.py init이 이미 생성 — **복사하지 말고 인터뷰 답으로 값만 갱신**(3.4) |

`README.md`는 스캔·보존 대상일 뿐 생성하지 않는다(architecture §1.2 대상 트리 기준).

### 3.2 `{{PLACEHOLDER}}` 치환 규칙

| 플레이스홀더 | 값 출처 |
|---|---|
| `{{PROJECT_NAME}}` | Q1 |
| `{{PRODUCT_GOAL}}` | Q2 |
| `{{MVP_SCOPE}}` | Q3 |
| `{{NON_GOALS}}` | Q4 |
| `{{TOOLS}}` | Q5 (쉼표 구분) |
| `{{TECH_STACK}}` | Q6 |
| `{{DEPLOY_TARGET}}` | Q7 |
| `{{DOD}}` | Q8 |
| `{{RISK_AREAS}}` | Q9 |
| `{{DATE}}` | 오늘 날짜 (YYYY-MM-DD) |
| `{{TARGET_USERS}}` | Q2 답 + README/PRD 스캔에서 추론. 근거 부족 시 값 뒤에 `(setup 기본값 — 확인 필요)` 표기 |
| `{{AI_TOOL_RULES}}` | 템플릿의 기본 규칙 문구를 유지하고 Q9(위험 영역)·Q10(기록 방식) 답을 반영해 보강 |
| `{{PROBLEM_STATEMENT}}` | Q2 답을 "누가 어떤 문제를 겪는가" 서술로 재구성 (PRD.md 신규 생성 시에만 사용) |
| `{{FEATURE_1}}` / `{{FEATURE_1_DESC}}` | Q3 MVP 범위에서 핵심 기능 도출 (기능이 여러 개면 표 행을 복제해 FEATURE_2… 로 확장) |
| `{{SUCCESS_METRICS}}` | Q8 답 재사용 (검증 가능한 형태로 다듬기) |

- 위 표에 없는 플레이스홀더를 템플릿에서 발견하면 임의 창작하지 말고 사용자에게 질문한다.
- `{{` 잔존 0건 검증은 **Step 4 완료 후** 실행한다 (handoff.md·next-session-prompt.md 는 Step 4에서야 생성되기 때문): `grep -rn "{{" context/ PRD.md TASKS.md CLAUDE.md AGENTS.md .cursor/ 2>/dev/null` → 출력 없어야 통과.
- `AGENTS.md`·`cursor-context-relay.mdc` 본문은 PRD §6.0.6 예시대로 영어 원문을 유지한다(임의 한국어화 금지).
- 답을 받지 못한 항목(위임 진행)은 스캔 기반 기본값으로 채우고 해당 섹션에 `(setup 기본값 — 확인 필요)` 표기를 남긴다. 빈칸이나 `{{...}}` 그대로 두지 않는다.

### 3.3 CLAUDE.md / AGENTS.md 마커 append 알고리즘

마커: `<!-- context-relay:begin -->` … `<!-- context-relay:end -->`

1. 대상 파일이 **없으면**: 템플릿 상단의 안내 HTML 주석을 제거한 나머지(마커 블록 포함)로 새 파일을 생성한다. `CLAUDE.md` 신규 생성 시 첫 줄에 `# CLAUDE.md` 제목을 붙이고 그 아래 마커 블록을 둔다. `AGENTS.md` 신규 생성 시 템플릿의 `# AGENTS.md` 헤딩 포함 전체(안내 주석 제외)를 사용한다.
2. **있으면** 파일을 Read 하여 마커 쌍 존재 여부를 확인한다.
3. 마커 쌍이 **있으면**: begin~end 블록 내부만 새 템플릿 내용으로 교체한다. 블록 바깥의 기존 내용은 한 글자도 수정하지 않는다.
4. 마커가 **없으면**: 기존 내용을 그대로 두고 파일 끝에 빈 줄 1개 + 마커 포함 섹션을 append 한다.
5. begin/end 마커 개수가 **(1,1) 또는 (0,0)이 아닌 모든 상태**(begin만, end만, 어느 쪽이든 2회 이상)는 손상으로 간주한다 — append 하지 말고 사용자에게 보고 후 지시를 기다린다.
6. 검증: 결과 파일에 begin 마커와 end 마커가 각각 정확히 1회 등장해야 한다.

### 3.4 config.json 갱신

`context-relay/config.json`(architecture §5 스키마)의 값을 Edit로 갱신한다. 키 추가·삭제 금지, 값만 변경:
`project_name`←Q1, `tools`←Q5, `capture_mode`←Q10(수동=`"manual"`, 반자동=`"semi"`), `github`←Q11, `store_prompt_full_text`←Q12, `token_tracking`←Q13.

### 3.5 .gitignore 갱신 (git 저장소일 때만)

Context Relay 저장소 파일이 커밋·통계를 오염시키지 않도록 `.gitignore`에 아래 블록을 append 한다 (동일 패턴이 이미 있으면 생략):

```gitignore
# Context Relay local store (config.json is shareable)
context-relay/*
!context-relay/config.json
```

`context/*.md` 는 팀과 공유되는 인계 문서이므로 커밋 대상으로 남긴다. 사용자가 DB까지 커밋해 기기 간 공유하길 원하면 이 단계를 건너뛴다 (보고에 명시).

---

## Step 4 — 초기 데이터 등록

1. **초기 task 등록**: TASKS.md의 task 항목(기존 TASKS.md가 있으면 그 항목, 없으면 Q3 MVP 범위에서 3~7개 도출해 TASKS.md에 먼저 기재)을 하나씩 DB에 등록한다.

```bash
python3 <skill>/scripts/cr.py task add --title "결제 webhook 구현" \
  --description "결제 완료 시 다운로드 토큰 생성" \
  --status not_started --priority high --prd-ref "PRD §6.x" \
  --risk medium --next "webhook route 골격 작성"
```

`--status` ∈ {not_started, in_progress, blocked, needs_review, ready_to_test, completed} / `--priority`·`--risk` ∈ {low, medium, high}.

2. **위험 영역 등록** (Q9 답이 "없음"이 아니면):

```bash
python3 <skill>/scripts/cr.py risk add --text "결제 webhook 응답 형식 변경 금지" \
  --level high --file "src/payment/webhook.ts"
```

3. **첫 handoff.md 작성**: `context/handoff.md`를 PRD §6.12 구조로 채운다. 현재 상태 = "Context Relay 셋업 완료", 완료된 작업 = 셋업 산출물 목록, 다음 세션에서 바로 할 일 = 첫 번째 task의 `--next` 액션 3~5개. 세부 품질 기준은 `references/handoff-guide.md` 참조.

4. **첫 next-session-prompt.md 작성**: PRD §6.13 구조(읽을 문서 목록 → 세션 목표 → 주의 → 작업 순서 → 완료 기준)로, 첫 task를 목표로 작성한다. 주의 항목에는 Q9의 위험 영역을 반영한다.

5. **(선택) 셋업 세션 기록**: 셋업 자체를 세션으로 남기면 대시보드 타임라인의 기점이 된다.

```bash
python3 <skill>/scripts/cr.py session log --tool claude-code \
  --goal "Context Relay 최초 셋업" --status completed \
  --summary "charter/PRD/TASKS/지침 파일 생성, task N건 등록"
```

---

## Step 5 — 완료 검증 + 사용자 보고

PRD §6.0.7의 10개 기준을 전부 확인한다. 하나라도 실패하면 해당 Step으로 돌아간다.

| # | 기준 | 검증 방법 |
|---|---|---|
| 1 | project-charter.md 생성 | `context/project-charter.md` 존재 + 플레이스홀더 잔존 0 |
| 2 | PRD.md·TASKS.md 존재 또는 생성 | 두 파일 존재 확인 |
| 3 | CLAUDE.md에 Context Relay 규칙 포함 | 마커 쌍 각 1회 등장 |
| 4 | AGENTS.md에 Context Relay 규칙 포함 | 마커 쌍 각 1회 등장 |
| 5 | Cursor Rules 생성 | `.cursor/rules/context-relay.mdc` 존재 |
| 6 | SQLite DB 초기화 | `cr.py stats --json` exit 0 |
| 7 | context 폴더 기본 문서 생성 | `context/` 아래 7개 md 존재 |
| 8 | dashboard 기본 파일 생성 | `python3 <skill>/scripts/cr_dashboard.py` 실행 → `context-relay/dashboard/index.html` 생성 |
| 9 | 첫 handoff.md 생성 | 내용이 템플릿 원문이 아닌 실제 프로젝트 상태 |
| 10 | next-session-prompt.md 생성 | 첫 task 목표가 담겨 있음 |

charter는 PRD §11.1의 6기준(목표 한 문장/MVP 구체성/Non-goals/검증 가능한 DoD/공통 규칙/위험 영역 명시)을 자가 점검한 뒤 완료를 선언한다.

**보고 형식** (사용자에게 이 구조로 보고):

```text
Context Relay 셋업 완료

- 프로젝트: <이름>
- 생성: project-charter, PRD.md(생성|기존 보존), TASKS.md(생성|기존 보존),
  CLAUDE.md(append), AGENTS.md(append), .cursor/rules/context-relay.mdc,
  context/ 문서 7개, DB, dashboard
- 등록: task N건, risk N건
- config: store_prompt_full_text=<값>, token_tracking=<값>, github=<값>, capture_mode=<값>
- (위임 진행 시) 자동 채택한 기본값: <목록>
- 다음 행동: 작업 시작 전 context/next-session-prompt.md 확인,
  세션 종료 시 /context-relay capture 실행
```

---

## 엣지 케이스

1. **재실행 (idempotent)**: `cr.py init`은 재실행 안전. CLAUDE.md/AGENTS.md는 마커 블록 내부만 교체되므로 중복되지 않는다. PRD/TASKS/README는 존재 시 보존. `context/*.md`가 이미 존재하고 템플릿 원문이 아닌 실제 기록을 담고 있으면 덮어쓰지 말고, 재생성 여부를 AskUserQuestion으로 확인한다.
2. **git 없는 프로젝트**: 셋업은 그대로 진행한다. Q11 기본값 "아니오", config `github: false`. `git capture`/`git info`는 경고 후 exit 0이므로 이후 워크플로우도 중단되지 않는다. 보고에 "git 저장소가 없어 GitHub 기능은 비활성 — 필요 시 git init" 안내를 포함한다.
3. **이미 다른 CLAUDE.md 규칙이 있는 프로젝트**: 기존 내용은 절대 수정하지 않고 마커 섹션만 append 한다. 기존 규칙과 Context Relay 규칙이 충돌하면(예: 세션 종료 절차가 이미 정의됨) 수정하지 말고 충돌 지점을 사용자에게 보고한다.
4. **모노레포**: Batch 0에서 설치 루트를 사용자에게 확정받는다. `cr.py init`은 cwd 기준으로 동작하므로 선택된 루트에서 실행한다. 이후 모든 커맨드는 `--root <선택 루트>`를 쓰거나 해당 루트에서 실행한다.
