---
name: context-relay
description: Claude Code, Cursor, Antigravity, Codex 등 여러 AI 코딩 도구에서 흩어진 작업 맥락을 날짜별·작업별·프롬프트별로 기록하고, 다음 세션에서 바로 이어갈 수 있도록 인계 문서, SQLite 기반 작업 기억 저장소, 검색 시스템, 대시보드를 제공하는 Claude Code 스킬. 핵심 동작 — 프로젝트 셋업 시 공통 작업 헌법(project-charter, PRD, TASKS, CLAUDE.md, AGENTS.md, Cursor Rules) 생성 → 세션 종료 시 capture로 프롬프트·변경 파일·결정·리스크를 SQLite에 기억 → FTS5/BM25로 과거 작업 검색 → 정적 HTML 대시보드로 시각화 → handoff 문서와 다음 세션 프롬프트로 인계. 트리거 — "컨텍스트 릴레이", "프로젝트 셋업하고 기록", "세션 기록해줘", "작업 맥락 저장", "인계서 만들어줘", "인수인계 문서", "어디까지 했더라", "다음 세션 프롬프트", "세션 캡처", "capture 실행", "프로젝트 블랙박스", "작업 이력 검색", "프롬프트 라이브러리", "/context-relay". 단순 git 커밋 요청이나 일반 코드 질문처럼 맥락 기록·인계와 무관한 요청에는 반응하지 않는다.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, AskUserQuestion
---

# Context Relay — AI 개발 인계서 생성 및 세션 맥락 관리

## 1. 개요

- **DB는 원천 기억 저장소, MD는 사람·AI가 읽는 인계 문서다.** 세션·프롬프트·변경 파일·결정·리스크의 원본 데이터는 SQLite(`context-relay/context-relay.sqlite`)에 저장하고, Markdown(`context/*.md`)은 그 요약 산출물로 생성한다.
- **기록보다 인계가 중요하다.** "무엇을 했는가"에서 끝나지 않고, 항상 "다음 세션이 바로 이어 달릴 수 있는가"를 산출물의 기준으로 삼는다.
- **판단은 Claude가, 저장·검색·집계·렌더링은 스크립트가 한다.** Claude는 SQL을 직접 쓰지 않고 항상 `scripts/cr.py` CLI를 경유한다.

인터페이스 계약의 단일 출처는 `references/architecture.md`다. 계약과 구현이 어긋나면 구현이 틀린 것이다.

### 데이터 흐름 (PRD §9)

```text
Project Setup
    → Project Charter / PRD / TASKS / Tool Rules 생성
    → AI Tool Session (Claude Code / Cursor / Codex / Antigravity)
    → Prompt / Response Summary / File Change / Git Diff
    → Context Relay Capture
    → SQLite DB 저장 → FTS5 검색 인덱스 갱신
    → Markdown 인계 문서 생성 → Dashboard 데이터 생성
    → 다음 AI 세션에서 handoff 읽기
```

## 2. 디렉터리 지도

### 2.1 스킬 패키지 (이 저장소)

```text
context-relay/                  ← 스킬 루트 (~/.claude/skills/context-relay 로 설치)
├── SKILL.md                    ← 이 문서: 라우팅 + 워크플로우
├── README.md                   ← 설치·사용 안내
├── scripts/
│   ├── cr.py                   ← 결정론 엔진: DB init/CRUD/검색/마스킹/git/통계
│   └── cr_dashboard.py         ← 정적 HTML 대시보드 생성기
├── templates/                  ← setup/init 시 대상 프로젝트로 복사·치환되는 원본
└── references/                 ← 서브커맨드별 상세 절차 (progressive disclosure)
```

### 2.2 대상 프로젝트 (setup 후)

```text
<project-root>/
├── PRD.md / TASKS.md           ← 없으면 생성, 있으면 보존
├── CLAUDE.md / AGENTS.md       ← Context Relay 섹션 append (마커 기반 idempotent)
├── .cursor/rules/context-relay.mdc
├── context/                    ← 사람·AI가 읽는 인계 문서
│   ├── project-charter.md      ← 프로젝트 헌법
│   ├── handoff.md
│   ├── next-session-prompt.md
│   ├── daily-worklog.md
│   ├── decision-log.md
│   ├── risk-notes.md
│   └── prompt-library.md
└── context-relay/              ← 기억 저장소
    ├── context-relay.sqlite
    ├── config.json
    ├── dashboard/index.html
    ├── exports/
    └── snapshots/
```

기존 파일 보호 원칙: `CLAUDE.md`/`AGENTS.md`는 덮어쓰지 않고 `<!-- context-relay:begin -->` … `<!-- context-relay:end -->` 마커 블록을 append 한다. 이미 마커가 있으면 블록 내부만 교체한다. `PRD.md`/`TASKS.md`/`README.md`는 존재하면 건드리지 않는다.

## 3. 라우팅 표

`/context-relay <subcommand>` 형태로 호출된다. 각 서브커맨드를 시작하기 전에 해당 행의 참조 문서를 **먼저 Read** 한다.

| 서브커맨드 | 동작 | 먼저 Read할 문서 |
|---|---|---|
| `setup` | 인터뷰(AskUserQuestion) → full setup → 초기 handoff 생성 | `references/setup-guide.md` |
| `init` | basic init (`cr.py init`) — context/ + DB만 생성 | `references/setup-guide.md` |
| `init --full` | `setup`의 별칭 (PRD §6.0.2) — setup 워크플로우로 처리 | `references/setup-guide.md` |
| `capture` | 세션 종료 11단계: git 수집 → 세션/프롬프트/파일/결정/리스크 저장 → 문서 갱신 → 대시보드 | `references/capture-protocol.md` |
| `handoff` | `recent` 번들 → handoff.md + daily-worklog + decision-log + risk-notes 갱신 | `references/handoff-guide.md` |
| `resume` | handoff 기반 next-session-prompt.md 생성 | `references/handoff-guide.md` |
| `search "..."` | `cr.py search` 실행 + 결과 해석 보고 | `references/search-guide.md` |
| `dashboard` | `cr_dashboard.py` 실행 + 열람 안내 + 핵심 해석 | `references/dashboard-guide.md` |
| `prompts` | prompt-library.md 재생성 / 조회 | `references/handoff-guide.md` |
| `github-summary` | `git info` 기반 커밋 메시지·PR 초안 생성 | `references/github-guide.md` |
| `status` | `stats` + `task list` 요약 보고 | — |

DB 스키마 근거가 필요하면 `references/db-schema.md`를 참조한다.

**인자 없이 호출된 경우:**
1. `python3 <skill>/scripts/cr.py stats --json` 실행 (exit 2면 미초기화).
2. DB가 있으면 → status 요약(진행 중 task, 마지막 세션, 총 세션/토큰)을 보고하고 서브커맨드 메뉴를 제시한다.
3. 미초기화면 → "이 프로젝트는 아직 Context Relay가 셋업되지 않았다"고 알리고 `setup`(full) 또는 `init`(basic)을 제안한다.

## 4. 불변 규칙 (모든 서브커맨드 공통)

1. **(a)** `setup`/`capture`/`handoff` 시작 전 해당 reference 문서를 반드시 Read 한다. 절차를 기억에 의존해 진행하지 않는다.
2. **(b)** 모든 DB 접근은 `cr.py` CLI 경유. `sqlite3` 직접 호출·직접 SQL 쓰기 금지 (스키마 보호). 읽기 전용 확인도 `--json` 플래그가 있는 cr.py 커맨드를 우선 사용한다.
3. **(c)** capture는 세션 종료 전 필수다. 사용자가 세션을 마치려는 신호를 보내면 capture 실행 여부를 확인한다.
4. **(d)** handoff 완료 선언 전 PRD §11.2의 6기준(§7 품질 기준 참조)을 자가 점검한다. 하나라도 미달이면 보완 후 재점검한다.
5. **(e)** 민감정보는 cr.py가 저장 직전 자동 마스킹하지만, 프롬프트 원문·diff 요약을 저장하기 전 API 키·토큰·비밀번호류가 없는지 육안으로도 확인한다. 마스킹은 저장 시 1회 적용되며 원문은 보존되지 않는다.

## 5. 서브커맨드별 요약 워크플로우

### 5.1 setup — 공통 작업 헌법 셋업

1. `references/setup-guide.md` Read.
2. AskUserQuestion으로 인터뷰: 프로젝트명, 최종 목표, MVP 범위, 하지 않을 것, 사용 도구, 기술 스택, 배포 목표, 완료 기준, 위험 영역, 기록 정책(프롬프트 원문/요약, 토큰 추적 방식), GitHub 사용 여부.
3. `cr.py init` 실행 → context/ + context-relay/ + DB + config.json 생성.
4. templates/의 `{{PLACEHOLDER}}`를 인터뷰 답변으로 치환해 project-charter.md, PRD.md, TASKS.md(존재하면 보존), CLAUDE.md·AGENTS.md 마커 append, `.cursor/rules/context-relay.mdc` 생성.
5. 초기 handoff.md + next-session-prompt.md 생성, `cr_dashboard.py`로 대시보드 기본 파일 생성.
6. charter를 PRD §11.1 6기준으로 자가 점검 후 완료 보고.

### 5.2 init — 기본 구조만

1. `references/setup-guide.md` Read.
2. `python3 <skill>/scripts/cr.py init [--name NAME]` 실행. idempotent — 재실행해도 안전.
3. 헌법 문서가 없다는 점과 `setup`으로 확장 가능함을 안내.

### 5.3 capture — 세션 기록 (세션 종료 전 필수)

1. `references/capture-protocol.md` Read.
2. 세션 유형 판별: Claude Code 현재 세션이면 대화에서 직접 재구성(`session start`/`session end` 또는 `session log`), 타 도구(Cursor/Codex/Antigravity)면 git diff + 사용자 문답으로 `session log` 사후 기록.
3. `git capture --session N --files`로 git 상태와 변경 파일 저장.
4. `prompt add`로 사용 프롬프트·결과 요약·성공 점수 기록 (config의 `store_prompt_full_text: false`면 요약만 저장).
5. 완료/미완료 작업을 분리해 `task update`, decision·risk 후보를 추출해 `decision add`/`risk add`.
6. handoff.md·daily-worklog.md 등 인계 문서 갱신, `cr_dashboard.py` 재실행.
7. 저장 전 민감정보 육안 확인(불변 규칙 e).

### 5.4 handoff — 인계 문서 생성

1. `references/handoff-guide.md` Read.
2. `python3 <skill>/scripts/cr.py recent --json`으로 번들 수집 (최근 세션·프롬프트·변경 파일·open task·결정·리스크·stats).
3. handoff.md 작성: 현재 상태 / 마지막 목표 / 완료·미완료 / 변경 파일과 이유 / 결정 사항 / 위험 요소 / 다음 세션 할 일 / 추천 프롬프트.
4. daily-worklog.md, decision-log.md, risk-notes.md 동기 갱신.
5. PRD §11.2 6기준 자가 점검 후 완료 선언(불변 규칙 d).

### 5.5 resume — 다음 세션 프롬프트

1. `references/handoff-guide.md` Read.
2. handoff.md와 open task를 기반으로 next-session-prompt.md 생성: 읽을 문서 목록, 이번 세션 목표, 주의사항(수정 금지 영역), 작업 순서, 완료 기준.
3. 다음 AI 도구에 그대로 붙여 넣을 수 있는 형태여야 한다.

### 5.6 search — 작업 이력 검색

1. `references/search-guide.md` Read.
2. 자연어 요청을 FTS5 질의로 변환해 `cr.py search "QUERY" [--entity ...] [--json]` 실행.
3. BM25 순위·snippet을 해석해 보고. FTS5 불가 환경이면 LIKE 폴백이 출력에 표기된다.

### 5.7 dashboard — 시각화

1. `references/dashboard-guide.md` Read.
2. `python3 <skill>/scripts/cr_dashboard.py --root <project>` 실행 → `context-relay/dashboard/index.html` 생성.
3. 파일 경로를 안내하고 핵심 지표(병목 task, 위험 파일, 활동 히트맵)를 요약 해석해 보고.

### 5.8 prompts — 프롬프트 라이브러리

1. `references/handoff-guide.md` Read.
2. `cr.py prompt list [--reuse-only] --json`으로 조회 후 context/prompt-library.md 재생성: 날짜별로 프롬프트 → 구현 결과 → 재사용 가능성 → 개선 메모를 연결.

### 5.9 github-summary — 커밋 메시지·PR 초안

1. `references/github-guide.md` Read.
2. `cr.py git info --json`으로 브랜치·변경 파일·최근 커밋 수집.
3. Conventional Commits 형식 커밋 메시지 후보와 PR 설명 초안(Summary / Changes / Not Completed / Related Context) 생성. 실제 커밋·푸시는 사용자가 요청할 때만.

### 5.10 status — 현재 상태 요약

1. `cr.py stats --json` + `cr.py task list --json` 실행.
2. 진행 중 task, 마지막 세션 시각, 총 세션·프롬프트·토큰·작업 시간을 요약 보고.

## 6. cr.py 커맨드 치트시트

호출 형태: `python3 <skill>/scripts/cr.py <command> [subcommand] [flags]`
공통 플래그: `--root PATH` (기본: cwd에서 위로 올라가며 DB 탐색), `--json`.
종료 코드: `0` 성공 / `1` 일반 오류 / `2` 미초기화. 멀티라인 텍스트는 `--text-file PATH` (`-`는 stdin).

| 커맨드 | 용도 | 대표 플래그 |
|---|---|---|
| `init` | 디렉터리 + DB + config 생성 (idempotent) | `--name NAME` |
| `session start` | 세션 시작 (status=active) → id | `--tool T --agent A --goal G --task N` |
| `session end` | 세션 종료, duration·token 자동 계산 | `--id N --summary S --status ST --task N --tokens-in N --tokens-out N --cost C --duration-sec N` |
| `session log` | 사후 일괄 기록 (타 도구 캡처용) → id | `--tool T --goal G --summary S --started-at ISO --ended-at ISO` |
| `session list` | 세션 목록 | `--limit N --status ST --json` |
| `prompt add` | 프롬프트 기록 (tool/agent는 세션 상속) | `--session N --text TXT --type TYPE --result R --score 1-5 --reuse --files "a,b"` |
| `prompt list` | 프롬프트 조회 | `--session N --reuse-only --type TYPE --json` |
| `task add` / `task update` | task 생성/갱신 | `--title T --status S --priority P --risk L --next A` |
| `task list` | task 목록 | `--status S --json` |
| `file add` / `file list` | 변경 파일 기록/조회 | `--session N --path P --type modified --risk L` |
| `decision add` / `decision list` | 결정 사항 기록/조회 | `--text TXT --reason R --impact I --revisit C` |
| `risk add` / `risk list` | 리스크 기록/조회 | `--text TXT --level L --file F --mitigation M` |
| `git capture` | git 상태 → git_events 저장 | `--session N --files` (files_changed 행 동시 생성 — `--files`는 `--session` 필수) |
| `git info` | 저장 없이 현재 git 상태 출력 | `--json` |
| `agent add` / `agent log` / `agent list` | 에이전트 등록/세션별 사용 기록 | `--session N --agent NAME --duration-sec S --tokens N` |
| `search` | FTS5 BM25 검색 (snippet 포함) | `"QUERY" --limit N --entity prompts --json` |
| `reindex` | 검색 인덱스 전체 재구축 (복구용) | — |
| `stats` | 요약 통계 (세션/토큰/task 상태별/파일 빈도) | `--json` |
| `recent` | handoff 생성용 번들 JSON | `--limit N --json` |
| `export` | 전체 DB → JSON 덤프 | `--out PATH` (기본: exports/) |
| `snapshot` | context/*.md → snapshots/ 복사 | — |

값 제약:

- `prompt --type` ∈ {planning, implementation, debugging, refactoring, testing, deployment, documentation, review, recovery}
- `task --status` ∈ {not_started, in_progress, blocked, needs_review, ready_to_test, completed}
- `session --status` ∈ {planned, active, paused, completed, failed, abandoned} — 단, `session end --status`는 {completed, failed, paused, abandoned} 4종만 (planned·active는 log/list 전용)
- priority·risk ∈ {low, medium, high} — task/file/risk 커맨드 전부 CLI가 강제

### 6.1 config.json 해석 (SKILL 워크플로우 책임)

`context-relay/config.json`의 항목 중 cr.py가 직접 읽는 것은 `masking` 뿐이고, 나머지는 이 SKILL.md 워크플로우가 해석한다.

| 키 | 의미 | 워크플로우 반영 |
|---|---|---|
| `store_prompt_full_text` | `false`면 capture 시 프롬프트를 요약해 저장 | `prompt add` 전 요약 여부 결정 |
| `token_tracking` | `"manual"` / `"estimate"` / `"off"` | estimate면 대화 길이 기반으로 Claude가 추정치 산출, off면 토큰 플래그 생략 |
| `tools` | 이 프로젝트에서 쓰는 도구 목록 | capture 시 tool_name 후보 제시 |
| `github` | GitHub 사용 여부 | false면 git 관련 단계 축소 |
| `language` | 인계 문서 언어 (기본 `ko`) | handoff/resume 문서 언어 |
| `capture_mode` | `"manual"` / `"semi"` | semi면 세션 종료 신호가 보일 때 Claude가 capture를 선제안, manual이면 사용자 요청 시에만 |

### 6.2 오류·종료 코드 대응

- exit `2` (미초기화): 사용자에게 알리고 `setup` 또는 `init`을 제안한다. 임의로 init을 실행하지 않는다.
- exit `1` (일반 오류 / `not found`): stderr 메시지를 읽고 잘못된 id·플래그를 교정해 재시도한다. 같은 오류 반복 시 사용자에게 보고.
- `git capture`/`git info`는 git 미설치·비저장소에서도 경고 후 exit `0` — 파이프라인을 중단하지 말고 git 단계만 건너뛴다.
- FTS 인덱스가 어긋난 정황(검색 결과 누락)이 있으면 `reindex`로 복구한다.

## 7. 스크립트 경로 규칙

- `cr.py`와 `cr_dashboard.py`는 **이 SKILL.md 파일과 같은 디렉터리의 `scripts/` 하위**에 있다. 이 스킬이 `~/.claude/skills/context-relay/`에 설치됐다면 `python3 ~/.claude/skills/context-relay/scripts/cr.py`, 프로젝트 로컬 `.claude/skills/context-relay/`에 설치됐다면 그 경로를 쓴다.
- 설치 위치가 불확실하면 `Glob`으로 `**/context-relay/scripts/cr.py`를 찾아 확정한 뒤 절대 경로로 호출한다.
- 요구사항: `python3` (3.9+). 표준 라이브러리만 사용하므로 pip 설치가 필요 없다.
- 스크립트는 스킬 디렉터리에서 실행하되, 대상 프로젝트는 `--root` 플래그 또는 cwd 기반 자동 탐색으로 지정한다.

## 8. 품질 기준 (완료 선언 전 자가 점검)

| 산출물 | 기준 |
|---|---|
| project-charter | 목표가 한 문장으로 명확 / MVP 범위 구체적 / 하지 않을 것 명확 / 완료 기준 검증 가능 / 모든 AI 도구 공통 규칙 존재 / 위험 영역 명시 |
| handoff | 다음 AI가 바로 이어갈 수 있음 / 완료·미완료 명확 / 변경 파일과 이유 연결 / PRD 관련성 표시 / 위험 파일·수정 금지 영역 표시 / 다음 액션 3~5개로 구체적 |
| 프롬프트 기록 | 원문 보존(또는 정책상 요약) / 사용 도구 표시 / 결과 연결 / 변경 파일 연결 / 재사용 가능 여부 표시 |
| 대시보드 | 10초 안에 상태 파악 / 진행 중 task 명확 / 병목 task·위험 파일 가시화 / 이전 프롬프트·결과 검색 용이 / 다음 할 일 명확 |

## 9. 보안

- **마스킹**: cr.py가 저장 직전 모든 자유 텍스트 컬럼에 마스킹 패턴을 적용한다 (API 키/토큰/비밀번호 할당, sk-/ghp-/AKIA/xox 계열 키, Bearer 헤더, JWT, PEM 블록, .env 값, 연결 문자열 자격증명 postgres://user:pass@host 류). 대체 문자열은 `[MASKED:<종류>]`. `config.json`의 `masking: false`로만 해제 가능(기본 true).
- **로컬 우선**: 모든 데이터는 로컬 SQLite에만 저장된다. 외부 서버 전송 없음.
- **외부 반출은 export만**: 사용자가 명시적으로 `export`를 실행할 때만 JSON 덤프가 생성되며, 반출 여부는 전적으로 사용자 판단이다.

## 10. MVP 경계 — 하지 않는 것

아래 7가지는 의도적으로 범위 밖이다. 사용자가 요청하면 정직하게 "현재 버전의 범위 밖"이라 안내하고, 가능한 대안(수동/반자동 경로)을 제시한다.

1. 모든 도구의 내부 세션 로그 완전 자동 수집 — 타 도구 세션은 git diff + 사용자 문답으로 사후 캡처한다.
2. 클라우드 동기화 — 로컬 저장만 지원한다.
3. 팀 협업 권한 관리.
4. GitHub API 완전 연동 — gh CLI가 있으면 opt-in 참고 수준만.
5. 실시간 토큰 자동 계측 — 수동 입력 또는 대화 길이 기반 추정만.
6. IDE 플러그인 개발.
7. 벡터 DB 기반 의미 검색 — FTS5/BM25 전문 검색만 제공한다.
