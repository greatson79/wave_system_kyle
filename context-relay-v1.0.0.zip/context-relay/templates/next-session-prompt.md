<!--
Context Relay 템플릿 — next-session-prompt.md
사용법: 이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환해 대상 프로젝트의
context/next-session-prompt.md 로 저장한다. resume 워크플로우가 handoff 를 바탕으로
매번 이 구조 그대로 파일을 재생성한다. 치환 후 이 주석을 삭제한다.
구분선(---) 아래 본문이 다음 AI 도구에 그대로 붙여 넣는 프롬프트다.
-->
# Next Session Prompt

> 갱신 시각: {{DATE}} · 기준 세션 ID: {{SESSION_ID}}

아래 구분선 이후 내용을 다음 AI 코딩 도구에 그대로 붙여 넣는다.

---

당신은 이 프로젝트({{PROJECT_NAME}})의 다음 개발 세션을 이어받는다.

먼저 아래 문서를 읽어라.

1. /context/project-charter.md
2. /context/handoff.md
3. /context/decision-log.md
4. /context/risk-notes.md
5. PRD.md
6. TASKS.md

이번 세션의 목표:
{{SESSION_GOAL}}

주의:
{{CAUTIONS}}

작업 순서:
{{WORK_ORDER}}

완료 기준:
{{COMPLETION_CRITERIA}}
- 변경 파일 목록 보고
- PRD와 달라진 점이 있으면 별도 보고
- 세션 종료 전 Context Relay capture 실행 (또는 사용자에게 실행 요청)
