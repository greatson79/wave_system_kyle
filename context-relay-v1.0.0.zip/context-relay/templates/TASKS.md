<!--
Context Relay 템플릿 — TASKS.md
주의: 대상 프로젝트에 TASKS.md가 이미 존재하면 이 템플릿은 사용하지 않는다
(기존 파일 보존 원칙 — architecture.md §1.2). 없을 때만 이중 중괄호(UPPER_SNAKE) 플레이스홀더를
치환해 프로젝트 루트의 TASKS.md 로 저장한다. 치환 후 이 주석과 (예시) 행을 삭제한다.
-->
# TASKS: {{PROJECT_NAME}}

> 생성일: {{DATE}}
>
> 상태 어휘 (cr.py task 상태와 동일):
> `not_started` | `in_progress` | `blocked` | `needs_review` | `ready_to_test` | `completed`
>
> 우선순위 어휘: `low` | `medium` | `high`
>
> 이 표는 사람이 읽는 요약이다. 원천 데이터는 `context-relay/context-relay.sqlite` 의
> tasks 테이블이며, task 추가·상태 변경 시 `cr.py task add` / `cr.py task update` 로
> DB에도 함께 반영한다. ID는 DB tasks.id 와 일치시킨다.

| ID | 제목 | 상태 | 우선순위 | PRD 참조 | 다음 액션 |
|----|------|------|----------|----------|-----------|
| 1 | (예시) 프로젝트 초기 구조 세팅 | not_started | high | PRD §5 | 개발 환경 구성 후 첫 화면 골격 작성 |
