<!--
Context Relay 템플릿 — PRD.md
주의: 대상 프로젝트에 PRD.md가 이미 존재하면 이 템플릿은 사용하지 않는다
(기존 파일 보존 원칙 — architecture.md §1.2). 없을 때만 setup 인터뷰 답변으로
이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환해 프로젝트 루트의 PRD.md 로 저장한다.
치환 후 이 주석을 삭제한다.
-->
# PRD: {{PROJECT_NAME}}

> 생성일: {{DATE}} · 이 문서는 경량 PRD다. 상세 헌법은 `context/project-charter.md` 참조.

## 1. 문제 정의

이 프로젝트가 해결하려는 문제와 현재 상황:

{{PROBLEM_STATEMENT}}

## 2. 목표

{{PRODUCT_GOAL}}

## 3. 대상 사용자

{{TARGET_USERS}}

## 4. 핵심 기능

| 번호 | 기능 | 설명 | 우선순위 |
|------|------|------|----------|
| 1 | {{FEATURE_1}} | {{FEATURE_1_DESC}} | high |

## 5. MVP 범위

이번 버전에 포함:

{{MVP_SCOPE}}

## 6. 제외 범위

이번 버전에서 하지 않을 것:

{{NON_GOALS}}

## 7. 성공 지표

이 프로젝트가 성공했다고 판단하는 기준:

{{SUCCESS_METRICS}}

완료 기준(Definition of Done)은 `context/project-charter.md` 의 Definition of Done 을 따른다.
