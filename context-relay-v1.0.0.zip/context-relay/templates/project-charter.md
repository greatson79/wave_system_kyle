<!--
Context Relay 템플릿 — project-charter.md
사용법: setup 인터뷰 답변으로 이중 중괄호(UPPER_SNAKE) 플레이스홀더를 모두 치환한 뒤,
대상 프로젝트의 context/project-charter.md 로 저장한다. 치환 후 이 주석을 삭제한다.
품질 자가점검 (PRD §11.1 — 완료 선언 전 6개 모두 통과):
1. 프로젝트 목표가 한 문장으로 명확하다.
2. MVP 범위가 구체적이다.
3. 하지 않을 것이 명확하다.
4. 완료 기준이 검증 가능하다.
5. 모든 AI 도구가 따라야 할 공통 규칙이 있다.
6. 위험 영역이 명시되어 있다.
-->
# Project Charter

> 생성일: {{DATE}} · 이 문서는 프로젝트의 헌법이다. 모든 AI 코딩 도구는 작업 전 이 문서를 읽는다.

## Project Name

{{PROJECT_NAME}}

## Product Goal

이 프로젝트가 최종적으로 해결하려는 문제 (한 문장):

{{PRODUCT_GOAL}}

## MVP Scope

이번 버전에서 반드시 구현할 범위:

{{MVP_SCOPE}}

## Non-Goals

이번 버전에서 하지 않을 것:

{{NON_GOALS}}

## Target Users

{{TARGET_USERS}}

## Tech Stack

{{TECH_STACK}}

## Deployment Target

{{DEPLOY_TARGET}}

## Definition of Done

검증 가능한 완료 기준:

{{DOD}}

## AI Tool Rules

사용 도구: {{TOOLS}}

모든 AI 코딩 도구가 따라야 할 공통 규칙:

{{AI_TOOL_RULES}}

- PRD와 TASKS에 없는 작업을 임의로 시작하지 않는다.
- MVP 범위를 벗어나는 기능은 제안만 하고 구현하지 않는다.
- 구조 변경, 라이브러리 추가, DB 스키마 변경은 decision-log 후보로 기록한다.
- 핵심 파일을 수정할 때는 변경 이유를 명시한다.

## Risk Areas

건드리면 위험한 파일, 모듈, 정책:

{{RISK_AREAS}}

## Session Handoff Rule

모든 세션은 종료 전에 Context Relay capture를 실행한다.
Claude Code에서는 `/context-relay capture` 를 실행하고, 다른 도구에서는 세션 종료 후
사용자가 Claude Code에서 capture 워크플로우를 실행해 사후 기록한다.
