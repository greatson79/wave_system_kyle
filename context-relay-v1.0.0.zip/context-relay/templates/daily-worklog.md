<!--
Context Relay 템플릿 — daily-worklog.md
사용법: 최초 setup 시에는 "# Daily Worklog" 제목과 안내 인용문만 남기고
context/daily-worklog.md 로 저장한다. capture/handoff 워크플로우가 세션을 기록할 때마다
아래 "날짜 헤딩 + 세션 항목" 골격을 복제해 이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환하고,
최신 날짜가 위로 오게 추가한다 (같은 날짜면 기존 날짜 헤딩 아래에 세션 항목만 추가).
치환 후 이 주석을 삭제한다.
-->
# Daily Worklog

> 날짜별·세션별 작업 기록. 원천 데이터는 `context-relay/context-relay.sqlite` 의
> sessions 테이블이며, 이 문서는 사람이 읽는 요약이다.

## {{DATE}}

### {{TIME}} · {{TOOL_NAME}} · 세션 {{SESSION_ID}}

- 목표: {{SESSION_GOAL}}
- 결과: {{SESSION_RESULT}}
- 상태: {{SESSION_STATUS}}
- 작업 시간: {{DURATION}}
- 토큰: {{TOKEN_TOTAL}}
