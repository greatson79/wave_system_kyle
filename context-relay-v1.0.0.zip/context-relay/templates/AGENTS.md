<!--
Context Relay 템플릿 — AGENTS.md
사용법: 이 안내 주석을 삭제한 뒤 사용한다. 대상 프로젝트에 AGENTS.md 가 없으면
이 파일 전체를 프로젝트 루트의 AGENTS.md 로 복사한다. 이미 존재하면 파일을 덮어쓰지 않고
아래 마커 블록(context-relay:begin ~ context-relay:end)만 append 한다. 이미 마커가 있으면
블록 내부만 교체한다 (idempotent — architecture.md §1.2). 플레이스홀더 없음 — 본문은
PRD §6.0.6 예시 그대로 영어를 유지한다.
-->
# AGENTS.md

<!-- context-relay:begin -->
## Global Agent Rule

This repository uses Context Relay to preserve project memory across AI coding tools.

## Required Reading Before Work

- `/context/project-charter.md`
- `/PRD.md`
- `/TASKS.md`
- `/context/handoff.md`
- `/context/decision-log.md`
- `/context/risk-notes.md`

## Agent Behavior

- Stay aligned with the current active task.
- Do not introduce unrelated refactoring.
- Do not change architecture without recording the decision.
- Report any divergence from PRD before implementation.
- Record prompts, implementation result, changed files, and unresolved issues.

## After Work

Generate or update:

- `/context/handoff.md`
- `/context/next-session-prompt.md`
- `/context/daily-worklog.md`
- `/context/decision-log.md`
- `/context/risk-notes.md`

Before ending the session, run the Context Relay capture workflow
(`/context-relay capture` in Claude Code), or ask the user to run it
from Claude Code if this tool cannot run it directly.
<!-- context-relay:end -->
