<!--
Context Relay 템플릿 — risk-notes.md
사용법: 최초 setup 시에는 "# Risk Notes" 제목과 안내 인용문만 남기고
context/risk-notes.md 로 저장한다 (setup 인터뷰에서 위험 영역 답변이 있으면 그 항목을
즉시 추가). 위험이 추가될 때마다 아래 항목 골격을 복제해 이중 중괄호(UPPER_SNAKE) 플레이스홀더를
치환하고, 수준(high 우선)과 최신순으로 정렬해 추가한다. 치환 후 이 주석을 삭제한다.
수준 어휘 (cr.py risk 수준과 동일): low | medium | high
-->
# Risk Notes

> 건드리면 위험한 파일·모듈·정책과 알려진 위험 요소 기록.
> 원천 데이터는 `context-relay/context-relay.sqlite` 의 risks 테이블이다.

## {{RISK_TITLE}}

- 위험: {{RISK_TEXT}}
- 수준: {{RISK_LEVEL}}
- 관련 파일: {{RELATED_FILE}}
- 완화책: {{MITIGATION}}
- 날짜: {{DATE}}
