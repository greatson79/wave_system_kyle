<!--
Context Relay 템플릿 — CLAUDE-section.md
사용법: 이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환하고 이 안내 주석을 삭제한 뒤,
아래 마커 블록(context-relay:begin ~ context-relay:end)만 대상 프로젝트의 CLAUDE.md 에
append 한다. CLAUDE.md 전체를 덮어쓰지 않는다. 이미 마커가 있으면 블록 내부만 교체한다
(idempotent — architecture.md §1.2). CLAUDE.md 가 없으면 "# CLAUDE.md" 제목 아래에
이 블록으로 새 파일을 생성한다.
-->
<!-- context-relay:begin -->
## Context Relay

이 프로젝트({{PROJECT_NAME}})는 Context Relay로 작업 맥락을 관리한다.

### Project Context

먼저 아래 문서를 순서대로 읽고 작업을 시작하라.

1. `/context/project-charter.md`
2. `/PRD.md`
3. `/TASKS.md`
4. `/context/handoff.md`
5. `/context/decision-log.md`
6. `/context/risk-notes.md`

### Working Rules

- PRD와 TASKS에 없는 작업을 임의로 시작하지 말 것.
- MVP 범위를 벗어나는 기능은 제안만 하고 구현하지 말 것.
- 구조 변경, 라이브러리 추가, DB 스키마 변경은 decision-log 후보로 기록할 것.
- 핵심 파일을 수정할 때는 변경 이유를 명시할 것.
- 작업 종료 전 Context Relay capture를 실행할 것.

### Session Start Protocol

1. handoff.md를 읽는다.
2. 현재 진행 task를 확인한다.
3. risk-notes.md를 확인한다.
4. next-session-prompt.md의 목표를 따른다.

### Session End Protocol

1. 변경 파일을 요약한다.
2. 완료/미완료 작업을 분리한다.
3. 사용한 프롬프트와 결과를 기록한다.
4. 다음 세션용 handoff를 갱신한다.

세션 종료 전 반드시 `/context-relay capture` 를 실행한다.
<!-- context-relay:end -->
