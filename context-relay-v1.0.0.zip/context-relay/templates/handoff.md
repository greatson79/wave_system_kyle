<!--
Context Relay 템플릿 — handoff.md
사용법: 이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환해 대상 프로젝트의 context/handoff.md 로
저장한다. capture/handoff 워크플로우가 매번 이 구조 그대로 파일을 재생성한다.
치환 후 이 주석을 삭제한다.
품질 자가점검 (PRD §11.2 — 완료 선언 전 6개 모두 통과):
1. 다음 AI가 바로 작업을 이어갈 수 있다.
2. 완료/미완료가 명확하다.
3. 변경 파일과 변경 이유가 연결되어 있다.
4. PRD와의 관련성이 표시된다.
5. 위험 파일과 수정 금지 영역이 표시된다.
6. 다음 액션이 3~5개로 구체적이다.
-->
# Handoff

> 갱신 시각: {{DATE}} · 세션 ID: {{SESSION_ID}} · 도구: {{TOOL_NAME}}

## 현재 프로젝트 상태

{{PROJECT_STATUS}}

## 마지막 작업 목표

{{SESSION_GOAL}}

## 완료된 작업

{{DONE_ITEMS}}

## 미완료 작업

{{TODO_ITEMS}}

## 변경된 주요 파일

파일 경로 · 변경 유형 · 변경 이유 · 위험도를 함께 적는다.

{{CHANGED_FILES}}

## 중요한 결정 사항

{{DECISIONS}}

## 위험 요소

수정 금지 영역과 위험 파일을 명시한다.

{{RISKS}}

## 다음 세션에서 바로 할 일

구체적인 액션 3~5개. PRD/TASKS 참조를 함께 적는다.

{{NEXT_ACTIONS}}

## 다음 세션 추천 프롬프트

전체 프롬프트는 `context/next-session-prompt.md` 참조.

{{NEXT_SESSION_PROMPT}}
