<!--
Context Relay 템플릿 — prompt-library.md
사용법: 최초 setup 시에는 "# Prompt Library" 제목과 안내 인용문만 남기고
context/prompt-library.md 로 저장한다. prompts 워크플로우가 DB의 prompts 테이블에서
아래 "날짜 헤딩 + Prompt 항목" 골격을 복제·치환해 재생성한다 (같은 날짜의 프롬프트는
같은 날짜 헤딩 아래에 시간순으로 나열). {{PROMPT_ID}} 는 3자리 순번(예: 001)으로 채운다.
치환 후 이 주석을 삭제한다.
유형 어휘 (cr.py prompt_type 과 동일): planning | implementation | debugging |
refactoring | testing | deployment | documentation | review | recovery
-->
# Prompt Library

> 사용한 프롬프트와 그 구현 결과의 연결 기록.
> 원천 데이터는 `context-relay/context-relay.sqlite` 의 prompts 테이블이다.

## {{DATE}}

### Prompt {{PROMPT_ID}}

도구: {{TOOL_NAME}}
유형: {{PROMPT_TYPE}}
목표: {{PROMPT_GOAL}}

#### 프롬프트

{{PROMPT_TEXT}}

#### AI 구현 결과

{{RESULT_SUMMARY}}

#### 재사용 가능성

{{REUSE_CANDIDATE}}

#### 개선 메모

{{IMPROVEMENT_NOTE}}
