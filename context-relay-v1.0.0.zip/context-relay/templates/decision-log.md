<!--
Context Relay 템플릿 — decision-log.md
사용법: 최초 setup 시에는 "# Decision Log" 제목과 안내 인용문만 남기고
context/decision-log.md 로 저장한다. 결정이 추가될 때마다 아래 항목 골격을 복제해
이중 중괄호(UPPER_SNAKE) 플레이스홀더를 치환하고, 최신 항목이 위로 오게 추가한다.
치환 후 이 주석을 삭제한다.
-->
# Decision Log

> 구조 변경, 라이브러리 선택, 정책 결정 등 프로젝트의 중요한 판단 기록.
> 원천 데이터는 `context-relay/context-relay.sqlite` 의 decisions 테이블이다.

## {{DECISION_TITLE}}

- 결정: {{DECISION_TEXT}}
- 이유: {{DECISION_REASON}}
- 영향: {{DECISION_IMPACT}}
- 재검토 조건: {{REVISIT_CONDITION}}
- 날짜·세션: {{DATE}} · 세션 {{SESSION_ID}}
