# Context Relay

**여러 AI 코딩 도구를 넘나드는 프로젝트 맥락 인계 시스템** — Claude Code 스킬.

Claude Code, Cursor, Antigravity, Codex 등 여러 AI 코딩 도구에서 흩어진 작업 맥락을 날짜별·작업별·프롬프트별로 기록하고, 다음 세션에서 바로 이어갈 수 있도록 인계 문서, SQLite 기반 작업 기억 저장소, 검색 시스템, 대시보드를 제공한다.

## 프로젝트 블랙박스

AI 코딩에서 가장 위험한 것은 코드가 틀리는 것이 아니라 **프로젝트의 기억이 사라지는 것**이다. 파일은 남지만 — 왜 이 라이브러리를 선택했는지, 어떤 파일은 건드리면 안 되는지, 어떤 프롬프트가 효과적이었는지, 다음 세션에서 무엇부터 해야 하는지는 사라진다.

> AI 코딩 도구는 점점 많아진다. 하지만 프로젝트의 기억은 흩어진다.
> Context Relay는 프로젝트 시작 시 공통 헌법을 세우고, 작업 중 흩어진 기억을 모아, 다음 세션이 바로 이어 달릴 수 있게 만든다. (PRD §16)

> Context Relay는 Claude Code, Cursor, Antigravity, Codex를 오가며 작업해도 프로젝트의 목표, 판단, 프롬프트, 변경 이력, 현재 task, 다음 행동을 잃지 않게 해주는 **AI 개발 블랙박스**다. (PRD §17)

## 설치

이 폴더 전체를 Claude Code 스킬 디렉터리로 복사한다.

```bash
# 전역 설치 (모든 프로젝트에서 사용)
cp -r context-relay ~/.claude/skills/context-relay

# 또는 특정 프로젝트에만 설치
cp -r context-relay <project>/.claude/skills/context-relay
```

요구사항:

- Claude Code
- `python3` (3.9 이상) — 표준 라이브러리만 사용하므로 pip 등 외부 의존성 설치가 전혀 필요 없다

## 빠른 시작

**1. 프로젝트 셋업** — 프로젝트 루트에서 Claude Code를 열고:

```text
/context-relay setup
```

프로젝트 목표, MVP 범위, 사용할 도구, 기술 스택, 완료 기준을 질문받은 뒤 project-charter.md, PRD.md, TASKS.md, CLAUDE.md, AGENTS.md, Cursor Rules, SQLite DB, 대시보드가 생성된다. 이후 모든 AI 코딩 도구가 같은 기준 문서를 읽고 작업한다.

**2. 평소처럼 작업** — Claude Code, Cursor, Codex 등 원하는 도구로 개발한다.

**3. 세션 종료 시 캡처**:

```text
/context-relay capture
```

git diff, 변경 파일, 사용 프롬프트, 결정 사항, 리스크가 SQLite에 저장되고 인계 문서와 대시보드가 갱신된다. Cursor·Codex 등 다른 도구에서 한 작업도 git diff + 문답으로 사후 캡처할 수 있다.

**4. 다른 도구에서 이어가기** — Cursor나 Codex를 열면 AGENTS.md / Cursor Rules 지시에 따라 `/context/handoff.md`와 `/context/next-session-prompt.md`를 읽고 이전 맥락을 이어받아 작업을 계속한다. 매번 프로젝트를 다시 설명할 필요가 없다.

## 명령어

| 명령 | 하는 일 |
|---|---|
| `/context-relay setup` | 인터뷰 후 공통 작업 헌법 + 도구별 지침 + DB + 대시보드 전체 생성 |
| `/context-relay init` | context/ 폴더와 DB 등 기본 구조만 생성 |
| `/context-relay capture` | 현재 세션의 변경 내역·프롬프트·결정·리스크를 저장 (세션 종료 전 필수) |
| `/context-relay handoff` | 다음 세션 인계 문서(handoff.md 등) 생성·갱신 |
| `/context-relay resume` | 다음 AI 도구에 붙여 넣을 세션 프롬프트 생성 |
| `/context-relay search "질의"` | FTS5/BM25로 세션·프롬프트·결정·파일 변경 검색 |
| `/context-relay dashboard` | 로컬 정적 HTML 대시보드 생성·갱신 |
| `/context-relay prompts` | 프롬프트 라이브러리 생성·조회 |
| `/context-relay github-summary` | git 상태 기반 커밋 메시지·PR 설명 초안 생성 |
| `/context-relay status` | 현재 task·세션·토큰 요약 보고 |

인자 없이 `/context-relay`만 호출하면: 초기화된 프로젝트에서는 status 요약과 메뉴를, 미초기화 프로젝트에서는 setup을 제안한다.

## 생성되는 파일 구조

setup 후 대상 프로젝트에는 다음이 생성된다.

```text
<project-root>/
├── PRD.md                      # 없으면 생성, 있으면 보존
├── TASKS.md                    # 없으면 생성, 있으면 보존
├── CLAUDE.md                   # Context Relay 섹션만 append (기존 내용 보존)
├── AGENTS.md                   # Context Relay 섹션만 append (기존 내용 보존)
├── .cursor/rules/context-relay.mdc
├── context/                    # 사람·AI가 읽는 인계 문서
│   ├── project-charter.md      # 프로젝트 헌법
│   ├── handoff.md              # 인계서
│   ├── next-session-prompt.md  # 다음 세션 프롬프트
│   ├── daily-worklog.md
│   ├── decision-log.md
│   ├── risk-notes.md
│   └── prompt-library.md
└── context-relay/              # 기억 저장소
    ├── context-relay.sqlite    # 원천 데이터 (세션·프롬프트·task·결정·리스크·git)
    ├── config.json
    ├── dashboard/index.html    # 자체완결 정적 대시보드
    ├── exports/                # JSON 덤프 출력처
    └── snapshots/              # context/*.md 스냅샷
```

## FAQ

**Q. Cursor나 Codex 세션도 자동으로 기록되나요?**
아니요. 도구 내부 로그 자동 수집은 MVP 범위 밖이다. 대신 **사후 캡처** 방식을 쓴다 — 다른 도구에서 작업한 뒤 Claude Code로 돌아와 `/context-relay capture`를 실행하면, git diff 분석과 사용자 문답으로 그 세션을 재구성해 `tool_name`을 해당 도구로 기록한다.

**Q. 데이터는 어디로 가나요?**
전부 로컬이다. 프로젝트 안의 `context-relay/context-relay.sqlite` 한 파일에 저장되고 외부 서버 전송은 없다. 외부 반출은 사용자가 명시적으로 export를 실행할 때만 JSON으로 생성된다.

**Q. SQLite DB를 직접 열어도 되나요?**
읽기는 자유다. DB 브라우저나 `sqlite3`로 열어봐도 된다. 다만 **쓰기는 반드시 `scripts/cr.py`를 경유**해야 한다 — 직접 INSERT/UPDATE 하면 FTS5 검색 인덱스 동기화와 민감정보 마스킹이 건너뛰어져 데이터가 어긋난다.

**Q. API 키 같은 민감정보가 프롬프트에 있으면요?**
cr.py가 저장 직전에 자동 마스킹한다 (API 키·토큰·비밀번호 할당, GitHub/AWS/Slack 키, Bearer 헤더, JWT, PEM 블록, .env 값 등을 `[MASKED:<종류>]`로 치환). 마스킹은 저장 시 1회 적용되고 원문은 보존되지 않는다. 그래도 저장 전 육안 확인을 권장한다.

**Q. 기존 CLAUDE.md가 있는데 덮어쓰나요?**
아니요. `CLAUDE.md`와 `AGENTS.md`는 마커 블록(`<!-- context-relay:begin -->` … `<!-- context-relay:end -->`)만 append 하고 기존 내용은 보존한다. 재실행 시 블록 내부만 교체된다. `PRD.md`/`TASKS.md`/`README.md`는 이미 존재하면 건드리지 않는다.
