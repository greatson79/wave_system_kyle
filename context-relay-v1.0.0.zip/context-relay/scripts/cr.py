#!/usr/bin/env python3
"""Context Relay deterministic engine.

Single-file CLI: DB init / CRUD / FTS5 search / masking / git capture / stats.
Contract: references/architecture.md (SSOT). Python 3.9+, stdlib only.
"""

import argparse
import json
import re
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SCHEMA_VERSION = "1"
DB_RELPATH = Path("context-relay") / "context-relay.sqlite"

PROMPT_TYPES = [
    "planning", "implementation", "debugging", "refactoring", "testing",
    "deployment", "documentation", "review", "recovery",
]
TASK_STATUSES = [
    "not_started", "in_progress", "blocked", "needs_review",
    "ready_to_test", "completed",
]
SESSION_STATUSES = ["planned", "active", "paused", "completed", "failed", "abandoned"]
SESSION_END_STATUSES = ["completed", "failed", "paused", "abandoned"]
PRIORITIES = ["low", "medium", "high"]
FILE_CHANGE_TYPES = ["added", "modified", "deleted", "renamed"]

# CLI --entity value -> search_index.entity_type value
ENTITY_MAP = {
    "sessions": "session", "prompts": "prompt", "tasks": "task",
    "decisions": "decision", "risks": "risk", "files": "file",
}
# entity_type -> source table
TABLE_BY_ETYPE = {
    "session": "sessions", "prompt": "prompts", "task": "tasks",
    "decision": "decisions", "risk": "risks", "file": "files_changed",
}

DEFAULT_CONFIG = {
    "version": 1,
    "project_name": "",
    "tools": ["claude-code", "cursor", "codex", "antigravity"],
    "store_prompt_full_text": True,
    "token_tracking": "estimate",
    "masking": True,
    "github": True,
    "language": "ko",
    "capture_mode": "manual",
}

# --- DDL (architecture.md section 4, verbatim) ------------------------------

DDL = """
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  root_path TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  tool_name TEXT NOT NULL,
  agent_name TEXT,
  started_at TEXT,
  ended_at TEXT,
  duration_sec INTEGER,
  session_goal TEXT,
  user_request TEXT,
  summary TEXT,
  status TEXT,
  token_input INTEGER DEFAULT 0,
  token_output INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  estimated_cost REAL DEFAULT 0,
  linked_task_id INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  tool_name TEXT,
  agent_name TEXT,
  prompt_text TEXT NOT NULL,
  prompt_type TEXT,
  related_files TEXT,
  result_summary TEXT,
  success_score INTEGER,
  reuse_candidate INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT,
  priority TEXT,
  prd_reference TEXT,
  risk_level TEXT,
  current_next_action TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS files_changed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  change_type TEXT,
  change_summary TEXT,
  risk_level TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  decision_text TEXT NOT NULL,
  reason TEXT,
  impact TEXT,
  revisit_condition TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS risks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  risk_text TEXT NOT NULL,
  risk_level TEXT,
  related_file TEXT,
  mitigation TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS git_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  session_id INTEGER,
  commit_hash TEXT,
  branch_name TEXT,
  diff_summary TEXT,
  changed_files_count INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  role TEXT,
  tool_name TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS session_agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  agent_id INTEGER NOT NULL,
  duration_sec INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  result_summary TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(id),
  FOREIGN KEY(agent_id) REFERENCES agents(id)
);

CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_prompts_session ON prompts(session_id);
CREATE INDEX IF NOT EXISTS idx_files_session ON files_changed(session_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
"""

FTS_DDL = """
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
  entity_type UNINDEXED,
  entity_id UNINDEXED,
  title,
  body,
  created_at UNINDEXED,
  tokenize = 'unicode61'
);
"""

# --- errors / basics --------------------------------------------------------


class CLIError(Exception):
    """Error with an explicit exit code (1=error, 2=not initialized)."""

    def __init__(self, message, code=1):
        super().__init__(message)
        self.code = code


class Parser(argparse.ArgumentParser):
    """argparse exits 2 on usage errors by default; keep exit 2 reserved
    for 'not initialized' per the contract, so usage errors exit 1."""

    def error(self, message):
        self.print_usage(sys.stderr)
        sys.stderr.write("error: {}\n".format(message))
        sys.exit(1)


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def stamp():
    return datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")


def eprint(msg):
    print(msg, file=sys.stderr)


def jdump(obj, compact=False):
    if compact:
        return json.dumps(obj, ensure_ascii=False, default=str)
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str)


# --- root / db / config -----------------------------------------------------


def find_root(root_arg):
    """Locate the project root containing context-relay/context-relay.sqlite."""
    if root_arg:
        root = Path(root_arg).resolve()
        if (root / DB_RELPATH).exists():
            return root
        raise CLIError(
            "Context Relay is not initialized at {} (run: cr.py init --root {})".format(root, root), 2)
    cur = Path.cwd().resolve()
    for p in (cur, *cur.parents):
        if (p / DB_RELPATH).exists():
            return p
    raise CLIError(
        "Context Relay is not initialized (no context-relay/context-relay.sqlite found "
        "from {} upward). Run: cr.py init".format(cur), 2)


def open_db(root):
    conn = sqlite3.connect(str(root / DB_RELPATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def load_config(root):
    cfg_path = root / "context-relay" / "config.json"
    if not cfg_path.exists():
        return dict(DEFAULT_CONFIG)
    try:
        with open(cfg_path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return dict(DEFAULT_CONFIG)


def get_ctx(args):
    """Return (root, conn, mask_fn) for an initialized project."""
    root = find_root(getattr(args, "root", None))
    conn = open_db(root)
    cfg = load_config(root)
    mask = mask_text if cfg.get("masking", True) else (lambda t: t)
    return root, conn, mask


def get_project(conn):
    row = conn.execute("SELECT * FROM projects ORDER BY id LIMIT 1").fetchone()
    if row is None:
        raise CLIError("no project row found; run: cr.py init", 2)
    return row


def require_row(conn, table, rid, label):
    row = conn.execute("SELECT * FROM {} WHERE id=?".format(table), (rid,)).fetchone()
    if row is None:
        raise CLIError("{} id={} not found".format(label, rid), 1)
    return row


# --- masking (architecture.md section 3.3, 10 patterns) ---------------------

# 1. key=value assignment: mask the value part only. The trigger keyword may
#    appear anywhere in the LHS identifier (SECRET_KEY=, MY_API_TOKEN=, ...).
RE_ASSIGN = re.compile(
    r'(?i)([A-Za-z0-9_.\-]*(?:api[_-]?key|apikey|secret|token|passwd|password|private[_-]?key|'
    r'access[_-]?key|client[_-]?secret|auth[_-]?token|credential)[A-Za-z0-9_.\-]*'
    r'\s*[:=]\s*["\']?)(\S{6,})')
# 2. OpenAI/Anthropic style keys
RE_SK = re.compile(r'sk-[A-Za-z0-9_-]{16,}')
# 3. GitHub tokens
RE_GH = re.compile(r'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}')
RE_GH_PAT = re.compile(r'\bgithub_pat_[A-Za-z0-9_]{20,}')
# 4. AWS access key id
RE_AWS = re.compile(r'\bAKIA[0-9A-Z]{16}\b')
# 5. Slack tokens
RE_SLACK = re.compile(r'\bxox[baprs]-[A-Za-z0-9-]{10,}')
# 6. Bearer headers
RE_BEARER = re.compile(r'(?i)\bbearer\s+[A-Za-z0-9\-_.=]{16,}')
# 7. JWT
RE_JWT = re.compile(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}')
# 8. PEM private key blocks
RE_PEM = re.compile(
    r'-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----', re.S)
# 10. credentials embedded in connection strings (postgres://user:pass@host)
RE_URL_CRED = re.compile(r'(?i)\b([a-z][a-z0-9+.\-]*://[^\s:@/]+:)([^\s:@/]{3,})@')
# 9. .env lines inside diffs / grep-style output
RE_DIFF_HEADER = re.compile(
    r'^(?:diff --git a/(\S+) b/(\S+)|\+\+\+ b?/?(\S+)|--- a?/?(\S+)|Index: (\S+))')
RE_ENV_PATH = re.compile(r'(?:^|[\\/])\.env(?:\.[\w.-]+)?$')
RE_KV_LINE = re.compile(r'^([+\- ]?\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*)\S.*$')
RE_ENV_GREP = re.compile(r'^(\S*\.env[\w.-]*:\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*)\S.*$')


def _mask_env_lines(text):
    out = []
    in_env_file = False
    for line in text.split("\n"):
        header = RE_DIFF_HEADER.match(line)
        if header:
            path = next((g for g in header.groups() if g), "")
            in_env_file = bool(RE_ENV_PATH.search(path))
            out.append(line)
            continue
        m = RE_ENV_GREP.match(line)
        if m:
            out.append(m.group(1) + "[MASKED:env]")
            continue
        if in_env_file:
            line = RE_KV_LINE.sub(lambda mm: mm.group(1) + "[MASKED:env]", line)
        out.append(line)
    return "\n".join(out)


def _assign_repl(m):
    # Known limitation (architecture.md 3.3): values that look like code
    # (function calls, e.g. "token = generateToken()") are left unmasked to
    # preserve prompt-library value; real secrets rarely contain "(".
    if "(" in m.group(2):
        return m.group(0)
    return m.group(1) + "[MASKED:assignment]"


def mask_text(text):
    """Apply all masking patterns (contract 3.3). None passes through."""
    if text is None:
        return None
    t = RE_PEM.sub("[MASKED:private-key]", text)
    t = _mask_env_lines(t)
    t = RE_URL_CRED.sub(r"\1[MASKED:credential]@", t)
    t = RE_ASSIGN.sub(_assign_repl, t)
    t = RE_SK.sub("[MASKED:api-key]", t)
    t = RE_GH.sub("[MASKED:github-token]", t)
    t = RE_GH_PAT.sub("[MASKED:github-token]", t)
    t = RE_AWS.sub("[MASKED:aws-key]", t)
    t = RE_SLACK.sub("[MASKED:slack-token]", t)
    t = RE_BEARER.sub("[MASKED:bearer-token]", t)
    t = RE_JWT.sub("[MASKED:jwt]", t)
    return t


# --- FTS sync (architecture.md section 3.2) ---------------------------------


def fts_on(conn):
    row = conn.execute("SELECT value FROM meta WHERE key='fts_enabled'").fetchone()
    return row is not None and row["value"] == "1"


def fts_fields(etype, r):
    """title/body mapping per the contract table."""
    def g(key):
        v = r.get(key)
        if v is None:
            return ""
        return v if isinstance(v, str) else str(v)

    if etype == "session":
        title = g("session_goal") or g("tool_name")
        body = " ".join(x for x in (g("summary"), g("user_request")) if x)
    elif etype == "prompt":
        title = " ".join(x for x in (g("prompt_type"), g("result_summary")[:60]) if x) or "prompt"
        body = " ".join(x for x in (g("prompt_text"), g("result_summary")) if x)
    elif etype == "task":
        title = g("title")
        body = " ".join(x for x in (g("description"), g("current_next_action")) if x)
    elif etype == "decision":
        title = g("decision_text")[:80]
        body = " ".join(x for x in (g("decision_text"), g("reason"), g("impact")) if x)
    elif etype == "risk":
        title = g("risk_text")[:80]
        body = " ".join(x for x in (g("risk_text"), g("mitigation"), g("related_file")) if x)
    elif etype == "file":
        title = g("file_path")
        body = " ".join(x for x in (g("change_summary"), g("change_type")) if x)
    else:
        title, body = "", ""
    return title, body


def fts_upsert(conn, etype, eid, title, body, created_at):
    if not fts_on(conn):
        return
    conn.execute(
        "DELETE FROM search_index WHERE entity_type=? AND entity_id=?",
        (etype, str(eid)))
    conn.execute(
        "INSERT INTO search_index(entity_type, entity_id, title, body, created_at) "
        "VALUES(?,?,?,?,?)",
        (etype, str(eid), title or "", body or "", created_at or ""))


def sync_fts(conn, etype, eid):
    """Refetch the row and upsert its search_index entry."""
    table = TABLE_BY_ETYPE[etype]
    row = conn.execute("SELECT * FROM {} WHERE id=?".format(table), (eid,)).fetchone()
    if row is None:
        return
    d = dict(row)
    title, body = fts_fields(etype, d)
    fts_upsert(conn, etype, eid, title, body, d.get("created_at", ""))


# --- output helpers ----------------------------------------------------------


def emit_created(args, conn, table, rid, note=""):
    """Creation commands must include 'id=N'; --json emits the full row."""
    if getattr(args, "json", False):
        row = conn.execute("SELECT * FROM {} WHERE id=?".format(table), (rid,)).fetchone()
        print(jdump(dict(row), compact=True))
    else:
        line = "id={}".format(rid)
        if note:
            line += " " + note
        print(line)


def read_text_input(args):
    """--text or --text-file PATH ('-' = stdin)."""
    if getattr(args, "text", None) is not None:
        return args.text
    path = getattr(args, "text_file", None)
    if path is None:
        raise CLIError("either --text or --text-file is required")
    if path == "-":
        return sys.stdin.read()
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError as exc:
        raise CLIError("cannot read --text-file {}: {}".format(path, exc))


# --- git helpers -------------------------------------------------------------


def run_git(root, *argv):
    """Run a git command; return stdout (rstripped) or None on any failure."""
    try:
        proc = subprocess.run(
            ["git"] + list(argv), cwd=str(root),
            capture_output=True, text=True, timeout=30)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    if proc.returncode != 0:
        return None
    return proc.stdout.rstrip("\n")


def is_git_repo(root):
    return run_git(root, "rev-parse", "--is-inside-work-tree") == "true"


def parse_porcelain(status_text):
    """Parse `git status --porcelain` -> [(change_type, path)]."""
    entries = []
    for line in (status_text or "").splitlines():
        if len(line) < 4 or not line.strip():
            continue
        code, path = line[:2], line[3:]
        if code == "??":
            ctype = "added"
        elif "R" in code:
            ctype = "renamed"
            path = path.split(" -> ")[-1]
        elif "A" in code:
            ctype = "added"
        elif "D" in code:
            ctype = "deleted"
        else:
            ctype = "modified"
        if path.startswith('"') and path.endswith('"'):
            path = path[1:-1]
        entries.append((ctype, path))
    return entries


# --- commands: init ----------------------------------------------------------


def cmd_init(args):
    root = Path(args.root).resolve() if args.root else Path.cwd().resolve()
    (root / "context").mkdir(parents=True, exist_ok=True)
    cr_dir = root / "context-relay"
    for sub in ("exports", "snapshots", "dashboard"):
        (cr_dir / sub).mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(root / DB_RELPATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(DDL)

    fts = "1"
    try:
        conn.executescript(FTS_DDL)
    except sqlite3.Error:
        fts = "0"
    conn.execute(
        "INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version',?)",
        (SCHEMA_VERSION,))
    conn.execute(
        "INSERT OR REPLACE INTO meta(key,value) VALUES('fts_enabled',?)", (fts,))

    cfg_path = cr_dir / "config.json"
    if cfg_path.exists():
        cfg = load_config(root)
        name = args.name or cfg.get("project_name") or root.name
    else:
        name = args.name or root.name
        cfg = dict(DEFAULT_CONFIG)
        cfg["project_name"] = name
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
            f.write("\n")

    row = conn.execute("SELECT * FROM projects ORDER BY id LIMIT 1").fetchone()
    if row is None:
        now = now_iso()
        cur = conn.execute(
            "INSERT INTO projects(name, root_path, created_at, updated_at) "
            "VALUES(?,?,?,?)", (name, str(root), now, now))
        pid = cur.lastrowid
    else:
        pid = row["id"]
    conn.commit()

    if args.json:
        prow = conn.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
        print(jdump({"project": dict(prow), "root": str(root),
                     "db": str(root / DB_RELPATH), "fts_enabled": fts == "1"},
                    compact=True))
    else:
        print("id={} initialized root={} fts={}".format(
            pid, root, "on" if fts == "1" else "off (LIKE fallback)"))
    return 0


# --- commands: session -------------------------------------------------------


def _compute_duration(started_at, ended_at):
    if not started_at or not ended_at:
        return None
    try:
        delta = datetime.fromisoformat(ended_at) - datetime.fromisoformat(started_at)
        return int(round(delta.total_seconds()))
    except (ValueError, TypeError):
        return None


def _validate_iso(value, flag):
    if value is None:
        return None
    try:
        datetime.fromisoformat(value)
    except ValueError:
        raise CLIError("invalid ISO timestamp for {}: {}".format(flag, value))
    return value


def cmd_session_start(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    if args.task is not None:
        require_row(conn, "tasks", args.task, "task")
    now = now_iso()
    cur = conn.execute(
        "INSERT INTO sessions(project_id, tool_name, agent_name, started_at, "
        "session_goal, user_request, status, linked_task_id, created_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (proj["id"], args.tool, args.agent, now,
         mask(args.goal), mask(args.request), "active", args.task, now))
    sid = cur.lastrowid
    sync_fts(conn, "session", sid)
    conn.commit()
    emit_created(args, conn, "sessions", sid,
                 "session started tool={}".format(args.tool))
    return 0


def cmd_session_end(args):
    root, conn, mask = get_ctx(args)
    row = require_row(conn, "sessions", args.id, "session")
    if args.task is not None:
        require_row(conn, "tasks", args.task, "task")
        conn.execute("UPDATE sessions SET linked_task_id=? WHERE id=?",
                     (args.task, args.id))
    ended = now_iso()
    if args.duration_sec is not None:
        duration = args.duration_sec
    else:
        duration = _compute_duration(row["started_at"], ended)
    tin = args.tokens_in if args.tokens_in is not None else (row["token_input"] or 0)
    tout = args.tokens_out if args.tokens_out is not None else (row["token_output"] or 0)
    status = args.status or "completed"
    summary = mask(args.summary) if args.summary is not None else row["summary"]
    cost = args.cost if args.cost is not None else row["estimated_cost"]
    conn.execute(
        "UPDATE sessions SET ended_at=?, duration_sec=?, status=?, summary=?, "
        "token_input=?, token_output=?, token_total=?, estimated_cost=? WHERE id=?",
        (ended, duration, status, summary, tin, tout, tin + tout, cost, args.id))
    sync_fts(conn, "session", args.id)
    conn.commit()
    emit_created(args, conn, "sessions", args.id,
                 "session ended status={} duration_sec={} token_total={}".format(
                     status, duration, tin + tout))
    return 0


def cmd_session_log(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    if args.task is not None:
        require_row(conn, "tasks", args.task, "task")
    started = _validate_iso(args.started_at, "--started-at")
    ended = _validate_iso(args.ended_at, "--ended-at")
    if args.duration_sec is not None:
        duration = args.duration_sec
    else:
        duration = _compute_duration(started, ended)
    tin = args.tokens_in or 0
    tout = args.tokens_out or 0
    status = args.status or "completed"
    now = now_iso()
    cur = conn.execute(
        "INSERT INTO sessions(project_id, tool_name, agent_name, started_at, ended_at, "
        "duration_sec, session_goal, user_request, summary, status, token_input, "
        "token_output, token_total, estimated_cost, linked_task_id, created_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (proj["id"], args.tool, args.agent, started, ended, duration,
         mask(args.goal), mask(args.request), mask(args.summary), status,
         tin, tout, tin + tout, args.cost or 0, args.task, now))
    sid = cur.lastrowid
    sync_fts(conn, "session", sid)
    conn.commit()
    emit_created(args, conn, "sessions", sid,
                 "session logged tool={} status={}".format(args.tool, status))
    return 0


def cmd_session_list(args):
    root, conn, _ = get_ctx(args)
    sql = "SELECT * FROM sessions"
    params = []
    if args.status:
        sql += " WHERE status=?"
        params.append(args.status)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(args.limit)
    rows = [dict(r) for r in conn.execute(sql, params)]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no sessions)")
        return 0
    for r in rows:
        print("id={} [{}] {} started={} goal={}".format(
            r["id"], r["status"], r["tool_name"],
            r["started_at"] or "-", r["session_goal"] or "-"))
    return 0


# --- commands: prompt --------------------------------------------------------


def cmd_prompt_add(args):
    root, conn, mask = get_ctx(args)
    sess = require_row(conn, "sessions", args.session, "session")
    text = read_text_input(args)
    if not text.strip():
        raise CLIError("prompt text is empty")
    tool = args.tool or sess["tool_name"]
    agent = args.agent or sess["agent_name"]
    cur = conn.execute(
        "INSERT INTO prompts(session_id, tool_name, agent_name, prompt_text, "
        "prompt_type, related_files, result_summary, success_score, "
        "reuse_candidate, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (args.session, tool, agent, mask(text), args.type, mask(args.files),
         mask(args.result), args.score, 1 if args.reuse else 0, now_iso()))
    pid = cur.lastrowid
    sync_fts(conn, "prompt", pid)
    conn.commit()
    emit_created(args, conn, "prompts", pid,
                 "prompt added session={} type={}".format(args.session, args.type or "-"))
    return 0


def cmd_prompt_list(args):
    root, conn, _ = get_ctx(args)
    sql = "SELECT * FROM prompts WHERE 1=1"
    params = []
    if args.session is not None:
        sql += " AND session_id=?"
        params.append(args.session)
    if args.reuse_only:
        sql += " AND reuse_candidate=1"
    if args.type:
        sql += " AND prompt_type=?"
        params.append(args.type)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(args.limit)
    rows = [dict(r) for r in conn.execute(sql, params)]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no prompts)")
        return 0
    for r in rows:
        head = (r["prompt_text"] or "").replace("\n", " ")[:80]
        print("id={} session={} [{}] score={} reuse={} {}".format(
            r["id"], r["session_id"], r["prompt_type"] or "-",
            r["success_score"] if r["success_score"] is not None else "-",
            r["reuse_candidate"], head))
    return 0


# --- commands: task ----------------------------------------------------------


def cmd_task_add(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    now = now_iso()
    cur = conn.execute(
        "INSERT INTO tasks(project_id, title, description, status, priority, "
        "prd_reference, risk_level, current_next_action, created_at, updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)",
        (proj["id"], mask(args.title), mask(args.description),
         args.status or "not_started", args.priority, args.prd_ref,
         args.risk, mask(args.next), now, now))
    tid = cur.lastrowid
    sync_fts(conn, "task", tid)
    conn.commit()
    emit_created(args, conn, "tasks", tid, "task added")
    return 0


def cmd_task_update(args):
    root, conn, mask = get_ctx(args)
    require_row(conn, "tasks", args.id, "task")
    fields = {
        "title": mask(args.title),
        "description": mask(args.description),
        "status": args.status,
        "priority": args.priority,
        "prd_reference": args.prd_ref,
        "risk_level": args.risk,
        "current_next_action": mask(args.next),
    }
    updates = {k: v for k, v in fields.items() if v is not None}
    if not updates:
        raise CLIError("nothing to update: pass at least one field flag")
    updates["updated_at"] = now_iso()
    set_clause = ", ".join("{}=?".format(k) for k in updates)
    conn.execute("UPDATE tasks SET {} WHERE id=?".format(set_clause),
                 (*updates.values(), args.id))
    sync_fts(conn, "task", args.id)
    conn.commit()
    emit_created(args, conn, "tasks", args.id, "task updated")
    return 0


def cmd_task_list(args):
    root, conn, _ = get_ctx(args)
    sql = "SELECT * FROM tasks"
    params = []
    if args.status:
        sql += " WHERE status=?"
        params.append(args.status)
    sql += " ORDER BY id DESC"
    rows = [dict(r) for r in conn.execute(sql, params)]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no tasks)")
        return 0
    for r in rows:
        print("id={} [{}] ({}) risk={} {} next={}".format(
            r["id"], r["status"] or "-", r["priority"] or "-",
            r["risk_level"] or "-", r["title"], r["current_next_action"] or "-"))
    return 0


# --- commands: file ----------------------------------------------------------


def cmd_file_add(args):
    root, conn, mask = get_ctx(args)
    require_row(conn, "sessions", args.session, "session")
    cur = conn.execute(
        "INSERT INTO files_changed(session_id, file_path, change_type, "
        "change_summary, risk_level, created_at) VALUES(?,?,?,?,?,?)",
        (args.session, args.path, args.type, mask(args.summary),
         args.risk, now_iso()))
    fid = cur.lastrowid
    sync_fts(conn, "file", fid)
    conn.commit()
    emit_created(args, conn, "files_changed", fid,
                 "file recorded path={}".format(args.path))
    return 0


def cmd_file_list(args):
    root, conn, _ = get_ctx(args)
    sql = "SELECT * FROM files_changed"
    params = []
    if args.session is not None:
        sql += " WHERE session_id=?"
        params.append(args.session)
    sql += " ORDER BY id DESC"
    rows = [dict(r) for r in conn.execute(sql, params)]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no files)")
        return 0
    for r in rows:
        print("id={} session={} [{}] risk={} {}".format(
            r["id"], r["session_id"], r["change_type"] or "-",
            r["risk_level"] or "-", r["file_path"]))
    return 0


# --- commands: decision / risk ------------------------------------------------


def cmd_decision_add(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    if args.session is not None:
        require_row(conn, "sessions", args.session, "session")
    text = read_text_input(args)
    cur = conn.execute(
        "INSERT INTO decisions(project_id, session_id, decision_text, reason, "
        "impact, revisit_condition, created_at) VALUES(?,?,?,?,?,?,?)",
        (proj["id"], args.session, mask(text), mask(args.reason),
         mask(args.impact), mask(args.revisit), now_iso()))
    did = cur.lastrowid
    sync_fts(conn, "decision", did)
    conn.commit()
    emit_created(args, conn, "decisions", did, "decision recorded")
    return 0


def cmd_decision_list(args):
    root, conn, _ = get_ctx(args)
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM decisions ORDER BY id DESC LIMIT ?", (args.limit,))]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no decisions)")
        return 0
    for r in rows:
        print("id={} {} | reason={}".format(
            r["id"], (r["decision_text"] or "").replace("\n", " ")[:100],
            (r["reason"] or "-").replace("\n", " ")[:60]))
    return 0


def cmd_risk_add(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    if args.session is not None:
        require_row(conn, "sessions", args.session, "session")
    text = read_text_input(args)
    cur = conn.execute(
        "INSERT INTO risks(project_id, session_id, risk_text, risk_level, "
        "related_file, mitigation, created_at) VALUES(?,?,?,?,?,?,?)",
        (proj["id"], args.session, mask(text), args.level,
         args.file, mask(args.mitigation), now_iso()))
    rid = cur.lastrowid
    sync_fts(conn, "risk", rid)
    conn.commit()
    emit_created(args, conn, "risks", rid, "risk recorded level={}".format(args.level or "-"))
    return 0


def cmd_risk_list(args):
    root, conn, _ = get_ctx(args)
    rows = [dict(r) for r in conn.execute("SELECT * FROM risks ORDER BY id DESC")]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no risks)")
        return 0
    for r in rows:
        print("id={} [{}] {} file={}".format(
            r["id"], r["risk_level"] or "-",
            (r["risk_text"] or "").replace("\n", " ")[:100],
            r["related_file"] or "-"))
    return 0


# --- commands: git -----------------------------------------------------------


def cmd_git_capture(args):
    root, conn, mask = get_ctx(args)
    if not is_git_repo(root):
        eprint("warning: not a git repository (or git unavailable) at {}; "
               "nothing captured".format(root))
        return 0
    if args.files and args.session is None:
        raise CLIError("--files requires --session N (files_changed.session_id is NOT NULL)")
    if args.session is not None:
        require_row(conn, "sessions", args.session, "session")
    proj = get_project(conn)

    branch = run_git(root, "branch", "--show-current") or \
        run_git(root, "rev-parse", "--abbrev-ref", "HEAD")
    head = run_git(root, "rev-parse", "HEAD")
    status = run_git(root, "status", "--porcelain")
    diffstat = run_git(root, "diff", "--stat")
    log5 = run_git(root, "log", "-5", "--oneline")

    entries = parse_porcelain(status)
    diff_summary = mask("\n\n".join([
        "## status --porcelain\n" + (status if status else "(clean)"),
        "## diff --stat\n" + (diffstat if diffstat else "(no diff)"),
        "## log -5 --oneline\n" + (log5 if log5 else "(no commits)"),
    ]))
    now = now_iso()
    cur = conn.execute(
        "INSERT INTO git_events(project_id, session_id, commit_hash, branch_name, "
        "diff_summary, changed_files_count, created_at) VALUES(?,?,?,?,?,?,?)",
        (proj["id"], args.session, head, branch, diff_summary, len(entries), now))
    gid = cur.lastrowid

    files_created = 0
    if args.files:
        for ctype, path in entries:
            # Skip Context Relay's own storage: recording it on every capture
            # pollutes file-change stats with tool churn.
            if path.startswith("context-relay/"):
                continue
            fcur = conn.execute(
                "INSERT INTO files_changed(session_id, file_path, change_type, "
                "change_summary, risk_level, created_at) VALUES(?,?,?,?,?,?)",
                (args.session, path, ctype, "git capture", None, now))
            sync_fts(conn, "file", fcur.lastrowid)
            files_created += 1
    conn.commit()

    if args.json:
        row = conn.execute("SELECT * FROM git_events WHERE id=?", (gid,)).fetchone()
        out = dict(row)
        out["files_created"] = files_created
        print(jdump(out, compact=True))
    else:
        print("id={} git captured branch={} changed_files={} files_created={}".format(
            gid, branch or "-", len(entries), files_created))
    return 0


def cmd_git_info(args):
    root, conn, mask = get_ctx(args)
    if not is_git_repo(root):
        eprint("warning: not a git repository (or git unavailable) at {}".format(root))
        return 0
    branch = run_git(root, "branch", "--show-current") or \
        run_git(root, "rev-parse", "--abbrev-ref", "HEAD")
    last = run_git(root, "log", "-1", "--format=%H%x09%s%x09%cI")
    last_commit = None
    if last:
        parts = last.split("\t")
        last_commit = {
            "hash": parts[0],
            "subject": mask(parts[1]) if len(parts) > 1 else "",
            "date": parts[2] if len(parts) > 2 else "",
        }
    status = run_git(root, "status", "--porcelain")
    entries = parse_porcelain(status)
    log5 = run_git(root, "log", "-5", "--oneline") or ""
    info = {
        "branch": branch,
        "last_commit": last_commit,
        "dirty_count": len(entries),
        "recent_commits": [mask(l) for l in log5.splitlines() if l.strip()],
        "changed_files": [{"status": c, "path": p} for c, p in entries],
    }
    print(jdump(info, compact=args.json))
    return 0


# --- commands: agent ---------------------------------------------------------


def cmd_agent_add(args):
    root, conn, mask = get_ctx(args)
    proj = get_project(conn)
    cur = conn.execute(
        "INSERT INTO agents(project_id, name, role, tool_name, created_at) "
        "VALUES(?,?,?,?,?)",
        (proj["id"], args.name, args.role, args.tool, now_iso()))
    aid = cur.lastrowid
    conn.commit()
    emit_created(args, conn, "agents", aid, "agent added name={}".format(args.name))
    return 0


def cmd_agent_log(args):
    root, conn, mask = get_ctx(args)
    sess = require_row(conn, "sessions", args.session, "session")
    proj = get_project(conn)
    ref = args.agent
    if ref.isdigit():
        agent = require_row(conn, "agents", int(ref), "agent")
        aid = agent["id"]
    else:
        row = conn.execute("SELECT * FROM agents WHERE name=?", (ref,)).fetchone()
        if row is None:
            cur = conn.execute(
                "INSERT INTO agents(project_id, name, role, tool_name, created_at) "
                "VALUES(?,?,?,?,?)",
                (proj["id"], ref, None, sess["tool_name"], now_iso()))
            aid = cur.lastrowid
        else:
            aid = row["id"]
    cur = conn.execute(
        "INSERT INTO session_agents(session_id, agent_id, duration_sec, "
        "token_total, result_summary) VALUES(?,?,?,?,?)",
        (args.session, aid, args.duration_sec or 0, args.tokens or 0,
         mask(args.result)))
    said = cur.lastrowid
    conn.commit()
    emit_created(args, conn, "session_agents", said,
                 "agent usage logged agent_id={} session={}".format(aid, args.session))
    return 0


def cmd_agent_list(args):
    root, conn, _ = get_ctx(args)
    rows = [dict(r) for r in conn.execute(
        "SELECT a.*, "
        "(SELECT COUNT(*) FROM session_agents sa WHERE sa.agent_id=a.id) AS usage_count, "
        "(SELECT COALESCE(SUM(sa.token_total),0) FROM session_agents sa "
        " WHERE sa.agent_id=a.id) AS tokens_total "
        "FROM agents a ORDER BY a.id")]
    if args.json:
        print(jdump(rows))
        return 0
    if not rows:
        print("(no agents)")
        return 0
    for r in rows:
        print("id={} {} role={} tool={} uses={} tokens={}".format(
            r["id"], r["name"], r["role"] or "-", r["tool_name"] or "-",
            r["usage_count"], r["tokens_total"]))
    return 0


# --- commands: search / reindex -----------------------------------------------


def _like_snippet(body, query, width=60):
    idx = body.lower().find(query.lower())
    if idx < 0:
        return body[:width * 2]
    start = max(0, idx - width)
    end = min(len(body), idx + len(query) + width)
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(body) else ""
    return prefix + body[start:end] + suffix


def _search_like(conn, query, etype_filter, limit):
    """LIKE fallback over base tables when FTS5 is unavailable."""
    results = []
    for etype, table in TABLE_BY_ETYPE.items():
        if etype_filter and etype != etype_filter:
            continue
        for row in conn.execute("SELECT * FROM {}".format(table)):
            d = dict(row)
            title, body = fts_fields(etype, d)
            haystack = title + " " + body
            if query.lower() in haystack.lower():
                results.append({
                    "entity_type": etype,
                    "entity_id": d["id"],
                    "title": title,
                    "snippet": _like_snippet(body or title, query),
                    "rank": None,
                    "created_at": d.get("created_at", ""),
                })
    results.sort(key=lambda r: r["created_at"], reverse=True)
    return results[:limit]


def cmd_search(args):
    root, conn, _ = get_ctx(args)
    query = args.query
    etype = ENTITY_MAP[args.entity] if args.entity else None
    fallback = not fts_on(conn)

    if fallback:
        results = _search_like(conn, query, etype, args.limit)
    else:
        sql = ("SELECT entity_type, entity_id, title, "
               "snippet(search_index, 3, '[', ']', '...', 20) AS snip, "
               "bm25(search_index) AS rank FROM search_index "
               "WHERE search_index MATCH ?")
        params = [query]
        if etype:
            sql += " AND entity_type = ?"
            params.append(etype)
        sql += " ORDER BY rank LIMIT ?"
        params.append(args.limit)
        try:
            rows = conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            # FTS5 query syntax error: retry with each term quoted literally.
            quoted = " ".join('"{}"'.format(t.replace('"', '""'))
                              for t in query.split())
            params[0] = quoted
            try:
                rows = conn.execute(sql, params).fetchall()
            except sqlite3.OperationalError as exc:
                raise CLIError("search query failed: {}".format(exc))
        results = []
        for r in rows:
            try:
                eid = int(r["entity_id"])
            except (TypeError, ValueError):
                eid = r["entity_id"]
            results.append({
                "entity_type": r["entity_type"], "entity_id": eid,
                "title": r["title"], "snippet": r["snip"], "rank": r["rank"],
            })

    if args.json:
        print(jdump({"query": query, "fallback": fallback, "results": results}))
        return 0
    if fallback:
        print("# fallback=LIKE (FTS5 unavailable)")
    if not results:
        print("(no results)")
        return 0
    for r in results:
        print("{}#{}  {}".format(r["entity_type"], r["entity_id"], r["title"]))
        print("    {}".format((r["snippet"] or "").replace("\n", " ")))
    return 0


def cmd_reindex(args):
    root, conn, _ = get_ctx(args)
    if not fts_on(conn):
        try:
            conn.executescript(FTS_DDL)
            conn.execute(
                "INSERT OR REPLACE INTO meta(key,value) VALUES('fts_enabled','1')")
        except sqlite3.Error:
            eprint("warning: FTS5 unavailable; search stays on LIKE fallback "
                   "(nothing to reindex)")
            return 0
    conn.execute("DELETE FROM search_index")
    count = 0
    for etype, table in TABLE_BY_ETYPE.items():
        for row in conn.execute("SELECT * FROM {}".format(table)):
            d = dict(row)
            title, body = fts_fields(etype, d)
            conn.execute(
                "INSERT INTO search_index(entity_type, entity_id, title, body, "
                "created_at) VALUES(?,?,?,?,?)",
                (etype, str(d["id"]), title, body, d.get("created_at", "")))
            count += 1
    conn.commit()
    print("reindexed rows={}".format(count))
    return 0


# --- commands: stats / recent --------------------------------------------------


def collect_stats(conn):
    def one(sql, *params):
        return conn.execute(sql, params).fetchone()[0]

    tasks_by_status = {
        (r["status"] or "unknown"): r["c"]
        for r in conn.execute("SELECT status, COUNT(*) c FROM tasks GROUP BY status")}
    by_date = [
        {"date": r["d"], "sessions": r["c"], "tokens": r["t"] or 0}
        for r in conn.execute(
            "SELECT substr(COALESCE(started_at, created_at),1,10) d, "
            "COUNT(*) c, SUM(token_total) t FROM sessions GROUP BY d ORDER BY d")]
    file_freq = [
        {"file_path": r["file_path"], "changes": r["c"]}
        for r in conn.execute(
            "SELECT file_path, COUNT(*) c FROM files_changed "
            "GROUP BY file_path ORDER BY c DESC, file_path LIMIT 20")]
    by_tool = {
        r["tool_name"]: r["c"]
        for r in conn.execute(
            "SELECT tool_name, COUNT(*) c FROM sessions GROUP BY tool_name")}
    return {
        "sessions_total": one("SELECT COUNT(*) FROM sessions"),
        "prompts_total": one("SELECT COUNT(*) FROM prompts"),
        "decisions_total": one("SELECT COUNT(*) FROM decisions"),
        "risks_total": one("SELECT COUNT(*) FROM risks"),
        "tasks_by_status": tasks_by_status,
        "duration_sec_total": one(
            "SELECT COALESCE(SUM(duration_sec),0) FROM sessions"),
        "tokens_total": one("SELECT COALESCE(SUM(token_total),0) FROM sessions"),
        "cost_total": one("SELECT COALESCE(SUM(estimated_cost),0) FROM sessions"),
        "last_session_at": one(
            "SELECT MAX(COALESCE(ended_at, started_at, created_at)) FROM sessions"),
        "sessions_by_date": by_date,
        "file_change_frequency": file_freq,
        "sessions_by_tool": by_tool,
    }


def cmd_stats(args):
    root, conn, _ = get_ctx(args)
    stats = collect_stats(conn)
    if args.json:
        print(jdump(stats))
        return 0
    print("sessions={} prompts={} decisions={} risks={}".format(
        stats["sessions_total"], stats["prompts_total"],
        stats["decisions_total"], stats["risks_total"]))
    print("tasks_by_status={}".format(
        jdump(stats["tasks_by_status"], compact=True)))
    print("duration_sec_total={} tokens_total={} cost_total={}".format(
        stats["duration_sec_total"], stats["tokens_total"], stats["cost_total"]))
    print("last_session_at={}".format(stats["last_session_at"] or "-"))
    print("sessions_by_tool={}".format(
        jdump(stats["sessions_by_tool"], compact=True)))
    if stats["file_change_frequency"]:
        print("top_changed_files:")
        for f in stats["file_change_frequency"][:5]:
            print("  {} x{}".format(f["file_path"], f["changes"]))
    return 0


def cmd_recent(args):
    root, conn, _ = get_ctx(args)
    proj = get_project(conn)
    limit = args.limit
    sessions = [dict(r) for r in conn.execute(
        "SELECT * FROM sessions ORDER BY id DESC LIMIT ?", (limit,))]
    for s in sessions:
        s["prompt_count"] = conn.execute(
            "SELECT COUNT(*) FROM prompts WHERE session_id=?",
            (s["id"],)).fetchone()[0]
    prompts = [dict(r) for r in conn.execute(
        "SELECT * FROM prompts ORDER BY id DESC LIMIT 20")]
    files = [dict(r) for r in conn.execute(
        "SELECT * FROM files_changed ORDER BY id DESC LIMIT 20")]
    open_tasks = [dict(r) for r in conn.execute(
        "SELECT * FROM tasks WHERE status IS NULL OR status != 'completed' "
        "ORDER BY updated_at DESC")]
    decisions = [dict(r) for r in conn.execute(
        "SELECT * FROM decisions ORDER BY id DESC LIMIT 10")]
    risks = [dict(r) for r in conn.execute("SELECT * FROM risks ORDER BY id DESC")]
    bundle = {
        "project": dict(proj),
        "sessions": sessions,
        "prompts": prompts,
        "files": files,
        "open_tasks": open_tasks,
        "decisions": decisions,
        "risks": risks,
        "stats": collect_stats(conn),
    }
    print(jdump(bundle, compact=args.json))
    return 0


# --- commands: export / snapshot -----------------------------------------------


def cmd_export(args):
    root, conn, _ = get_ctx(args)
    tables = ["meta", "projects", "sessions", "prompts", "tasks", "files_changed",
              "decisions", "risks", "git_events", "agents", "session_agents"]
    dump = {"exported_at": now_iso(), "root": str(root), "tables": {}}
    for table in tables:
        dump["tables"][table] = [
            dict(r) for r in conn.execute("SELECT * FROM {}".format(table))]
    if args.out:
        out = Path(args.out)
    else:
        out = root / "context-relay" / "exports" / "export-{}.json".format(stamp())
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(dump, f, ensure_ascii=False, indent=2, default=str)
        f.write("\n")
    print("exported {} tables -> {}".format(len(tables), out))
    return 0


def cmd_snapshot(args):
    root, conn, _ = get_ctx(args)
    dest = root / "context-relay" / "snapshots" / stamp()
    dest.mkdir(parents=True, exist_ok=True)
    count = 0
    context_dir = root / "context"
    if context_dir.is_dir():
        for md in sorted(context_dir.glob("*.md")):
            shutil.copy2(str(md), str(dest / md.name))
            count += 1
    print("snapshot {} files -> {}".format(count, dest))
    return 0


# --- argparse wiring -----------------------------------------------------------


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--root", metavar="PATH",
                        help="Project root (default: walk up from cwd)")
    common.add_argument("--json", action="store_true",
                        help="Machine-readable JSON output")

    p = Parser(prog="cr.py", description="Context Relay deterministic engine")
    sub = p.add_subparsers(dest="command", metavar="command")
    sub.required = True

    sp = sub.add_parser("init", parents=[common],
                        help="Create context/ + context-relay/ (DB, config); idempotent")
    sp.add_argument("--name", help="Project name (default: root directory name)")
    sp.set_defaults(func=cmd_init)

    # session
    sess = sub.add_parser("session", help="Session records")
    ssub = sess.add_subparsers(dest="subcommand", metavar="subcommand")
    ssub.required = True

    sp = ssub.add_parser("start", parents=[common], help="Start a live session")
    sp.add_argument("--tool", required=True)
    sp.add_argument("--agent")
    sp.add_argument("--goal")
    sp.add_argument("--request")
    sp.add_argument("--task", type=int, help="Linked task id")
    sp.set_defaults(func=cmd_session_start)

    sp = ssub.add_parser("end", parents=[common], help="End a session")
    sp.add_argument("--id", type=int, required=True)
    sp.add_argument("--summary")
    sp.add_argument("--task", type=int, help="Link session to task id")
    sp.add_argument("--status", choices=SESSION_END_STATUSES)
    sp.add_argument("--tokens-in", type=int, dest="tokens_in")
    sp.add_argument("--tokens-out", type=int, dest="tokens_out")
    sp.add_argument("--cost", type=float)
    sp.add_argument("--duration-sec", type=int, dest="duration_sec",
                    help="Override computed duration")
    sp.set_defaults(func=cmd_session_end)

    sp = ssub.add_parser("log", parents=[common],
                         help="Record a past session retroactively")
    sp.add_argument("--tool", required=True)
    sp.add_argument("--goal")
    sp.add_argument("--summary")
    sp.add_argument("--status", choices=SESSION_STATUSES)
    sp.add_argument("--request")
    sp.add_argument("--agent")
    sp.add_argument("--task", type=int)
    sp.add_argument("--started-at", dest="started_at", metavar="ISO")
    sp.add_argument("--ended-at", dest="ended_at", metavar="ISO")
    sp.add_argument("--duration-sec", type=int, dest="duration_sec")
    sp.add_argument("--tokens-in", type=int, dest="tokens_in")
    sp.add_argument("--tokens-out", type=int, dest="tokens_out")
    sp.add_argument("--cost", type=float)
    sp.set_defaults(func=cmd_session_log)

    sp = ssub.add_parser("list", parents=[common], help="List sessions")
    sp.add_argument("--limit", type=int, default=20)
    sp.add_argument("--status", choices=SESSION_STATUSES)
    sp.set_defaults(func=cmd_session_list)

    # prompt
    pr = sub.add_parser("prompt", help="Prompt records")
    psub = pr.add_subparsers(dest="subcommand", metavar="subcommand")
    psub.required = True

    sp = psub.add_parser("add", parents=[common], help="Record a prompt")
    sp.add_argument("--session", type=int, required=True)
    grp = sp.add_mutually_exclusive_group(required=True)
    grp.add_argument("--text")
    grp.add_argument("--text-file", dest="text_file", metavar="PATH",
                     help="Read text from file ('-' = stdin)")
    sp.add_argument("--type", choices=PROMPT_TYPES)
    sp.add_argument("--result", help="Result summary")
    sp.add_argument("--score", type=int, choices=[1, 2, 3, 4, 5])
    sp.add_argument("--reuse", action="store_true", help="Mark as reuse candidate")
    sp.add_argument("--files", help="Comma-separated related file paths")
    sp.add_argument("--agent")
    sp.add_argument("--tool")
    sp.set_defaults(func=cmd_prompt_add)

    sp = psub.add_parser("list", parents=[common], help="List prompts")
    sp.add_argument("--session", type=int)
    sp.add_argument("--reuse-only", action="store_true", dest="reuse_only")
    sp.add_argument("--type", choices=PROMPT_TYPES)
    sp.add_argument("--limit", type=int, default=20)
    sp.set_defaults(func=cmd_prompt_list)

    # task
    tk = sub.add_parser("task", help="Task records")
    tsub = tk.add_subparsers(dest="subcommand", metavar="subcommand")
    tsub.required = True

    sp = tsub.add_parser("add", parents=[common], help="Add a task")
    sp.add_argument("--title", required=True)
    sp.add_argument("--description")
    sp.add_argument("--status", choices=TASK_STATUSES)
    sp.add_argument("--priority", choices=PRIORITIES)
    sp.add_argument("--prd-ref", dest="prd_ref")
    sp.add_argument("--risk", choices=PRIORITIES)
    sp.add_argument("--next", help="Current next action")
    sp.set_defaults(func=cmd_task_add)

    sp = tsub.add_parser("update", parents=[common], help="Update a task")
    sp.add_argument("--id", type=int, required=True)
    sp.add_argument("--title")
    sp.add_argument("--description")
    sp.add_argument("--status", choices=TASK_STATUSES)
    sp.add_argument("--priority", choices=PRIORITIES)
    sp.add_argument("--prd-ref", dest="prd_ref")
    sp.add_argument("--risk", choices=PRIORITIES)
    sp.add_argument("--next")
    sp.set_defaults(func=cmd_task_update)

    sp = tsub.add_parser("list", parents=[common], help="List tasks")
    sp.add_argument("--status", choices=TASK_STATUSES)
    sp.set_defaults(func=cmd_task_list)

    # file
    fl = sub.add_parser("file", help="Changed-file records")
    fsub = fl.add_subparsers(dest="subcommand", metavar="subcommand")
    fsub.required = True

    sp = fsub.add_parser("add", parents=[common], help="Record a changed file")
    sp.add_argument("--session", type=int, required=True)
    sp.add_argument("--path", required=True)
    sp.add_argument("--type", choices=FILE_CHANGE_TYPES)
    sp.add_argument("--summary")
    sp.add_argument("--risk", choices=PRIORITIES)
    sp.set_defaults(func=cmd_file_add)

    sp = fsub.add_parser("list", parents=[common], help="List changed files")
    sp.add_argument("--session", type=int)
    sp.set_defaults(func=cmd_file_list)

    # decision
    dc = sub.add_parser("decision", help="Decision records")
    dsub = dc.add_subparsers(dest="subcommand", metavar="subcommand")
    dsub.required = True

    sp = dsub.add_parser("add", parents=[common], help="Record a decision")
    grp = sp.add_mutually_exclusive_group(required=True)
    grp.add_argument("--text")
    grp.add_argument("--text-file", dest="text_file", metavar="PATH")
    sp.add_argument("--session", type=int)
    sp.add_argument("--reason")
    sp.add_argument("--impact")
    sp.add_argument("--revisit", help="Revisit condition")
    sp.set_defaults(func=cmd_decision_add)

    sp = dsub.add_parser("list", parents=[common], help="List decisions")
    sp.add_argument("--limit", type=int, default=20)
    sp.set_defaults(func=cmd_decision_list)

    # risk
    rk = sub.add_parser("risk", help="Risk records")
    rsub = rk.add_subparsers(dest="subcommand", metavar="subcommand")
    rsub.required = True

    sp = rsub.add_parser("add", parents=[common], help="Record a risk")
    grp = sp.add_mutually_exclusive_group(required=True)
    grp.add_argument("--text")
    grp.add_argument("--text-file", dest="text_file", metavar="PATH")
    sp.add_argument("--level", choices=PRIORITIES)
    sp.add_argument("--file")
    sp.add_argument("--mitigation")
    sp.add_argument("--session", type=int)
    sp.set_defaults(func=cmd_risk_add)

    sp = rsub.add_parser("list", parents=[common], help="List risks")
    sp.set_defaults(func=cmd_risk_list)

    # git
    gt = sub.add_parser("git", help="Git capture / info")
    gsub = gt.add_subparsers(dest="subcommand", metavar="subcommand")
    gsub.required = True

    sp = gsub.add_parser("capture", parents=[common],
                         help="Save current git state as a git_event")
    sp.add_argument("--session", type=int)
    sp.add_argument("--files", action="store_true",
                    help="Also create files_changed rows from porcelain")
    sp.set_defaults(func=cmd_git_capture)

    sp = gsub.add_parser("info", parents=[common],
                         help="Print current git state (no DB write)")
    sp.set_defaults(func=cmd_git_info)

    # agent
    ag = sub.add_parser("agent", help="Agent records")
    asub = ag.add_subparsers(dest="subcommand", metavar="subcommand")
    asub.required = True

    sp = asub.add_parser("add", parents=[common], help="Register an agent")
    sp.add_argument("--name", required=True)
    sp.add_argument("--role")
    sp.add_argument("--tool")
    sp.set_defaults(func=cmd_agent_add)

    sp = asub.add_parser("log", parents=[common],
                         help="Log agent usage in a session")
    sp.add_argument("--session", type=int, required=True)
    sp.add_argument("--agent", required=True, metavar="NAME_OR_ID")
    sp.add_argument("--duration-sec", type=int, dest="duration_sec")
    sp.add_argument("--tokens", type=int)
    sp.add_argument("--result")
    sp.set_defaults(func=cmd_agent_log)

    sp = asub.add_parser("list", parents=[common], help="List agents")
    sp.set_defaults(func=cmd_agent_list)

    # search / reindex
    sp = sub.add_parser("search", parents=[common],
                        help="FTS5 BM25 search (LIKE fallback when FTS5 missing)")
    sp.add_argument("query")
    sp.add_argument("--limit", type=int, default=20)
    sp.add_argument("--entity", choices=sorted(ENTITY_MAP.keys()))
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("reindex", parents=[common],
                        help="Rebuild the whole search_index")
    sp.set_defaults(func=cmd_reindex)

    # stats / recent
    sp = sub.add_parser("stats", parents=[common], help="Summary statistics")
    sp.set_defaults(func=cmd_stats)

    sp = sub.add_parser("recent", parents=[common],
                        help="Bundle JSON for handoff generation")
    sp.add_argument("--limit", type=int, default=10)
    sp.set_defaults(func=cmd_recent)

    # export / snapshot
    sp = sub.add_parser("export", parents=[common], help="Dump entire DB to JSON")
    sp.add_argument("--out", metavar="PATH")
    sp.set_defaults(func=cmd_export)

    sp = sub.add_parser("snapshot", parents=[common],
                        help="Copy context/*.md into a timestamped snapshot dir")
    sp.set_defaults(func=cmd_snapshot)

    return p


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args) or 0
    except CLIError as exc:
        eprint("error: {}".format(exc))
        return exc.code
    except sqlite3.Error as exc:
        eprint("sqlite error: {}".format(exc))
        return 1
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    sys.exit(main())
