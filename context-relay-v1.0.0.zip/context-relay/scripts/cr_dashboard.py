#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cr_dashboard.py — Context Relay 정적 HTML 대시보드 생성기.

architecture.md §6 계약 구현.

- 호출: python3 cr_dashboard.py [--root PATH] [--out PATH]
  (기본 out: <root>/context-relay/dashboard/index.html)
- 루트 탐색: --root 우선, 없으면 cwd에서 상위로 올라가며
  context-relay/context-relay.sqlite 탐색. DB 없으면 stderr 안내 + exit 2.
- DB(§4 스키마)를 직접 SELECT + git 서브프로세스로 현재 상태 수집
  → 자체완결 정적 HTML 1파일 생성.
- 외부 네트워크 요청 0건 (CDN/폰트/이미지 금지). CSS/JS 전부 인라인.
  시스템 폰트 스택. 라이트/다크 모두 지원 (prefers-color-scheme).
- 데이터는 <script id="cr-data" type="application/json"> 임베드,
  vanilla JS 렌더. JSON 임베드 시 '<' 를 \\u003c 로 치환해
  "</script>" 조기 종료와 마크업 주입을 원천 차단한다.
- 모든 사용자 텍스트는 클라이언트 렌더 시 HTML 이스케이프 (XSS 방어).
- 빈 DB에서도 크래시 없이 "아직 기록이 없습니다" 상태를 렌더한다.

표준 라이브러리만 사용 (Python 3.9+).
"""

import argparse
import json
import sqlite3
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

DB_RELPATH = Path("context-relay") / "context-relay.sqlite"


# ---------------------------------------------------------------------------
# 루트 / DB 탐색
# ---------------------------------------------------------------------------

def find_root(start):
    """cwd에서 상위로 올라가며 context-relay/context-relay.sqlite 를 찾는다."""
    cur = Path(start).resolve()
    for p in [cur, *cur.parents]:
        if (p / DB_RELPATH).is_file():
            return p
    return None


def connect_ro(db_path):
    """가능하면 read-only 로 열고, 실패하면 일반 연결로 폴백한다."""
    try:
        conn = sqlite3.connect("file:{}?mode=ro".format(db_path), uri=True)
        conn.execute("SELECT 1")
    except sqlite3.Error:
        conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# 쿼리 헬퍼
# ---------------------------------------------------------------------------

def q(conn, sql, params=()):
    """SELECT 실행. 테이블 부재 등 오류 시 빈 리스트 (빈/부분 DB 방어)."""
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    except sqlite3.Error:
        return []


def q1(conn, sql, params=()):
    rows = q(conn, sql, params)
    return rows[0] if rows else None


def trunc(s, n):
    if s is None:
        return ""
    s = str(s)
    if len(s) <= n:
        return s
    return s[:n] + "…"


def join_parts(*parts):
    out = []
    for p in parts:
        if p is None:
            continue
        t = str(p).strip()
        if t:
            out.append(t)
    return " · ".join(out)


# ---------------------------------------------------------------------------
# git 상태 수집 (subprocess — 비 git 저장소면 available=False)
# ---------------------------------------------------------------------------

def collect_git(root):
    def run(*args):
        try:
            p = subprocess.run(
                ["git", *args],
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=10,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        if p.returncode != 0:
            return None
        return p.stdout

    inside = run("rev-parse", "--is-inside-work-tree")
    if inside is None or inside.strip() != "true":
        return {"available": False}

    sep = "\x1f"
    info = {"available": True}

    branch = run("rev-parse", "--abbrev-ref", "HEAD")
    info["branch"] = branch.strip() if branch else "(unknown)"

    last = run("log", "-1", "--date=format:%Y-%m-%d %H:%M",
               "--format=%h" + sep + "%s" + sep + "%an" + sep + "%ad")
    if last and last.strip():
        parts = (last.strip().split(sep) + ["", "", "", ""])[:4]
        info["last_commit"] = {
            "hash": parts[0], "subject": parts[1],
            "author": parts[2], "date": parts[3],
        }
    else:
        info["last_commit"] = None

    porcelain = run("status", "--porcelain")
    if porcelain is None:
        info["uncommitted"] = 0
    else:
        info["uncommitted"] = len([ln for ln in porcelain.splitlines() if ln.strip()])

    log5 = run("log", "-5", "--date=short",
               "--format=%h" + sep + "%s" + sep + "%an" + sep + "%ad")
    commits = []
    for ln in (log5 or "").splitlines():
        if not ln.strip():
            continue
        parts = (ln.split(sep) + ["", "", "", ""])[:4]
        commits.append({"hash": parts[0], "subject": parts[1],
                        "author": parts[2], "date": parts[3]})
    info["recent_commits"] = commits
    return info


# ---------------------------------------------------------------------------
# 데이터 수집
# ---------------------------------------------------------------------------

RISK_RANK = {"high": 3, "medium": 2, "low": 1}


def norm_risk(level):
    lv = (level or "").strip().lower()
    return lv if lv in RISK_RANK else "other"


def collect(conn, root):
    now = datetime.now().astimezone()

    project = q1(conn, "SELECT id, name, root_path, created_at, updated_at "
                       "FROM projects ORDER BY id LIMIT 1")

    # -- 요약 --------------------------------------------------------------
    srow = q1(conn, """
        SELECT COUNT(*) AS n,
               COALESCE(SUM(duration_sec), 0) AS dur,
               COALESCE(SUM(token_total), 0) AS tok,
               COALESCE(SUM(estimated_cost), 0) AS cost,
               MAX(CASE WHEN COALESCE(started_at, created_at)
                             GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]T*'
                        THEN COALESCE(started_at, created_at)
                        ELSE created_at END) AS last
        FROM sessions""") or {}
    prow = q1(conn, "SELECT COUNT(*) AS n FROM prompts") or {}
    status_counts = {}
    for r in q(conn, "SELECT COALESCE(status, '') AS st, COUNT(*) AS n "
                     "FROM tasks GROUP BY COALESCE(status, '')"):
        status_counts[r["st"]] = r["n"]
    risky = q1(conn, "SELECT COUNT(*) AS n FROM tasks "
                     "WHERE LOWER(COALESCE(risk_level, '')) = 'high' "
                     "AND COALESCE(status, '') != 'completed'") or {}

    summary = {
        "last_session_at": srow.get("last"),
        "sessions_total": srow.get("n", 0) or 0,
        "duration_sec_total": srow.get("dur", 0) or 0,
        "tokens_total": srow.get("tok", 0) or 0,
        "cost_total": srow.get("cost", 0) or 0,
        "prompts_total": prow.get("n", 0) or 0,
        "tasks_total": sum(status_counts.values()),
        "tasks_in_progress": status_counts.get("in_progress", 0),
        "tasks_completed": status_counts.get("completed", 0),
        "tasks_risky": risky.get("n", 0) or 0,
    }

    # -- Task 칸반 (sessions.linked_task_id 조인 집계) ----------------------
    sess_agg = {}
    for r in q(conn, """
        SELECT linked_task_id AS tid, COUNT(*) AS n,
               COALESCE(SUM(duration_sec), 0) AS dur,
               COALESCE(SUM(token_total), 0) AS tok
        FROM sessions WHERE linked_task_id IS NOT NULL
        GROUP BY linked_task_id"""):
        sess_agg[r["tid"]] = r

    tools_by_task = {}
    agents_by_task = {}
    for r in q(conn, "SELECT linked_task_id AS tid, tool_name, agent_name "
                     "FROM sessions WHERE linked_task_id IS NOT NULL"):
        if r["tool_name"]:
            tools_by_task.setdefault(r["tid"], set()).add(r["tool_name"])
        if r["agent_name"]:
            agents_by_task.setdefault(r["tid"], set()).add(r["agent_name"])
    for r in q(conn, """
        SELECT s.linked_task_id AS tid, a.name AS name
        FROM session_agents sa
        JOIN sessions s ON sa.session_id = s.id
        JOIN agents a ON sa.agent_id = a.id
        WHERE s.linked_task_id IS NOT NULL"""):
        if r["name"]:
            agents_by_task.setdefault(r["tid"], set()).add(r["name"])

    files_by_task = {}
    for r in q(conn, """
        SELECT s.linked_task_id AS tid, COUNT(*) AS n
        FROM files_changed f JOIN sessions s ON f.session_id = s.id
        WHERE s.linked_task_id IS NOT NULL
        GROUP BY s.linked_task_id"""):
        files_by_task[r["tid"]] = r["n"]

    tasks_out = []
    for t in q(conn, """
        SELECT id, title, description, status, priority, prd_reference,
               risk_level, current_next_action, created_at, updated_at
        FROM tasks ORDER BY id"""):
        a = sess_agg.get(t["id"], {})
        tasks_out.append({
            "id": t["id"],
            "title": t.get("title") or "(제목 없음)",
            "status": t.get("status") or "not_started",
            "priority": t.get("priority") or "",
            "risk_level": t.get("risk_level") or "",
            "prd_ref": t.get("prd_reference") or "",
            "next_action": trunc(t.get("current_next_action"), 160),
            "sessions_count": a.get("n", 0),
            "duration_sec": a.get("dur", 0),
            "tokens": a.get("tok", 0),
            "tools": sorted(tools_by_task.get(t["id"], set())),
            "agents": sorted(agents_by_task.get(t["id"], set())),
            "files_count": files_by_task.get(t["id"], 0),
        })

    # -- 세션 타임라인 (최근 30) --------------------------------------------
    sessions_out = []
    for r in q(conn, """
        SELECT id, tool_name, agent_name, session_goal, status,
               started_at, ended_at, created_at, duration_sec,
               COALESCE(token_total, 0) AS token_total, linked_task_id
        FROM sessions
        ORDER BY COALESCE(started_at, created_at) DESC, id DESC
        LIMIT 30"""):
        sessions_out.append({
            "id": r["id"],
            "tool": r["tool_name"] or "-",
            "agent": r["agent_name"] or "",
            "goal": trunc(r["session_goal"], 120),
            "status": r["status"] or "",
            "started_at": r["started_at"],
            "created_at": r["created_at"],
            "duration_sec": r["duration_sec"] or 0,
            "tokens": r["token_total"] or 0,
            "task_id": r["linked_task_id"],
        })

    # -- 프롬프트 타임라인 (최근 50, 앞 160자) -------------------------------
    prompts_out = []
    for r in q(conn, """
        SELECT p.id, p.session_id,
               COALESCE(p.tool_name, s.tool_name) AS tool_name,
               COALESCE(p.agent_name, s.agent_name) AS agent_name,
               p.prompt_type, p.prompt_text, p.related_files,
               p.result_summary, p.success_score, p.reuse_candidate,
               p.created_at
        FROM prompts p LEFT JOIN sessions s ON p.session_id = s.id
        ORDER BY p.created_at DESC, p.id DESC
        LIMIT 50"""):
        prompts_out.append({
            "id": r["id"],
            "session_id": r["session_id"],
            "tool": r["tool_name"] or "-",
            "agent": r["agent_name"] or "",
            "type": r["prompt_type"] or "",
            "text": trunc(r["prompt_text"], 160),
            "result": trunc(r["result_summary"], 200),
            "files": trunc(r["related_files"], 160),
            "score": r["success_score"],
            "reuse": bool(r["reuse_candidate"]),
            "created_at": r["created_at"],
        })

    # -- 히트맵 ① 날짜별 캘린더 (최근 17주 = 119일, 여유 126일 컷오프) --------
    cutoff = (now.date() - timedelta(days=126)).isoformat()
    calendar = {}
    for r in q(conn, """
        SELECT substr(COALESCE(started_at, created_at), 1, 10) AS d,
               COUNT(*) AS n, COALESCE(SUM(token_total), 0) AS tok
        FROM sessions
        WHERE substr(COALESCE(started_at, created_at), 1, 10) >= ?
        GROUP BY d""", (cutoff,)):
        if r["d"]:
            calendar[r["d"]] = {"s": r["n"], "t": r["tok"] or 0}

    # -- 히트맵 ② 파일 변경 빈도 top 20 --------------------------------------
    file_heat = [{"path": r["file_path"], "count": r["n"]}
                 for r in q(conn, """
                     SELECT file_path, COUNT(*) AS n FROM files_changed
                     GROUP BY file_path ORDER BY n DESC, file_path LIMIT 20""")]

    # -- 히트맵 ③ task별 토큰 -------------------------------------------------
    task_tokens = sorted(
        [{"title": trunc(t["title"], 48), "tokens": t["tokens"]}
         for t in tasks_out if t["sessions_count"] > 0],
        key=lambda x: -x["tokens"])

    # -- 히트맵 ④ 에이전트 활동 (session_agents + sessions.agent_name 병합) ---
    activity = {}
    for r in q(conn, """
        SELECT sa.session_id AS sid, a.name AS name,
               COALESCE(sa.token_total, 0) AS tok
        FROM session_agents sa JOIN agents a ON sa.agent_id = a.id"""):
        if not r["name"]:
            continue
        ent = activity.setdefault(r["name"], {"sids": set(), "tok": 0})
        ent["sids"].add(r["sid"])
        ent["tok"] += r["tok"] or 0
    for r in q(conn, """
        SELECT id AS sid, agent_name AS name, COALESCE(token_total, 0) AS tok
        FROM sessions
        WHERE agent_name IS NOT NULL AND agent_name != ''"""):
        ent = activity.setdefault(r["name"], {"sids": set(), "tok": 0})
        if r["sid"] not in ent["sids"]:
            ent["sids"].add(r["sid"])
            ent["tok"] += r["tok"] or 0
    agent_activity = sorted(
        [{"name": k, "sessions": len(v["sids"]), "tokens": v["tok"]}
         for k, v in activity.items()],
        key=lambda x: (-x["sessions"], -x["tokens"], x["name"]))

    # -- 위험 파일 지도 (risks.related_file + files_changed.risk_level 결합) --
    entries = {}

    def ent_for(fp, level):
        key = (fp or "").strip() or "(파일 미지정)"
        lv = norm_risk(level)
        e = entries.get(key)
        if e is None:
            e = {"file": key, "level": lv, "notes": []}
            entries[key] = e
        elif RISK_RANK.get(lv, 0) > RISK_RANK.get(e["level"], 0):
            e["level"] = lv
        return e

    for r in q(conn, "SELECT risk_text, risk_level, related_file, mitigation "
                     "FROM risks ORDER BY id"):
        e = ent_for(r["related_file"], r["risk_level"])
        note = "위험 기록: " + trunc(r["risk_text"], 140)
        if r["mitigation"]:
            note += " (대응: " + trunc(r["mitigation"], 80) + ")"
        e["notes"].append(note)

    change_counts = {r["file_path"]: r["n"]
                     for r in q(conn, "SELECT file_path, COUNT(*) AS n "
                                      "FROM files_changed GROUP BY file_path")}
    fc_risk = {}
    for r in q(conn, """
        SELECT file_path, COALESCE(risk_level, '') AS lv, COUNT(*) AS n
        FROM files_changed
        WHERE COALESCE(risk_level, '') != ''
        GROUP BY file_path, COALESCE(risk_level, '')"""):
        cur = fc_risk.setdefault(r["file_path"], {"lv": "other", "n": 0})
        lv = norm_risk(r["lv"])
        if RISK_RANK.get(lv, 0) > RISK_RANK.get(cur["lv"], 0):
            cur["lv"] = lv
        cur["n"] += r["n"]
    for fp, info in fc_risk.items():
        e = ent_for(fp, info["lv"])
        e["notes"].append("위험 표시된 변경 {}회 · 총 변경 {}회".format(
            info["n"], change_counts.get(fp, info["n"])))

    risk_map = {"high": [], "medium": [], "low": [], "other": []}
    for e in sorted(entries.values(), key=lambda x: x["file"]):
        risk_map[e["level"]].append(e)

    # -- GitHub 상태 ----------------------------------------------------------
    git = collect_git(root)
    git_events = []
    for r in q(conn, """
        SELECT commit_hash, branch_name, diff_summary,
               changed_files_count, created_at
        FROM git_events ORDER BY id DESC LIMIT 5"""):
        git_events.append({
            "commit_hash": r["commit_hash"] or "",
            "branch_name": r["branch_name"] or "",
            "diff_summary": trunc(r["diff_summary"], 200),
            "changed_files_count": r["changed_files_count"] or 0,
            "created_at": r["created_at"],
        })

    # -- 검색 패널용 임베드 레코드 --------------------------------------------
    recs = []
    for r in q(conn, """
        SELECT id, tool_name, session_goal, summary, user_request,
               started_at, created_at
        FROM sessions ORDER BY id DESC LIMIT 200"""):
        recs.append({
            "type": "session", "id": r["id"],
            "title": trunc(r["session_goal"] or r["tool_name"] or "세션", 120),
            "body": trunc(join_parts(r["summary"], r["user_request"],
                                     r["tool_name"]), 300),
            "date": (r["started_at"] or r["created_at"] or "")[:10],
        })
    for r in q(conn, """
        SELECT id, prompt_type, prompt_text, result_summary, created_at
        FROM prompts ORDER BY id DESC LIMIT 200"""):
        recs.append({
            "type": "prompt", "id": r["id"],
            "title": trunc(r["prompt_type"] or "프롬프트", 60),
            "body": trunc(join_parts(r["prompt_text"], r["result_summary"]), 300),
            "date": (r["created_at"] or "")[:10],
        })
    for r in q(conn, """
        SELECT id, title, description, current_next_action, status, created_at
        FROM tasks ORDER BY id"""):
        recs.append({
            "type": "task", "id": r["id"],
            "title": trunc(r["title"], 120),
            "body": trunc(join_parts(r["description"],
                                     r["current_next_action"], r["status"]), 300),
            "date": (r["created_at"] or "")[:10],
        })
    for r in q(conn, """
        SELECT id, decision_text, reason, impact, created_at
        FROM decisions ORDER BY id DESC LIMIT 100"""):
        recs.append({
            "type": "decision", "id": r["id"],
            "title": trunc(r["decision_text"], 80),
            "body": trunc(join_parts(r["decision_text"], r["reason"],
                                     r["impact"]), 300),
            "date": (r["created_at"] or "")[:10],
        })
    for r in q(conn, """
        SELECT id, risk_text, risk_level, related_file, mitigation, created_at
        FROM risks ORDER BY id DESC LIMIT 100"""):
        recs.append({
            "type": "risk", "id": r["id"],
            "title": trunc(r["risk_text"], 80),
            "body": trunc(join_parts(r["risk_text"], r["mitigation"],
                                     r["related_file"], r["risk_level"]), 300),
            "date": (r["created_at"] or "")[:10],
        })
    for r in q(conn, """
        SELECT id, file_path, change_type, change_summary, created_at
        FROM files_changed ORDER BY id DESC LIMIT 300"""):
        recs.append({
            "type": "file", "id": r["id"],
            "title": trunc(r["file_path"], 160),
            "body": trunc(join_parts(r["change_summary"], r["change_type"]), 300),
            "date": (r["created_at"] or "")[:10],
        })

    return {
        "generated_at": now.isoformat(timespec="seconds"),
        "project": {
            "name": project["name"],
            "root_path": project["root_path"],
            "created_at": project["created_at"],
        } if project else None,
        "summary": summary,
        "tasks": tasks_out,
        "sessions": sessions_out,
        "prompts": prompts_out,
        "calendar": calendar,
        "file_heat": file_heat,
        "task_tokens": task_tokens,
        "agent_activity": agent_activity,
        "risk_map": risk_map,
        "git": git,
        "git_events": git_events,
        "search_records": recs,
    }


# ---------------------------------------------------------------------------
# HTML 템플릿 (자체완결 — 외부 요청 0건, CSS/JS 인라인, 시스템 폰트 스택)
# ---------------------------------------------------------------------------

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Context Relay 대시보드</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#f6f5f1;--panel:#fdfcf8;--ink:#25272e;--muted:#6b6e78;--line:#e3e1d8;
  --accent:#2f6b5f;--accent-soft:#dcebe5;
  --lv0:#ecebe3;--lv1:#c9dfd5;--lv2:#93c4b2;--lv3:#5aa38c;--lv4:#2f6b5f;
  --risk-high:#b3423a;--risk-med:#a8762b;--risk-low:#4a7d55;--risk-other:#6b6e78;
}
@media (prefers-color-scheme: dark){
  :root{
    --bg:#15171c;--panel:#1d2026;--ink:#e6e7ea;--muted:#9a9daa;--line:#2c3038;
    --accent:#7bc4ab;--accent-soft:#24352f;
    --lv0:#22252c;--lv1:#28453b;--lv2:#33604f;--lv3:#478269;--lv4:#6fbf9f;
    --risk-high:#e07a70;--risk-med:#d8a04e;--risk-low:#7fb98a;--risk-other:#9a9daa;
  }
}
body{background:var(--bg);color:var(--ink);
  font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",
  "Apple SD Gothic Neo","Noto Sans KR","Malgun Gothic",sans-serif;}
.wrap{max-width:1180px;margin:0 auto;padding:0 20px}
header{border-bottom:1px solid var(--line);padding:22px 0;background:var(--panel)}
h1{font-size:20px;font-weight:800}
header .meta{color:var(--muted);margin-top:4px;font-size:13px}
main section{background:var(--panel);border:1px solid var(--line);
  border-radius:10px;padding:18px 20px;margin:18px 0}
h2{font-size:16px;font-weight:700;margin-bottom:12px;
  border-bottom:1px solid var(--line);padding-bottom:8px}
h3{font-size:13.5px;font-weight:700;margin:14px 0 8px}
h4{font-size:13px;font-weight:700;margin:12px 0 6px}
.hint{color:var(--muted);font-weight:400;font-size:12px}
.empty{color:var(--muted);padding:14px;text-align:center;
  border:1px dashed var(--line);border-radius:8px;font-size:13px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.card{border:1px solid var(--line);border-radius:8px;padding:10px 12px;background:var(--bg)}
.card .k{font-size:11.5px;color:var(--muted)}
.card .v{font-size:16px;font-weight:700;margin-top:2px;word-break:break-all}
.kanban{display:grid;grid-template-columns:repeat(6,minmax(190px,1fr));
  gap:10px;overflow-x:auto}
.kcol{background:var(--bg);border:1px solid var(--line);border-radius:8px;
  padding:8px;min-width:0}
.kcol-head{font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;
  display:flex;justify-content:space-between;gap:6px}
.kempty{color:var(--muted);font-size:12px;text-align:center;padding:8px 0}
.kcard{border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  margin-bottom:8px;background:var(--panel)}
.kcard-title{font-weight:700;font-size:13px;margin-bottom:4px;word-break:break-word}
.kcard-badges{margin-bottom:4px}
.kcard-row{font-size:12px;color:var(--muted);margin-top:2px;word-break:break-word}
.kcard-next{font-size:12px;margin-top:6px;padding-top:6px;
  border-top:1px dashed var(--line);word-break:break-word}
.badge{display:inline-block;font-size:11px;border-radius:99px;padding:1px 8px;
  border:1px solid var(--line);margin-right:4px;vertical-align:middle;
  background:var(--bg);white-space:nowrap}
.badge.tool{background:var(--accent-soft);border-color:transparent}
.badge.risk-high{color:var(--risk-high);border-color:var(--risk-high)}
.badge.risk-medium{color:var(--risk-med);border-color:var(--risk-med)}
.badge.risk-low{color:var(--risk-low);border-color:var(--risk-low)}
.badge.risk-other{color:var(--risk-other)}
.badge.reuse{color:var(--accent);border-color:var(--accent)}
.trow{display:flex;gap:8px;align-items:baseline;padding:6px 0;
  border-bottom:1px solid var(--line);font-size:13px;flex-wrap:wrap}
.trow:last-child{border-bottom:none}
.twhen{color:var(--muted);font-variant-numeric:tabular-nums;
  white-space:nowrap;font-size:12px}
.tgoal{flex:1;min-width:160px;word-break:break-word}
.ttok{color:var(--muted);font-size:12px;white-space:nowrap}
.item{border:1px solid var(--line);border-radius:8px;padding:10px 12px;
  margin-bottom:10px;background:var(--bg)}
.item-head{display:flex;gap:6px;align-items:baseline;flex-wrap:wrap;margin-bottom:6px}
.ptext{font-size:13px;white-space:pre-wrap;word-break:break-word}
.presult,.pfiles{font-size:12px;color:var(--muted);margin-top:4px;word-break:break-word}
.sub{margin-bottom:16px}
.cal-toolbar{display:flex;align-items:center;gap:6px;margin-bottom:8px;flex-wrap:wrap}
.toggle{font:inherit;font-size:12px;padding:3px 12px;border:1px solid var(--line);
  background:var(--bg);color:var(--ink);border-radius:99px;cursor:pointer}
.toggle.active{background:var(--accent-soft);border-color:var(--accent);font-weight:700}
.legend{margin-left:8px;color:var(--muted);font-size:11.5px;
  display:inline-flex;align-items:center;gap:3px}
.legend .cal-cell{width:11px;height:11px}
.cal-scroll{overflow-x:auto;padding-bottom:4px}
#cal-grid{display:grid;grid-auto-flow:column;grid-template-rows:repeat(7,14px);
  grid-auto-columns:14px;gap:3px;width:max-content}
.cal-cell{width:14px;height:14px;border-radius:3px;background:var(--lv0);display:inline-block}
.cal-cell.lv1{background:var(--lv1)}
.cal-cell.lv2{background:var(--lv2)}
.cal-cell.lv3{background:var(--lv3)}
.cal-cell.lv4{background:var(--lv4)}
.bar-row{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:12px}
.bar-label{width:32%;min-width:120px;overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap;text-align:right;color:var(--muted)}
.bar-track{flex:1;background:var(--lv0);border-radius:4px;height:14px;overflow:hidden}
.bar-fill{height:100%;background:var(--accent);border-radius:4px}
.bar-val{min-width:110px;color:var(--muted);white-space:nowrap}
.risk-group{margin-bottom:12px}
.risk-head.risk-high{color:var(--risk-high)}
.risk-head.risk-medium{color:var(--risk-med)}
.risk-head.risk-low{color:var(--risk-low)}
.risk-head.risk-other{color:var(--risk-other)}
.risk-item{border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  margin:6px 0;background:var(--bg);font-size:12.5px}
.risk-item ul{margin:4px 0 0 18px;color:var(--muted)}
code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  font-size:12px;background:var(--panel);border:1px solid var(--line);
  border-radius:4px;padding:0 4px;word-break:break-all}
.git-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:8px;margin-bottom:6px}
.git-row{border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  background:var(--bg);font-size:13px}
.gk{color:var(--muted);font-size:11.5px;display:block}
.gv{font-weight:600;word-break:break-word}
.commits{list-style:none}
.commits li{padding:4px 0;border-bottom:1px solid var(--line);font-size:13px}
.commits li:last-child{border-bottom:none}
#search-input{width:100%;font:inherit;padding:9px 12px;border:1px solid var(--line);
  border-radius:8px;background:var(--bg);color:var(--ink);margin-bottom:6px}
.sr-item{border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  margin:6px 0;background:var(--bg);font-size:13px}
.sr-body{color:var(--muted);font-size:12px;margin-top:2px;word-break:break-word}
footer{padding:10px 0 28px}
</style>
</head>
<body>
<header>
  <div class="wrap">
    <h1>Context Relay 대시보드</h1>
    <p class="meta" id="header-meta"></p>
  </div>
</header>
<main class="wrap">
  <section id="sec-summary">
    <h2>프로젝트 요약</h2>
    <div id="summary-cards" class="cards"></div>
  </section>
  <section id="sec-kanban">
    <h2>Task 보드 (칸반)</h2>
    <div id="kanban" class="kanban"></div>
  </section>
  <section id="sec-sessions">
    <h2>세션 타임라인 <span class="hint">최근 30개</span></h2>
    <div id="session-list"></div>
  </section>
  <section id="sec-prompts">
    <h2>프롬프트 타임라인 <span class="hint">최근 50개 · 본문 앞 160자</span></h2>
    <div id="prompt-list"></div>
  </section>
  <section id="sec-heatmaps">
    <h2>히트맵</h2>
    <div class="sub">
      <h3>날짜별 활동 캘린더 <span class="hint">최근 17주</span></h3>
      <div class="cal-toolbar">
        <button type="button" id="cal-btn-s" class="toggle active">세션 수</button>
        <button type="button" id="cal-btn-t" class="toggle">토큰</button>
        <span class="legend">적음
          <i class="cal-cell lv0"></i><i class="cal-cell lv1"></i><i class="cal-cell lv2"></i><i class="cal-cell lv3"></i><i class="cal-cell lv4"></i>
        많음</span>
      </div>
      <div class="cal-scroll"><div id="cal-grid"></div></div>
    </div>
    <div class="sub"><h3>파일 변경 빈도 <span class="hint">top 20</span></h3><div id="file-bars"></div></div>
    <div class="sub"><h3>Task별 토큰 사용량</h3><div id="task-bars"></div></div>
    <div class="sub"><h3>에이전트 활동 <span class="hint">세션 수 · 토큰</span></h3><div id="agent-bars"></div></div>
  </section>
  <section id="sec-risk">
    <h2>위험 파일 지도</h2>
    <div id="risk-map"></div>
  </section>
  <section id="sec-git">
    <h2>GitHub 상태</h2>
    <div id="git-body"></div>
    <h4>최근 git 이벤트 <span class="hint">DB 기록 최근 5건</span></h4>
    <div id="git-events"></div>
  </section>
  <section id="sec-search">
    <h2>검색</h2>
    <input id="search-input" type="search"
      placeholder="임베드된 기록(세션·프롬프트·Task·결정·위험·파일)에서 부분 문자열 검색">
    <p class="hint">이 검색은 대시보드에 임베드된 스냅샷만 대상으로 합니다. 심층 검색(FTS5 BM25)은 CLI에서 /context-relay search "질의" 를 사용하세요.</p>
    <div id="search-results"></div>
  </section>
</main>
<footer class="wrap"><p class="hint" id="footer-meta"></p></footer>
<noscript><div class="wrap"><div class="empty">이 대시보드는 JavaScript로 렌더링됩니다. 브라우저에서 JavaScript를 활성화하세요.</div></div></noscript>
<script id="cr-data" type="application/json">__CR_DATA__</script>
<script>
(function(){
'use strict';
var data = {};
try { data = JSON.parse(document.getElementById('cr-data').textContent || '{}'); }
catch (e) { data = {}; }

function esc(s){
  return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function(c){
    switch(c){
      case '&': return '&amp;';
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '"': return '&quot;';
      default: return '&#39;';
    }
  });
}
function fmt(n){ n = Number(n) || 0; return n.toLocaleString('ko-KR'); }
function fmtDur(sec){
  sec = Number(sec) || 0;
  if(sec <= 0) return '0m';
  var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  if(h > 0) return h + 'h ' + m + 'm';
  if(m > 0) return m + 'm';
  return sec + 's';
}
function fmtWhen(iso){ if(!iso) return '-'; return String(iso).slice(0,16).replace('T',' '); }
function el(id){ return document.getElementById(id); }
function emptyNote(id, msg){
  el(id).innerHTML = '<div class="empty">' + esc(msg || '아직 기록이 없습니다.') + '</div>';
}
function badge(cls, text){
  return '<span class="badge ' + cls + '">' + esc(text) + '</span>';
}
function riskKey(v){
  v = String(v || '').toLowerCase();
  return (v === 'high' || v === 'medium' || v === 'low') ? v : 'other';
}

var TASK_COLS = [
  ['not_started', 'Not Started'],
  ['in_progress', 'In Progress'],
  ['blocked', 'Blocked'],
  ['needs_review', 'Needs Review'],
  ['ready_to_test', 'Ready to Test'],
  ['completed', 'Completed']
];
var TASK_STATUS = {not_started:'시작 전', in_progress:'진행 중', blocked:'차단됨',
  needs_review:'리뷰 필요', ready_to_test:'테스트 대기', completed:'완료'};
var SESSION_STATUS = {planned:'계획', active:'진행중', paused:'일시중지',
  completed:'완료', failed:'실패', abandoned:'중단'};
var RISK_LABEL = {high:'높음', medium:'중간', low:'낮음', other:'미분류'};
var REC_TYPE = {session:'세션', prompt:'프롬프트', task:'Task',
  decision:'결정', risk:'위험', file:'파일'};

function renderHeader(){
  var name = (data.project && data.project.name) || '-';
  el('header-meta').textContent =
    '프로젝트: ' + name + ' · 생성 시각: ' + fmtWhen(data.generated_at);
  el('footer-meta').textContent =
    'Context Relay 정적 대시보드 · 생성 시각 ' + fmtWhen(data.generated_at) +
    ' · 갱신하려면 /context-relay dashboard 를 다시 실행하세요.';
}

function renderSummary(){
  var s = data.summary || {};
  var cards = [
    ['프로젝트', (data.project && data.project.name) || '-'],
    ['현재 브랜치', (data.git && data.git.available && data.git.branch) || '-'],
    ['마지막 세션', s.last_session_at ? fmtWhen(s.last_session_at) : '-'],
    ['진행 중 Task', fmt(s.tasks_in_progress)],
    ['완료 Task', fmt(s.tasks_completed)],
    ['위험 Task', fmt(s.tasks_risky)],
    ['총 세션', fmt(s.sessions_total)],
    ['총 프롬프트', fmt(s.prompts_total)],
    ['총 작업 시간', fmtDur(s.duration_sec_total)],
    ['총 토큰', fmt(s.tokens_total)]
  ];
  el('summary-cards').innerHTML = cards.map(function(c){
    return '<div class="card"><div class="k">' + esc(c[0]) +
      '</div><div class="v">' + esc(c[1]) + '</div></div>';
  }).join('');
}

function cardHtml(t){
  var html = '<div class="kcard">';
  html += '<div class="kcard-title">' + esc(t.title) + '</div>';
  var badges = badge('st', TASK_STATUS[t.status] || t.status);
  if(t.risk_level){
    var rk = riskKey(t.risk_level);
    badges += badge('risk-' + rk, '위험도 ' + (RISK_LABEL[rk] === '미분류' ? t.risk_level : RISK_LABEL[rk]));
  }
  if(t.priority) badges += badge('prio', '우선순위 ' + t.priority);
  if(t.prd_ref) badges += badge('prd', 'PRD: ' + t.prd_ref);
  html += '<div class="kcard-badges">' + badges + '</div>';
  html += '<div class="kcard-row">세션 ' + fmt(t.sessions_count) + '개' +
    (t.tools && t.tools.length ? ' · 도구: ' + esc(t.tools.join(', ')) : '') + '</div>';
  if(t.agents && t.agents.length){
    html += '<div class="kcard-row">에이전트: ' + esc(t.agents.join(', ')) + '</div>';
  }
  html += '<div class="kcard-row">시간 ' + fmtDur(t.duration_sec) +
    ' · 토큰 ' + fmt(t.tokens) + ' · 변경 파일 ' + fmt(t.files_count) + '개</div>';
  if(t.next_action){
    html += '<div class="kcard-next">다음 액션: ' + esc(t.next_action) + '</div>';
  }
  html += '</div>';
  return html;
}

function renderKanban(){
  var tasks = data.tasks || [];
  if(!tasks.length){ emptyNote('kanban', '아직 기록이 없습니다. task를 추가하면 칸반이 채워집니다.'); return; }
  var byCol = {};
  TASK_COLS.forEach(function(c){ byCol[c[0]] = []; });
  tasks.forEach(function(t){
    var k = byCol.hasOwnProperty(t.status) ? t.status : 'not_started';
    byCol[k].push(t);
  });
  el('kanban').innerHTML = TASK_COLS.map(function(c){
    var items = byCol[c[0]];
    return '<div class="kcol"><div class="kcol-head"><span>' + esc(c[1]) +
      '</span><span>' + items.length + '</span></div>' +
      (items.length ? items.map(cardHtml).join('') : '<div class="kempty">없음</div>') +
      '</div>';
  }).join('');
}

function renderSessions(){
  var ss = data.sessions || [];
  if(!ss.length){ emptyNote('session-list'); return; }
  el('session-list').innerHTML = ss.map(function(s){
    var when = s.started_at || s.created_at;
    var st = SESSION_STATUS[s.status] || s.status || '-';
    return '<div class="trow"><span class="twhen">' + esc(fmtWhen(when)) + '</span>' +
      badge('tool', s.tool || '-') +
      '<span class="tgoal">' + esc(s.goal || '(목표 미기록)') +
      (s.agent ? ' <span class="hint">' + esc(s.agent) + '</span>' : '') + '</span>' +
      badge('st', st) +
      '<span class="ttok">' + fmt(s.tokens) + ' tok · ' + fmtDur(s.duration_sec) + '</span></div>';
  }).join('');
}

function renderPrompts(){
  var ps = data.prompts || [];
  if(!ps.length){ emptyNote('prompt-list'); return; }
  el('prompt-list').innerHTML = ps.map(function(p){
    var head = '<span class="twhen">' + esc(fmtWhen(p.created_at)) + '</span>' +
      badge('tool', p.tool || '-') +
      (p.type ? badge('type', p.type) : '') +
      (p.score !== null && p.score !== undefined ? badge('score', '점수 ' + p.score + '/5') : '') +
      (p.reuse ? badge('reuse', '재사용 후보') : '');
    var body = '<div class="ptext">' + esc(p.text || '') + '</div>';
    if(p.result) body += '<div class="presult">결과: ' + esc(p.result) + '</div>';
    if(p.files) body += '<div class="pfiles">관련 파일: ' + esc(p.files) + '</div>';
    return '<div class="item"><div class="item-head">' + head + '</div>' + body + '</div>';
  }).join('');
}

var calMetric = 's';
function isoDate(d){
  var m = d.getMonth() + 1, day = d.getDate();
  return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
}
function renderCal(){
  var grid = el('cal-grid');
  grid.innerHTML = '';
  var cal = data.calendar || {};
  var end = new Date(String(data.generated_at || '').slice(0,10) + 'T00:00:00');
  if(isNaN(end.getTime())) end = new Date();
  var start = new Date(end);
  start.setDate(start.getDate() - (7 * 16) - end.getDay());
  var max = 0, d = new Date(start), k, v, e;
  while(d <= end){
    k = isoDate(d);
    e = cal[k];
    v = e ? (calMetric === 's' ? e.s : e.t) : 0;
    if(v > max) max = v;
    d.setDate(d.getDate() + 1);
  }
  var frag = document.createDocumentFragment();
  d = new Date(start);
  while(d <= end){
    k = isoDate(d);
    e = cal[k] || {s:0, t:0};
    v = (calMetric === 's' ? e.s : e.t);
    var lv = (v <= 0 || max <= 0) ? 0 : Math.max(1, Math.ceil(v / max * 4));
    var cell = document.createElement('div');
    cell.className = 'cal-cell lv' + lv;
    cell.title = k + ' · 세션 ' + fmt(e.s) + ' · 토큰 ' + fmt(e.t);
    frag.appendChild(cell);
    d.setDate(d.getDate() + 1);
  }
  grid.appendChild(frag);
}
function setCalButtons(){
  el('cal-btn-s').className = 'toggle' + (calMetric === 's' ? ' active' : '');
  el('cal-btn-t').className = 'toggle' + (calMetric === 't' ? ' active' : '');
}

function renderBars(id, items, valFn, labelFn, valueTextFn){
  if(!items || !items.length){ emptyNote(id); return; }
  var max = 0;
  items.forEach(function(it){ var v = valFn(it); if(v > max) max = v; });
  el(id).innerHTML = items.map(function(it){
    var v = valFn(it);
    var pct = max > 0 ? Math.max(2, Math.round(v / max * 100)) : 2;
    return '<div class="bar-row">' +
      '<div class="bar-label" title="' + esc(labelFn(it)) + '">' + esc(labelFn(it)) + '</div>' +
      '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%"></div></div>' +
      '<div class="bar-val">' + esc(valueTextFn(it)) + '</div></div>';
  }).join('');
}

function renderRisk(){
  var rm = data.risk_map || {};
  var order = ['high', 'medium', 'low', 'other'];
  var html = '';
  order.forEach(function(k){
    var items = rm[k] || [];
    if(!items.length) return;
    html += '<div class="risk-group"><h3 class="risk-head risk-' + k + '">위험도 ' +
      RISK_LABEL[k] + ' (' + items.length + ')</h3>';
    html += items.map(function(it){
      return '<div class="risk-item"><code>' + esc(it.file) + '</code>' +
        (it.notes && it.notes.length
          ? '<ul>' + it.notes.map(function(n){ return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>'
          : '') + '</div>';
    }).join('');
    html += '</div>';
  });
  if(!html){ emptyNote('risk-map', '기록된 위험 파일이 없습니다.'); return; }
  el('risk-map').innerHTML = html;
}

function gitRow(k, v){
  return '<div class="git-row"><span class="gk">' + esc(k) +
    '</span><span class="gv">' + esc(v) + '</span></div>';
}
function renderGit(){
  var g = data.git || {};
  if(!g.available){
    el('git-body').innerHTML = '<div class="empty">git 저장소 아님 — 이 프로젝트 루트는 git으로 관리되지 않거나 git 명령을 사용할 수 없습니다.</div>';
  } else {
    var html = '<div class="git-grid">';
    html += gitRow('브랜치', g.branch || '-');
    html += gitRow('마지막 커밋', g.last_commit
      ? (g.last_commit.hash + ' ' + g.last_commit.subject + ' (' +
         g.last_commit.author + ', ' + g.last_commit.date + ')')
      : '커밋 없음');
    html += gitRow('커밋되지 않은 변경', fmt(g.uncommitted) + '건');
    html += '</div>';
    var rc = g.recent_commits || [];
    html += '<h4>최근 커밋 5</h4>';
    if(rc.length){
      html += '<ul class="commits">' + rc.map(function(c){
        return '<li><code>' + esc(c.hash) + '</code> ' + esc(c.subject) +
          ' <span class="hint">' + esc(c.author) + ' · ' + esc(c.date) + '</span></li>';
      }).join('') + '</ul>';
    } else {
      html += '<div class="empty">커밋 기록이 없습니다.</div>';
    }
    el('git-body').innerHTML = html;
  }
  var ev = data.git_events || [];
  if(!ev.length){ emptyNote('git-events', '기록된 git 이벤트가 없습니다.'); return; }
  el('git-events').innerHTML = ev.map(function(e){
    return '<div class="trow"><span class="twhen">' + esc(fmtWhen(e.created_at)) + '</span>' +
      (e.branch_name ? badge('tool', e.branch_name) : '') +
      (e.commit_hash ? '<code>' + esc(String(e.commit_hash).slice(0,10)) + '</code>' : '') +
      '<span class="tgoal">' + esc(e.diff_summary || '') + '</span>' +
      '<span class="ttok">파일 ' + fmt(e.changed_files_count) + '개</span></div>';
  }).join('');
}

function renderSearch(){
  var input = el('search-input');
  var out = el('search-results');
  var recs = data.search_records || [];
  function run(){
    var qs = input.value.trim().toLowerCase();
    if(!qs){
      out.innerHTML = '<div class="empty">검색어를 입력하면 임베드된 기록 ' +
        fmt(recs.length) + '건에서 부분 문자열로 찾습니다.</div>';
      return;
    }
    var hits = [];
    for(var i = 0; i < recs.length && hits.length < 50; i++){
      var r = recs[i];
      if(String(r.title || '').toLowerCase().indexOf(qs) >= 0 ||
         String(r.body || '').toLowerCase().indexOf(qs) >= 0){
        hits.push(r);
      }
    }
    if(!hits.length){
      out.innerHTML = '<div class="empty">일치하는 기록이 없습니다. 심층 검색은 CLI의 /context-relay search 를 사용하세요.</div>';
      return;
    }
    out.innerHTML = hits.map(function(r){
      return '<div class="sr-item">' + badge('type', REC_TYPE[r.type] || r.type) +
        '<strong>' + esc(r.title) + '</strong>' +
        (r.date ? ' <span class="hint">' + esc(r.date) + '</span>' : '') +
        (r.body ? '<div class="sr-body">' + esc(r.body) + '</div>' : '') + '</div>';
    }).join('');
  }
  input.addEventListener('input', run);
  run();
}

renderHeader();
renderSummary();
renderKanban();
renderSessions();
renderPrompts();
renderCal();
setCalButtons();
el('cal-btn-s').addEventListener('click', function(){ calMetric = 's'; setCalButtons(); renderCal(); });
el('cal-btn-t').addEventListener('click', function(){ calMetric = 't'; setCalButtons(); renderCal(); });
renderBars('file-bars', data.file_heat || [],
  function(x){ return x.count; },
  function(x){ return x.path; },
  function(x){ return fmt(x.count) + '회'; });
renderBars('task-bars', data.task_tokens || [],
  function(x){ return x.tokens; },
  function(x){ return x.title; },
  function(x){ return fmt(x.tokens) + ' tok'; });
renderBars('agent-bars', data.agent_activity || [],
  function(x){ return x.sessions; },
  function(x){ return x.name; },
  function(x){ return '세션 ' + fmt(x.sessions) + ' · 토큰 ' + fmt(x.tokens); });
renderRisk();
renderGit();
renderSearch();
})();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="cr_dashboard.py",
        description="Context Relay 정적 HTML 대시보드 생성기 (자체완결 1파일)")
    ap.add_argument("--root", help="프로젝트 루트 경로 "
                    "(기본: cwd에서 상위로 context-relay/context-relay.sqlite 탐색)")
    ap.add_argument("--out", help="출력 HTML 경로 "
                    "(기본: <root>/context-relay/dashboard/index.html)")
    args = ap.parse_args(argv)

    if args.root:
        root = Path(args.root).expanduser().resolve()
    else:
        root = find_root(Path.cwd())
        if root is None:
            print("오류: context-relay/context-relay.sqlite 를 찾을 수 없습니다.",
                  file=sys.stderr)
            print("먼저 프로젝트 루트에서 초기화하세요: /context-relay init "
                  "(또는 python3 cr.py init)", file=sys.stderr)
            print("탐색 시작 위치: {}".format(Path.cwd()), file=sys.stderr)
            return 2

    db_path = root / DB_RELPATH
    if not db_path.is_file():
        print("오류: DB가 없습니다: {}".format(db_path), file=sys.stderr)
        print("먼저 프로젝트 루트에서 초기화하세요: /context-relay init "
              "(또는 python3 cr.py init)", file=sys.stderr)
        return 2

    out = (Path(args.out).expanduser().resolve() if args.out
           else root / "context-relay" / "dashboard" / "index.html")

    conn = connect_ro(db_path)
    try:
        data = collect(conn, root)
    finally:
        conn.close()

    # JSON 임베드: '<' 전체를 < 로 치환 → "</script>" 조기 종료 및
    # "<script>" 류 마크업이 raw 로 노출되는 것을 모두 차단 (유효한 JSON escape).
    payload = json.dumps(data, ensure_ascii=False,
                         separators=(",", ":")).replace("<", "\\u003c")
    html = HTML_TEMPLATE.replace("__CR_DATA__", payload)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")

    s = data["summary"]
    print("대시보드 생성 완료: {}".format(out))
    print("세션 {}건 · 프롬프트 {}건 · task {}건 · 브라우저로 여세요.".format(
        s["sessions_total"], s["prompts_total"], s["tasks_total"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
